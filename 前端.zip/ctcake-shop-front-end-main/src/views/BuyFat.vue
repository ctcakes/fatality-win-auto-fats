<template>
  <div class="buy-container">
    <div class="buy-panel">
      <!-- 顶部装饰与标题区 -->
      <div class="buy-panel__header">
        <div class="header-decoration"></div>
        <h2 class="buy-panel__title">Fatality.win FAT$购买</h2>
        <div class="buy-panel__subtitle">发货服务器:{{ server }}</div>
      </div>

      <!-- 主体内容区 -->
      <div class="buy-panel__body">
        <!-- 购买模式选择 -->
        <div class="mode-selector">
          <div class="mode-tabs">
            <div class="mode-tab" :class="{ active: selectedMode === 'arrival' }" @click="selectedMode = 'arrival'">
              <span>到账模式</span>
            </div>
            <div class="mode-tab" :class="{ active: selectedMode === 'direct' }" @click="selectedMode = 'direct'">
              <span>直接下单</span>
            </div>
          </div>

          <div class="mode-description">
            <p v-if="selectedMode === 'arrival'">
              <strong>到账模式：</strong>输入您想要<span class="highlight">实际到账</span>的FAT数量，系统自动计算需要购买的数量
            </p>
            <p v-else>
              <strong>直接下单：</strong>输入购买数量，<span class="highlight">实际到账约为购买量的90%</span>
            </p>
          </div>
        </div>

        <!-- 主要内容区域（左右布局） -->
        <div class="main-content-layout">
          <!-- 左侧：输入表单 -->
          <div class="input-section">
            <!-- FAT数量输入 -->
            <div class="fat-quantity-section">
              <a-form-item :label="selectedMode === 'arrival' ? '实际到账数量' : '购买数量'" class="quantity-form-item">
                <div class="quantity-input-wrapper">
                  <a-input v-model:value="userInputQuantity" type="number" :min="10" :step="1" class="quantity-input"
                    :placeholder="selectedMode === 'arrival' ? '输入您想要的实际到账数量' : '输入购买数量'"
                    @change="onUserInputQuantityChange" />
                </div>
                <div class="quantity-info">
                  最低购买10个，<span class="fee-info">手续费10%</span>
                </div>
              </a-form-item>
            </div>

            <!-- 用户名输入框 -->
            <a-form-item label="论坛用户名" class="username-form-item">
              <a-input v-model:value="username" placeholder="请输入您的论坛用户名" size="large" :maxlength="50" show-count
                :status="usernameStatus" @input="checkUsername">
                <template #prefix>
                  <UserOutlined class="input-icon" />
                </template>
              </a-input>
              <div v-if="usernameStatus === 'error'" class="error-tip">
                <ExclamationCircleOutlined /> 用户名不能为空
              </div>
            </a-form-item>

            <!-- 权益说明 -->
            <div class="benefits-list">
              <p class="benefits-title">卡网优势</p>
              <ul>
                <li>
                  <CheckCircleOutlined /> 全自动发货
                </li>
                <li>
                  <CheckCircleOutlined /> 发货完成后可查看发货截图
                </li>
                <li>
                  <CheckCircleOutlined /> 支持输错用户名自动退款(遵循<RouterLink to="/agreement-refund" class="agreement-link">退款准则
                  </RouterLink>)
                </li>
              </ul>
            </div>
          </div>

          <!-- 右側：計算結果和推薦 -->
          <div class="result-section">
            <!-- 价格展示卡片 -->
            <div class="price-card">
              <div class="price-row">
                <div v-if="is_sale_active" class="original-price">¥{{ (calculatedPayable *
                  currentSettings.fat_price).toFixed(2)
                }}</div>
                <div class="current-price">
                  <span class="price-symbol">¥</span>
                  <span class="price-number">{{ finalPrice }}</span>
                  <span class="price-unit">/ {{ calculatedPayable }}个</span>
                </div>
              </div>
              <div v-if="is_sale_active" class="price-tag">限时优惠</div>
            </div>

            <!-- 价格和手续费计算展示 -->
            <div class="calculation-display">
              <div class="display-row">
                <span><strong>实际到账:</strong></span>
                <span class="value highlight-arrival">{{ calculatedArrival }}</span>
              </div>
              <div class="display-row">
                <span>需要付款:</span>
                <span class="value">{{ calculatedPayable }}</span>
              </div>
              <div class="display-row">
                <span>手续费:</span>
                <span class="value">{{ calculatedFee }}</span>
              </div>
              <div class="display-row total">
                <span>支付总额:</span>
                <span class="value price">¥{{ finalPrice }}</span>
              </div>
            </div>

            <!-- 智能推荐区 -->
            <div v-if="recommendations.length > 0" class="recommendations-section">
              <h4>💡 推荐购买方案</h4>
              <div class="recommendations-list">
                <div v-for="rec in recommendations" :key="rec.payable" class="recommendation-item"
                  @click="applyRecommendation(rec)">
                  <div class="rec-info">
                    <div class="rec-main">付款 {{ rec.payable }} 个</div>
                    <div class="rec-sub"><strong>实际到账 {{ rec.arrival }} 个</strong>(手续费 {{ rec.fee }} 个)</div>
                  </div>
                  <div class="rec-price">¥{{ rec.price }}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 底部操作区 -->
      <div class="buy-panel__footer">
        <div class="payment-notice">
          <InfoCircleOutlined /> 支付成功后系统将自动为您发货
        </div>

        <!-- 支付按钮组 -->
        <a-tooltip v-if="can_buy && tooltipReason" :title="tooltipReason">
          <div v-if="can_buy && tooltipReason" class="payment-buttons">
            <a-button type="primary" size="large" class="payment-btn dual-color-btn" @click="confrim_modal_show = true;"
              :loading="paymentLoading" :disabled="disabled">
              <template #icon>
                <WechatOutlined class="btn-icon" />
                OR
                
              </template>
              前往支付
              <AlipayOutlined class="btn-icon" />
            </a-button>
          </div>
        </a-tooltip>

        <div v-if="can_buy && !tooltipReason" class="payment-buttons">
          <a-button type="primary" size="large" class="payment-btn dual-color-btn" @click="confrim_modal_show = true;"
            :loading="paymentLoading" :disabled="disabled">
            <template #icon>
              <WechatOutlined class="btn-icon" />
              
            </template>
            <span style="position: relative; top: -13px;left: 30px;">O</span>
            <span style="position: relative; top: 7px;">前往支付</span>
            <span style="position: relative; top: -13px;left: -30px;">R</span>
              <AlipayOutlined class="btn-icon" />
          </a-button>
        </div>

        <div v-else>
          <a-card hoverable class="check-card" v-if="error || showLoad">
            <a-result title="正在检查发货服务器状态...">
              <template #icon>
                <LoadingOutlined />
              </template>
              <template #extra>
                <p>正在检查发货服务器状态，检查完成后即可购买。发货服务器不正常将无法发货。</p>
              </template>
            </a-result>
          </a-card>

          <a-result status="error" title="失败" sub-title="检查发货服务器时出现错误" v-if="error">
            <template #extra>
              <div class="desc">
                <p style="font-size: 16px">
                  <close-circle-outlined style="margin-right: 5px;" />{{ error_msg }}
                </p>
              </div>
              <a-button href="/" type="primary">返回</a-button>
            </template>
          </a-result>
        </div>

        <!-- 协议提示 -->
        <div class="agreement-tip">
          点击支付即表示您同意
          <RouterLink to="/agreement-refund" class="agreement-link">退款准则</RouterLink>
          及<RouterLink to="/ui-agreement" class="agreement-link">信息收集行为</RouterLink>
        </div>
      </div>
    </div>
  </div>


  <a-modal v-model:visible="confrim_modal_show" title="确认订单" @cancel="confrim_modal_show = false"
    :ok-button-props="{ disabled: true }" ok-text="CTCAKE SHOP" cancel-text="取消">
    <div v-if="selectedMode == 'arrival'">
      <h3>购买模式：到账数量</h3>
      <p>您将<span class="highlight">实际到账</span>：<strong class="highlight-arrival">{{ calculatedArrival }}个FAT</strong></p>
      <p>需支付：<strong>{{ calculatedPayable }}个FAT</strong>（含10%手续费）</p>
      <p>FAT单价：¥{{ FAT_PRICE }}/个，总计：<strong class="price">¥{{ finalPrice }}</strong></p>
      <p>请确认信息无误后支付。</p>
    </div>
    <div v-else>
      <h3>购买模式：直接下单</h3>
      <p>支付数量：<strong>{{ userInputQuantity }}个FAT</strong></p>
      <p><span class="highlight">实际到账</span>：<strong class="highlight-arrival">{{ calculatedArrival }}个FAT</strong>（扣除10%手续费）</p>
      <p>FAT单价：¥{{ FAT_PRICE }}/个，总计：<strong class="price">¥{{ finalPrice }}</strong></p>
      <p>请确认信息无误后支付。</p>
    </div>

    <div class="buy-panel__footer">
      <div class="payment-buttons">
        <a-button type="primary" size="large" class="payment-btn wechat-btn" @click="handlePayment('wechat')"
          :loading="paymentLoading" :disabled="disabled">
          <template #icon>
            <WechatOutlined class="btn-icon" />
          </template>
          微信支付
        </a-button>
        <a-button type="primary" size="large" class="payment-btn alipay-btn" @click="handlePayment('alipay')"
          :loading="paymentLoading" :disabled="disabled">
          <template #icon>
            <AlipayOutlined class="btn-icon" />
          </template>
          支付宝
        </a-button>
      </div>
    </div>
  </a-modal>
</template>

<script setup>
import { ref, computed, onMounted, watchEffect } from 'vue';
import { useRouter } from 'vue-router';
import { message } from 'ant-design-vue';
import {
  UserOutlined,
  ExclamationCircleOutlined,
  CheckCircleOutlined,
  InfoCircleOutlined,
  WechatOutlined,
  AlipayOutlined,
  LoadingOutlined,
  CloseCircleOutlined,
  CloseSquareFilled
} from '@ant-design/icons-vue';
import axios from 'axios';
import FingerprintJS from '@fingerprintjs/fingerprintjs';

const router = useRouter();
const wallet_fat = ref(0);
// 响应式数据
const username = ref('');
const paymentLoading = ref(false);
const can_buy = ref(false);
const error = ref(false);
const error_msg = ref('');
const showLoad = ref(false);
const server = ref('获取中...');
const selectedMode = ref('arrival'); // 'arrival' 或 'direct'
const userInputQuantity = ref(10); // 用户输入的数量
const tooltipReason = ref('');
// FAT单价
const FAT_PRICE = ref(0.75); // 默认单价，将从后端获取

const FEE_RATE = 0.1; // 手续费10%
const confrim_modal_show = ref(false);
const is_sale_active = ref(false); // 促销活动状态
const currentSettings = ref({ fat_price: 0.75 }); // 当前设置

// 获取价格和促销设置
const fetchPriceSettings = async () => {
  try {
    const response = await axios.get('/api/theme-settings');
    if (response.data.fat_price !== undefined) {
      FAT_PRICE.value = parseFloat(response.data.fat_price);
    }
    if (response.data.is_sale_active !== undefined) {
      is_sale_active.value = response.data.is_sale_active;
    }
    // 更新currentSettings
    currentSettings.value = response.data;
  } catch (error) {
    console.error('获取价格设置失败:', error);
    // 如果获取失败，保持默认值
  }
};

// 计算相关数据
const calculatedArrival = computed(() => {
  // 确保用户输入是有效数字
  const inputVal = parseInt(userInputQuantity.value) || 10;
  if (selectedMode.value === 'arrival') {
    // 到账模式：输入的是到账数量
    const arrival = Math.max(10, inputVal);
    const payable = Math.round(arrival * (1 + FEE_RATE));
    return payable > 0 ? arrival : 0;
  } else {
    // 直接下单模式：输入的是购买数量
    const payable = Math.max(10, inputVal);
    const arrival = Math.round(payable * (1 - FEE_RATE));
    return arrival > 0 ? arrival : 0;
  }
});

const calculatedPayable = computed(() => {
  // 确保用户输入是有效数字
  const inputVal = parseInt(userInputQuantity.value) || 10;
  if (selectedMode.value === 'arrival') {
    // 到账模式：计算需要购买的数量
    const arrival = Math.max(10, inputVal);
    return Math.max(10, Math.round(arrival * (1 + FEE_RATE)));
  } else {
    // 直接下单模式：就是输入的数量
    return Math.max(10, inputVal);
  }
});

const calculatedFee = computed(() => {
  const fee = calculatedPayable.value - calculatedArrival.value;
  return isNaN(fee) ? 0 : fee;
});

const finalPrice = computed(() => {
  // 使用响应式变量中的价格
  let pricePerFat = FAT_PRICE.value; // 使用响应式变量
  return (calculatedPayable.value * pricePerFat).toFixed(2);
});

// 智能推荐计算
const recommendations = computed(() => {
  const results = [];
  const baseArrival = calculatedArrival.value;

  // 确保FAT_PRICE有效
  const currentFatPrice = isNaN(FAT_PRICE.value) ? 0.75 : FAT_PRICE.value;

  // 生成推荐选项，寻找手续费相同但数量更多的选项
  for (let i = baseArrival + 1; i <= baseArrival + 50 && results.length < 5; i++) {
    const payable = Math.round(i * (1 + FEE_RATE));
    const fee = payable - i;

    // 查找相同手续费的更大数量
    for (let j = i + 1; j <= i + 20 && results.length < 5; j++) {
      const testPayable = Math.round(j * (1 + FEE_RATE));
      const testFee = testPayable - j;

      if (Math.abs(testFee - fee) < 0.5) { // 手续费相近
        const testPrice = (testPayable * currentFatPrice).toFixed(2);
        results.push({
          arrival: j,
          payable: testPayable,
          fee: testFee,
          price: testPrice
        });
      }
    }
  }

  // 过滤掉重复和不划算的选项，只保留性价比高的
  const uniqueResults = [];
  const feeMap = new Map();

  for (const rec of results) {
    const roundedFee = Math.round(rec.fee);
    if (!feeMap.has(roundedFee) || rec.arrival > feeMap.get(roundedFee).arrival) {
      feeMap.set(roundedFee, rec);
    }
  }

  for (const [_, rec] of feeMap) {
    if (rec.arrival > calculatedArrival.value) { // 只显示比当前选择更多的选项
      uniqueResults.push(rec);
    }
  }

  // 按实收数量排序
  return uniqueResults.sort((a, b) => b.arrival - a.arrival).slice(0, 3);
});

const disabled = ref(false);

// FAT数量相关计算
const onUserInputQuantityChange = (e) => {
  let value = parseInt(e.target.value);
  // 如果输入的不是有效数字，保持原值
  if (isNaN(value)) {
    // 不做任何更改，保持当前值
    return;
  }
  // // 确保数量至少为10
  // if (value < 10) {
  //   // 显示错误信息并重置为10
  //   // message.warning('FAT数量不能低于10个');
  //   userInputQuantity.value = 10;
  // }
};

// 应用推荐选项
const applyRecommendation = (rec) => {
  selectedMode.value = 'arrival';
  userInputQuantity.value = rec.arrival;
};

// 用户名状态校验
const usernameStatus = computed(() => {
  // 已输入且不为空
  if (username.value.trim()) return 'success';
  // 未输入但已触发校验（有值后又清空）
  if (username.value === '') return '';
  // 为空且触发过校验
  return 'error';
});

// 检查用户名
const checkUsername = () => {
  // 仅做状态更新，不主动提示
};

// 支付处理函数
const handlePayment = async (type) => {
  // 校验用户名
  if (!username.value.trim()) {
    message.error('请输入有效的论坛用户名');
    return;
  }

  // 校验FAT数量
  if (calculatedPayable.value < 10) {
    message.error('FAT数量不能低于10个');
    return;
  }

  try {

    paymentLoading.value = true;

    // 获取浏览器指纹
    const fp = await FingerprintJS.load();
    const result = await fp.get();
    const browserFingerprint = result.visitorId;

    // 调用后端API创建支付订单
    const response = await axios.post('/api/create-payment', {
      username: username.value,
      payment_method: type, // 'wechat' 或 'alipay'
      buy_type: 'fat', // 购买类型为fat
      fat_count: calculatedPayable.value, // 应付FAT数量
      amount: parseFloat(calculatedPayable.value * FAT_PRICE.value), // 实际金额
      browser_fingerprint: browserFingerprint // 添加浏览器指纹
    });

    if (response.data.success) {
      // 成功创建支付订单，跳转到等待支付页面
      const paymentUrl = response.data.payment_url;
      const qrcode = response.data.qrcode;
      if (paymentUrl || qrcode) {



        // 跳转到等待支付页面，传递订单ID
        router.push(`/buy/waiting?order_id=${response.data.order_id}`);
      } else {
        message.error('获取支付链接失败');
      }
    } else {
      message.error(response.data.error || '支付创建失败');
    }
  } catch (error) {
    console.error('支付请求错误:', error);
    message.error('支付请求失败，请重试');
  } finally {
    paymentLoading.value = false;
  }
};

// 检查订单状态
const checkOrderStatus = async (order_id) => {
  try {
    // 显示支付状态提示
    message.info('正在支付中，请稍候...', 0); // 0表示不自动关闭

    // 轮询订单状态，最多轮询30次（每2秒一次，持续60秒）
    for (let i = 0; i < 30; i++) {
      await new Promise(resolve => setTimeout(resolve, 2000)); // 等待2秒

      const response = await axios.get(`/api/order-status/${order_id}`);

      if (response.data.status === 'paid') {
        // 订单已支付
        message.destroy(); // 关闭之前的消息
        message.success('支付成功！正在为您发货...');

        // 可以在这里添加发货成功后的逻辑，如跳转到成功页面
        setTimeout(() => {
          message.success('FAT$购买成功！请返回论坛查看您的购买结果。');
        }, 2000);

        return; // 退出轮询
      } else if (response.data.status === 'cancelled') {
        // 订单已取消
        message.destroy();
        message.error('支付已取消');
        return;
      }
    }

    // 超时未支付
    message.destroy();
    message.warning('支付超时，请重新尝试支付');
  } catch (error) {
    console.error('检查订单状态错误:', error);
    message.destroy();
    message.error('检查订单状态失败');
  }
};

const getServerStatus = async () => {
  showLoad.value = true;
  axios.get('/api/get_fat').then((response) => {
    const balance = Number(response.data.last_sync_balance);
    wallet_fat.value = balance;
    if (balance > 0) {
      can_buy.value = true;
      server.value = "在线 剩余FAT库存:" + response.data.last_sync_balance;
      showLoad.value = false;
    } else {
      can_buy.value = false;
      message.error('卡网FAT库存不足，暂时无法购买，请等待补货后再来。');
      error.value = true;
      showLoad.value = true;
      let baseErrorMsg = '卡网FAT库存不足，暂时无法购买，请等待补货后再来。';
      if (response.data.msg) {
        error_msg.value = baseErrorMsg + ' 错误信息:' + response.data.msg;
      } else {
        error_msg.value = baseErrorMsg + 'Fat$库存:' + response.data.last_sync_balance;
      }
    }
  }).catch((e) => {
    can_buy.value = false;
    message.error('发货服务器状态检查失败，暂时无法购买，请稍后再试。');
    error.value = true;
    showLoad.value = true;
    let baseErrorMsg = '服务器状态检查失败，请稍后再试。';
    if (e.message) {
      error_msg.value = baseErrorMsg + ' 错误信息：' + e.message;
    } else {
      error_msg.value = baseErrorMsg;
    }
  });
}

onMounted(() => {
  fetchPriceSettings(); // 先获取价格设置
  getServerStatus();
});

watchEffect(() => {
  const inputValue = Number(userInputQuantity.value);

  console.log('应付FAT数量：' + calculatedPayable.value)
  console.log('库存FAT数量：' + wallet_fat.value)
  console.log('选择模式：' + selectedMode.value)
  console.log('用户输入数量：' + inputValue)
  console.log('输入数量的类型' + typeof (inputValue))
  console.log('钱包类型' + typeof (wallet_fat.value))
  console.log(calculatedPayable.value > Number(wallet_fat.value))

  // 初始化disabled和tooltipReason
  disabled.value = false;
  tooltipReason.value = '';

  // 检查服务器状态
  if (!can_buy.value) {
    disabled.value = true;
    tooltipReason.value = '服务器状态异常，暂时无法购买';
    return; // 如果服务器状态异常，直接返回
  }

  // 检查是否为有效数字
  if (isNaN(inputValue)) {
    disabled.value = true;
    tooltipReason.value = '请输入有效的数字';
    return;
  }

  // 检查输入是否为空
  if (userInputQuantity.value === '') {
    disabled.value = true;
    tooltipReason.value = '请输入购买数量';
    return;
  }

  // 检查是否为整数
  if (!Number.isInteger(inputValue)) {
    disabled.value = true;
    tooltipReason.value = '购买数量必须是整数';
    return;
  }

  // 检查是否为0或负数
  if (inputValue <= 0) {
    disabled.value = true;
    tooltipReason.value = '购买数量必须大于0';
    return;
  }

  // 检查是否小于最小购买量
  if (inputValue < 10) {
    disabled.value = true;
    tooltipReason.value = 'FAT数量不能低于10个';
    return;
  }

  // 检查是否超过库存
  if (inputValue > Number(wallet_fat.value)) {
    disabled.value = true;
    tooltipReason.value = `当前库存仅剩 ${wallet_fat.value} 个FAT$，无法购买超过库存的数量`;
    return;
  }

  // 检查计算出的应付数量是否小于10
  if (calculatedPayable.value < 10) {
    disabled.value = true;
    tooltipReason.value = '购买数量不能低于10个';
    return;
  }

  // 检查计算出的应付数量是否超过库存
  if (calculatedPayable.value > Number(wallet_fat.value)) {
    disabled.value = true;
    tooltipReason.value = `当前库存仅剩 ${wallet_fat.value} 个FAT$，无法购买超过库存的数量`;
    return;
  }

  // 检查计算出的数量是否为负数或0（虽然前面检查了inputValue，但这里确保计算后的值也是正数）
  if (calculatedPayable.value <= 0) {
    disabled.value = true;
    tooltipReason.value = '购买数量必须大于0';
    return;
  }

  // 如果所有检查都通过，则启用按钮
  disabled.value = false;
  tooltipReason.value = '';
})</script>

<style scoped lang="less">
// 外层容器 - 清新渐变背景
.buy-container {
  min-height: 100vh;
  padding: 40px 20px;
  display: flex;
  align-items: center;
  justify-content: center;
}

// 卡片主体 - 精致化设计
.buy-panel {
  width: 800px; // 增加宽度以适应左右布局
  background: #ffffff;
  border-radius: 20px;
  box-shadow:
    0 10px 40px rgba(0, 0, 0, 0.08),
    0 4px 15px rgba(0, 0, 0, 0.06);
  overflow: hidden;
  position: relative;
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);

  &:hover {
    transform: translateY(-5px);
    box-shadow:
      0 15px 50px rgba(0, 0, 0, 0.15),
      0 6px 20px rgba(0, 0, 0, 0.1);
  }

  // 头部区域 - 增强视觉层次
  &__header {
    text-align: center;
    padding: 35px 24px 25px;
    position: relative;
    background: linear-gradient(135deg, #f8fafc 0%, #eef2f7 100%);

    .header-decoration {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 8px;
      background: linear-gradient(90deg, #07c160 0%, #1677ff 100%);
    }

    .buy-panel__title {
      margin: 0 0 8px 0;
      font-size: 24px;
      font-weight: 700;
      color: #111827;
      letter-spacing: 0.5px;
      background: linear-gradient(135deg, #07c160 0%, #1677ff 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .buy-panel__subtitle {
      margin: 0;
      font-size: 15px;
      color: #6b7280;
      font-weight: 500;
    }
  }

  // 主体内容区
  &__body {
    padding: 0 32px 28px;

    // 购买模式选择区
    .mode-selector {
      margin-bottom: 24px;

      .mode-tabs {
        display: flex;
        border-radius: 12px;
        background: #f1f5f9;
        padding: 4px;
        margin-bottom: 12px;

        .mode-tab {
          flex: 1;
          padding: 10px;
          text-align: center;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.3s ease;
          font-weight: 500;
          color: #64748b;

          &.active {
            background: #ffffff;
            color: #1677ff;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            font-weight: 600;
          }
        }
      }

      .mode-description {
        padding: 12px;
        background: #f0f9ff;
        border-radius: 8px;
        border-left: 4px solid #3b82f6;
        font-size: 13px;
        color: #1e40af;

        p {
          margin: 0;
          line-height: 1.5;
        }
      }
    }

    // 主要内容左右布局
    .main-content-layout {
      display: flex;
      gap: 24px;

      .input-section {
        flex: 1;
      }

      .result-section {
        flex: 1;
        min-width: 300px; // 确保右侧区域有足够空间
      }
    }

    // FAT数量选择区
    .fat-quantity-section {
      margin-bottom: 24px;

      .quantity-form-item {
        margin-bottom: 16px;

        :deep(.ant-form-item-label) {
          font-weight: 500;
          color: #374151;
          padding-bottom: 6px;
        }

        .quantity-input-wrapper {
          display: flex;
          align-items: center;
          justify-content: center;

          .quantity-input {
            width: 100%;
            text-align: center;
            font-size: 18px;
            font-weight: 600;
            height: 50px;
            border-radius: 12px;
            border: 2px solid #e5e7eb;

            &:focus {
              border-color: #1677ff;
              box-shadow: 0 0 0 4px rgba(22, 119, 255, 0.15);
            }
          }
        }

        .quantity-info {
          font-size: 13px;
          color: #6b7280;
          text-align: center;
          margin-top: 8px;
        }
      }
    }

    // 计算结果展示
    .calculation-display {
      background: #f8fafc;
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 24px;
      border: 1px solid #e2e8f0;

      .display-row {
        display: flex;
        justify-content: space-between;
        padding: 8px 0;
        border-bottom: 1px solid #e2e8f0;
        font-size: 14px;
        color: #334155;

        &:last-child {
          border-bottom: none;
          font-weight: 600;
        }

        &.total {
          font-size: 16px;
          padding-top: 12px;

          .price {
            color: #dc2626;
            font-size: 18px;
          }
        }

        .value {
          color: #1f2937;
          font-weight: 500;
        }
      }
    }

    // 智能推荐区
    .recommendations-section {
      margin-bottom: 24px;

      h4 {
        margin: 0 0 12px 0;
        font-size: 14px;
        font-weight: 600;
        color: #1e2937;
      }

      .recommendations-list {
        display: flex;
        flex-direction: column;
        gap: 8px;

        .recommendation-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 12px;
          background: #f0fdf4;
          border-radius: 8px;
          border: 1px solid #bbf7d0;
          cursor: pointer;
          transition: all 0.2s ease;

          &:hover {
            background: #dcfce7;
            transform: translateY(-2px);
          }

          .rec-info {
            flex: 1;

            .rec-main {
              font-weight: 600;
              color: #047857;
            }

            .rec-sub {
              font-size: 12px;
              color: #059669;
              margin-top: 4px;
            }
          }

          .rec-price {
            font-weight: 700;
            color: #059669;
            font-size: 16px;
          }
        }
      }
    }

    // 价格卡片
    .price-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      margin-bottom: 24px;
      padding: 20px;
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
      border-radius: 16px;
      position: relative;
      border: 1px solid rgba(226, 232, 240, 0.5);

      .price-row {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 10px;
      }

      .current-price {
        display: flex;
        align-items: baseline;
      }

      .price-symbol {
        font-size: 22px;
        color: #2563eb;
        margin-right: 4px;
      }

      .price-number {
        font-size: 40px;
        font-weight: 800;
        color: #1d4ed8;
        letter-spacing: -1px;
      }

      .price-unit {
        font-size: 17px;
        color: #475569;
        margin-left: 6px;
      }

      .price-tag {
        position: absolute;
        top: -12px;
        right: 20px;
        background: linear-gradient(135deg, #f59e0b, #d97706);
        color: white;
        font-size: 13px;
        padding: 4px 12px;
        border-radius: 20px;
        font-weight: 600;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      }
    }

    // 用户名输入项
    .username-form-item {
      margin-bottom: 24px;

      :deep(.ant-form-item-label) {
        font-weight: 500;
        color: #374151;
        padding-bottom: 6px;
      }

      :deep(.ant-input) {
        height: 50px;
        border-radius: 12px;
        border: 2px solid #e5e7eb;
        padding: 0 16px;
        font-size: 15px;
        transition: all 0.3s ease;
        background-color: #f9fafb;

        &:hover {
          border-color: #a0aec0;
        }

        &:focus {
          border-color: #1677ff;
          box-shadow: 0 0 0 4px rgba(22, 119, 255, 0.15);
          background-color: #ffffff;
        }
      }

      .input-icon {
        color: #718096;
        font-size: 16px;
      }

      .error-tip {
        margin-top: 8px;
        font-size: 13px;
        color: #e53e3e;
        display: flex;
        align-items: center;
        padding: 6px 10px;
        background-color: #fef2f2;
        border-radius: 6px;
        border-left: 4px solid #e53e3e;

        :deep(.anticon) {
          font-size: 14px;
          margin-right: 6px;
        }
      }
    }

    // 权益列表
    .benefits-list {
      padding: 16px;
      background: #f8fafc;
      border-radius: 12px;
      border: 1px solid #e2e8f0;

          .benefits-title {
            margin: 0 0 14px 0;
            font-size: 16px;
            font-weight: 600;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 8px;
      
            :deep(.anticon) {
              color: #0ea5e9;
            }
          }
          
          .highlight {
            color: #0ea57a;
            font-weight: 600;
          }
          
          .highlight-arrival {
            color: #0ea57a;
            font-weight: 700;
            font-size: 18px;
          }
          
          .fee-info {
            color: #ef4444;
            font-weight: 500;
          }
      ul {
        margin: 0;
        padding-left: 20px;
        list-style: none;

        li {
          margin-bottom: 10px;
          font-size: 14px;
          color: #334155;
          display: flex;
          align-items: center;
          padding: 6px 0;

          :deep(.anticon) {
            color: #10b981;
            margin-right: 10px;
            font-size: 16px;
            background: #ecfdf5;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
          }
        }
      }
    }
  }

  // 底部操作区
  &__footer {
    padding: 28px 32px 36px;
    background: linear-gradient(135deg, #f8fafc 0%, #eef2f7 100%);
    border-top: 1px solid rgba(226, 232, 240, 0.6);

    .payment-notice {
      text-align: center;
      font-size: 14px;
      color: #4b5563;
      margin-bottom: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 12px;
      background: #f1f5f9;
      border-radius: 10px;
      border-left: 4px solid #3b82f6;

      :deep(.anticon) {
        font-size: 14px;
        margin-right: 8px;
        color: #2563eb;
      }
    }

    // 支付按钮组
    .payment-buttons {
      display: flex;
      gap: 16px;
      margin-bottom: 20px;

      .payment-btn {
        flex: 1;
        height: 54px;
        border-radius: 14px;
        font-size: 16px;
        font-weight: 600;
        border: none;
        position: relative;
        overflow: hidden;
        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        letter-spacing: 0.5px;

        .btn-icon {
          font-size: 18px;
          margin-right: 8px;
        }

        // 按钮点击波纹效果
        &::after {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          background: rgba(255, 255, 255, 0.3);
          border-radius: 50%;
          transform: translate(-50%, -50%);
          transition: width 0.6s ease, height 0.6s ease;
        }

        &:active::after {
          width: 300px;
          height: 300px;
        }

        // 微信按钮
        &.wechat-btn {
          background: linear-gradient(135deg, #10b981 0%, #059669 100%);
          box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);

          &:hover {
            background: linear-gradient(135deg, #059669 0%, #047857 100%);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);
          }

          &:active {
            transform: translateY(0);
            box-shadow: 0 2px 10px rgba(16, 185, 129, 0.3);
          }
        }

        // 支付宝按钮
        &.alipay-btn {
          background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
          box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);

          &:hover {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
          }

          &:active {
            transform: translateY(0);
            box-shadow: 0 2px 10px rgba(59, 130, 246, 0.3);
          }
        }

        // 双色按钮 - 左50%绿色，右50%蓝色，使用更柔和的渐变
        &.dual-color-btn {
          background: linear-gradient(to right, #10b981 0%, #0ea57a 45%, #2563eb 55%, #3b82f6 100%);
          box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);

          &:hover {
            background: linear-gradient(to right, #059669 0%, #047857 45%, #1d4ed8 55%, #2563eb 100%);
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
          }

          &:active {
            transform: translateY(0);
            box-shadow: 0 2px 10px rgba(59, 130, 246, 0.3);
          }
        }
      }
    }

    // 协议提示
    .agreement-tip {
      text-align: center;
      font-size: 13px;
      color: #64748b;
      padding: 10px;
      background: #f8fafc;
      border-radius: 8px;

      .agreement-link {
        color: #2563eb;
        text-decoration: none;
        margin: 0 4px;
        font-weight: 500;

        &:hover {
          text-decoration: underline;
          color: #1d4ed8;
        }
      }
    }
  }
}

// 响应式适配 - 移动端
@media (max-width: 768px) {
  .buy-panel {
    width: 92%;

    &__body {
      padding: 0 20px 20px;
    }

    .main-content-layout {
      flex-direction: column;
    }

    &__footer {
      padding: 20px 20px 28px;

    }

    .price-card .price-number {
      font-size: 32px;
    }
  }
}

//检测服务器的card
.check-card {
  width: 420px;
  margin: 0 auto;
  margin-top: 30px;
  text-align: center;
  padding: 40px;
  background: #ffffff;
  border-radius: 16px;
  box-shadow:
    0 8px 30px rgba(0, 0, 0, 0.08),
    0 2px 10px rgba(0, 0, 0, 0.04);
  overflow: hidden;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.check-card:hover {
  transform: translateY(-4px);
  box-shadow:
    0 12px 40px rgba(0, 0, 0, 0.12),
    0 4px 15px rgba(0, 0, 0, 0.06);
}

.desc {
  margin: 24px 0 0 0; // 与上方内容拉开间距，匹配antd默认间距规范
  margin-bottom: 15px;
  padding: 16px 20px;
  background-color: #fff2f0; // 错误状态配套浅红背景，贴合antd error色系
  border: 1px solid #ffccc7;
  border-radius: 8px; // 圆角弱化硬朗感
  box-shadow: 0 2px 8px rgba(245, 108, 108, 0.08); // 轻微阴影增强层次感
  max-width: 600px; // 限制宽度，避免文本过长影响阅读
  margin-left: auto;
  margin-right: auto; // 居中显示

  p {
    margin: 0 !important; // 清除默认p标签间距
    font-size: 16px !important;
    color: #f5222d; // antd error主色，突出错误提示
    line-height: 1.8; // 行高优化，提升可读性
    text-align: center; // 文本居中，视觉更规整
    word-break: break-word; // 兼容长文本换行
  }

  // 响应式适配：移动端调整间距和字体
  @media (max-width: 768px) {
    padding: 12px 16px;
    max-width: 100%;

    p {
      font-size: 14px !important;
      line-height: 1.6;
    }
  }
}

// 优化result组件整体间距（可选）
:deep(.ant-result) {
  padding: 40px 20px; // 增加整体内边距，避免内容拥挤
}

:deep(.ant-result-extra) {
  margin-top: 32px !important; // 按钮与desc区域拉开间距
}
</style>
