<template>
  <div class="refund-policy-page">
    <!-- 页面头部 -->
    <div class="policy-header">
      <h1 class="policy-title">退款与售后服务政策</h1>
      <p class="policy-desc">下单前请仔细阅读以下条款，您的购买行为将视为同意本政策</p>
    </div>

    <!-- 政策条款列表 -->
    <div class="policy-list">
      <!-- 条款1：自动发货错误处理 -->
      <a-card class="policy-card" hoverable>
        <div class="policy-card__header">
          <div class="policy-badge">1</div>
          <h3 class="policy-card__title">自动发货错误处理</h3>
        </div>
        <div class="policy-card__content">
          <p class="policy-text">
            当自动发货程序出现错误时，查询订单的网页会显示"出现错误"，并且自动将款项原路退回；
            若查询页面显示订单完成（绿色）但订阅/FAT$未到账，请添加上方官方群联系管理员处理。
          </p>
          <a-alert
            type="info"
            message="温馨提示"
            description="请保留订单查询页面截图，便于管理员快速核实处理"
            show-icon
            class="policy-alert mt-2"
          />
        </div>
      </a-card>

      <!-- 条款2：用户名输入错误处理 -->
      <a-card class="policy-card" hoverable>
        <div class="policy-card__header">
          <div class="policy-badge">2</div>
          <h3 class="policy-card__title">用户名输入错误处理</h3>
        </div>
        <div class="policy-card__content">
          <p class="policy-text">
            因购买时论坛用户名输入错误导致订阅错发，不予退款。
          </p>
          <div class="exception-block">
            <h4 class="exception-title">
              <a-icon type="exception" theme="outline" class="exception-icon" />
              例外情况
            </h4>
            <ul class="exception-list">
              <li>购买时输入的用户不存在：系统将自动原路退款；</li>
              <li>输入的错误用户名存在，且FAT/订阅已发货给该用户：不予退款。</li>
            </ul>
          </div>
        </div>
      </a-card>

      <!-- 条款3：订阅叠加相关规定 -->
      <a-card class="policy-card" hoverable>
        <div class="policy-card__header">
          <div class="policy-badge">3</div>
          <h3 class="policy-card__title">订阅叠加相关规定</h3>
        </div>
        <div class="policy-card__content">
          <p class="policy-text">
            因订阅叠加导致订阅未到账，不予退款。
          </p>
          <a-alert
            type="warning"
            message="重要提醒"
            description="FA订阅最多仅可购买1个月，未到期前不可叠加购买"
            show-icon
            class="policy-alert mt-2"
          />
        </div>
      </a-card>

      <!-- 条款4：售后服务范围 -->
      <a-card class="policy-card" hoverable>
        <div class="policy-card__header">
          <div class="policy-badge">4</div>
          <h3 class="policy-card__title">售后服务范围</h3>
        </div>
        <div class="policy-card__content">
          <p class="policy-text">
            一旦订阅/FAT$正常发货至您的账号，我们将不提供任何售后服务。
          </p>
        </div>
      </a-card>

      <!-- 条款5：FAT$手续费说明 -->
      <a-card class="policy-card" hoverable>
        <div class="policy-card__header">
          <div class="policy-badge">5</div>
          <h3 class="policy-card__title">FAT$手续费说明</h3>
        </div>
        <div class="policy-card__content">
          <div class="question-block">
            <a-icon type="question-circle" theme="outline" class="question-icon" />
            <p class="question-text">"我买了10个FAT，为什么只到账9个FAT？"</p>
          </div>
          <p class="policy-text mt-3">
            此类问题不予退款。商品页已明确标注"10%FAT$手续费请自行承担！"，该手续费为FA官方限制，无法取消。
          </p>
          <a-alert
            type="success"
            message="10%手续费计算方式"
            description="实际到账数量 = 四舍五入(购买FAT数量 × 90%)"
            show-icon
            class="policy-alert mt-2"
          />
        </div>
      </a-card>
    </div>

    <!-- 页面底部 -->
    <div class="policy-footer">
      <a-divider />
      <p class="footer-text">
        <a-icon type="exclamation-circle" theme="outline" class="footer-icon" />
        如有其他疑问，可在购买前联系客服咨询，感谢您的理解与支持！
      </p>
    </div>
  </div>
</template>



<style lang="less" scoped>
// 全局页面样式
.refund-policy-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px 20px 40px;
  background-color: #f5f7fa;
  border-radius: 8px;
  min-height: calc(100vh - 72px);
  font-family: 'PingFang SC', 'Microsoft YaHei', sans-serif;
}

// 头部样式
.policy-header {
  text-align: center;
  margin-bottom: 40px;

  .policy-title {
    font-size: 32px;
    font-weight: 600;
    color: #1890ff;
    margin: 0 0 12px 0;
  }

  .policy-desc {
    font-size: 16px;
    color: #666;
    margin: 0;
  }
}

// 条款列表样式
.policy-list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
  gap: 24px;
  margin-bottom: 40px;
}

// 单个条款卡片样式
.policy-card {
  border-radius: 12px !important;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05) !important;
  transition: all 0.3s ease !important;
  overflow: hidden;

  &:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08) !important;
  }

  &__header {
    display: flex;
    align-items: center;
    padding: 16px 24px;
    background-color: #e8f4ff;
    border-bottom: 1px solid #f0f7ff;

    // 自定义数字徽章（替代原ABadge，解决拉伸/蓝底问题）
    .policy-badge {
      width: 28px;
      height: 28px;
      border-radius: 50%; // 确保圆形不拉伸
      background-color: #1890ff !important;
      color: #fff;
      font-size: 14px;
      font-weight: 500;
      line-height: 28px; // 垂直居中
      text-align: center;
      flex-shrink: 0; // 防止压缩变形
      margin-right: 12px !important;
    }

    &__title {
      font-size: 18px;
      font-weight: 600;
      color: #1890ff;
      margin: 0;
      flex: 1;
    }
  }

  &__content {
    padding: 24px;

    .policy-text {
      font-size: 15px;
      color: #333;
      line-height: 1.8;
      margin: 0;
    }

    .policy-alert {
      border-radius: 8px !important;
      border: none !important; // 去掉alert默认边框
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06) !important;
    }
  }
}

// 例外情况区块样式
.exception-block {
  margin-top: 16px;
  padding: 16px;
  background-color: #faf0f5;
  border-radius: 8px;

  .exception-title {
    display: flex;
    align-items: center;
    font-size: 16px;
    font-weight: 600;
    color: #eb2f96;
    margin: 0 0 8px 0;

    .exception-icon {
      color: #eb2f96;
      margin-right: 8px;
      font-size: 18px;
      flex-shrink: 0;
    }
  }

  .exception-list {
    margin: 0;
    padding-left: 24px;
    color: #666;
    line-height: 1.8;

    li {
      margin-bottom: 4px;
    }
  }
}

// 问题区块样式
.question-block {
  padding: 12px 16px;
  background-color: #f0f8ff;
  border-radius: 8px;
  display: flex;
  align-items: flex-start;

  .question-icon {
    color: #1890ff;
    font-size: 18px;
    margin-right: 8px;
    margin-top: 2px;
    flex-shrink: 0;
  }

  .question-text {
    margin: 0;
    color: #333;
    font-size: 15px;
    line-height: 1.6;
    flex: 1;
  }
}

// 底部样式
.policy-footer {
  text-align: center;

  .footer-text {
    font-size: 15px;
    color: #666;
    margin: 16px 0 0 0;

    .footer-icon {
      color: #faad14;
      margin-right: 8px;
      flex-shrink: 0;
    }
  }
}

// 响应式适配
@media (max-width: 768px) {
  .policy-list {
    grid-template-columns: 1fr;
  }

  .policy-header .policy-title {
    font-size: 26px;
  }

  .policy-card__content {
    padding: 16px;
  }

  .policy-card__header .policy-badge {
    width: 24px;
    height: 24px;
    line-height: 24px;
    font-size: 12px;
  }
}

// 通用间距类
.mt-2 {
  margin-top: 8px;
}

.mt-3 {
  margin-top: 12px;
}

// 重置antdv默认样式（防止样式穿透）
:deep(.ant-card) {
  border: none !important;
}

:deep(.ant-alert) {
  margin-bottom: 0 !important;
}

:deep(.ant-alert-icon) {
  font-size: 16px !important;
}
</style>