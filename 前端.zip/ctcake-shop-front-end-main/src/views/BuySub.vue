<template>
  <div class="buy-container" v-if="can_buy">
    <div class="buy-panel">
      <!-- 顶部装饰与标题区 -->
      <div class="buy-panel__header">
        <div class="header-decoration"></div>
        <h2 class="buy-panel__title">Fatality.win 30天续费</h2>
        <div class="buy-panel__subtitle">发货服务器:{{ server }}</div>
      </div>

      <!-- 主体内容区 -->
      <div class="buy-panel__body">
        <!-- 价格展示卡片 -->
        <div class="price-card">
          <div class="price-row">
            <div v-if="isSaleActive" class="original-price">¥{{ originalSubPrice.toFixed(2) }}</div>
            <div class="current-price">
              <span class="price-symbol">¥</span>
              <span class="price-number">{{ currentDisplayPrice }}</span>
              <span class="price-unit">/ 30天</span>
            </div>
          </div>
          <div v-if="isSaleActive" class="price-tag">限时优惠</div>
        </div>

        <!-- 用户名输入框 -->
        <a-form-item label="论坛用户名" class="username-form-item">
          <a-input v-model:value="username" placeholder="请输入您的论坛用户名" size="large" :maxlength="50" show-count
            :status="usernameStatus" @input="checkUsername">
            <template #prefix>
              <UserOutlined class="input-icon" />
            </template>
          </a-input>
          <div v-if="usernameStatus === 'error'" class="error-tip">
            <ExclamationCircleOutlined /> 用户名不能为空
          </div>
        </a-form-item>

        <!-- 权益说明 -->
        <div class="benefits-list">
          <p class="benefits-title">卡网优势</p>
          <ul>
            <li>
              <CheckCircleOutlined /> 全自动发货
            </li>
            <li>
              <CheckCircleOutlined /> 发货完成后可查看发货截图
            </li>
            <li>
              <CheckCircleOutlined /> 支持输错用户名自动退款(遵循<RouterLink to="/agreement-refund" class="agreement-link">退款准则
              </RouterLink>)
            </li>
          </ul>
        </div>
      </div>

      <!-- 底部操作区 -->
      <div class="buy-panel__footer">
        <div class="payment-notice">
          <InfoCircleOutlined /> 支付成功后系统将自动为您续费
        </div>


        <!-- 支付按钮组 -->
        <div class="payment-buttons">
          <a-button type="primary" size="large" class="payment-btn wechat-btn" @click="handlePayment('wechat')"
            :loading="paymentLoading">
            <template #icon>
              <WechatOutlined class="btn-icon" />
            </template>
            微信支付
          </a-button>

          <a-button type="primary" size="large" class="payment-btn alipay-btn" @click="handlePayment('alipay')"
            :loading="paymentLoading">
            <template #icon>
              <AlipayOutlined class="btn-icon" />
            </template>
            支付宝
          </a-button>
        </div>

        <!-- 测试商品按钮 -->
        <!-- <div class="test-section">
          <h3>测试功能</h3>
          <p>需要测试支付流程？购买0.01元测试商品快速体验</p>
          <a-button @click="buyTestProduct('wechat')" size="large" class="test-btn wechat-test-btn">
            <template #icon>
              <WechatOutlined class="btn-icon" />
            </template>
            微信支付测试商品 ¥0.01
          </a-button>
          <a-button @click="buyTestProduct('alipay')" size="large" class="test-btn alipay-test-btn">
            <template #icon>
              <AlipayOutlined class="btn-icon" />
            </template>
            支付宝支付测试商品 ¥0.01
          </a-button>
        </div> -->

        <!-- 协议提示 -->
        <div class="agreement-tip">
          点击支付即表示您同意
          <RouterLink to="/agreement-refund" class="agreement-link">退款准则</RouterLink>
        </div>
      </div>
    </div>
  </div>

  <div v-else>
    <a-card hoverable class="check-card" v-if="!error">
      <a-result title="正在检查发货服务器状态...">
        <template #icon>
          <LoadingOutlined />
        </template>
        <template #extra>
          <p>正在检查发货服务器状态，检查完成后即可购买。发货服务器不正常将无法发货。</p>
        </template>
      </a-result>
    </a-card>

    <a-result status="error" title="失败" sub-title="检查发货服务器时出现错误" v-if="error">


      <template #extra>
        <div class="desc">
          <p style="font-size: 16px">
            <close-circle-outlined style="margin-right: 5px;" />{{ error_msg }}
          </p>
        </div>
        <routerLink to="/"><a-button type="primary">返回</a-button></routerLink>
      </template>
    </a-result>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue';
import { useRouter, useRoute } from 'vue-router';
import { message } from 'ant-design-vue';
import {
  UserOutlined,
  ExclamationCircleOutlined,
  CheckCircleOutlined,
  InfoCircleOutlined,
  WechatOutlined,
  AlipayOutlined,
  LoadingOutlined,
  CloseCircleOutlined
} from '@ant-design/icons-vue';
import axios from 'axios';
import FingerprintJS from '@fingerprintjs/fingerprintjs';

const router = useRouter();
const wallet_fat = ref(0);
// 动态价格和优惠相关变量
const subPrice = ref(198.0); // 默认价格
const originalSubPrice = ref(198.0); // 原始价格
const saleSubPrice = ref(0.0); // 优惠价格
const isSaleActive = ref(false); // 是否在优惠期间
const saleFatRequired = ref(288); // 优惠所需FAT数量

// 当前显示价格的计算属性
const currentDisplayPrice = computed(() => {
  return isSaleActive.value && saleSubPrice.value > 0 ? saleSubPrice.value : subPrice.value;
});

// 获取价格设置
const fetchPriceSettings = async () => {
  try {
    const response = await axios.get('/api/theme-settings');
    if (response.data.sub_price !== undefined) {
      originalSubPrice.value = response.data.sub_price;
      subPrice.value = response.data.sub_price;
    }
    if (response.data.sale_sub_price !== undefined) {
      saleSubPrice.value = response.data.sale_sub_price;
    }
    if (response.data.is_sale_active !== undefined) {
      isSaleActive.value = response.data.is_sale_active;
    }
    if (response.data.sale_fat_required !== undefined) {
      saleFatRequired.value = response.data.sale_fat_required;
    }
    // 如果在优惠期间且有优惠价格，则使用优惠价格
    if (isSaleActive.value && saleSubPrice.value > 0) {
      subPrice.value = saleSubPrice.value;
    }
  } catch (error) {
    console.error('获取价格设置失败:', error);
    // 如果获取失败，保持默认值
  }
};

// 响应式数据
const username = ref('');
const paymentLoading = ref(false);
const can_buy = ref(false);
const error = ref(false);
const error_msg = ref('');
const server = ref('获取中...');
// 用户名状态校验
const usernameStatus = computed(() => {
  // 已输入且不为空
  if (username.value.trim()) return 'success';
  // 未输入但已触发校验（有值后又清空）
  if (username.value === '') return '';
  // 为空且触发过校验
  return 'error';
});

// 检查用户名
const checkUsername = () => {
  // 仅做状态更新，不主动提示
};

// 计算当前价格（考虑优惠）
const currentPrice = computed(() => {
  if (is_sale_active.value) {
    return currentSettings.value.sale_sub_price.toFixed(2);
  } else {
    return currentSettings.value.sub_price.toFixed(2);
  }
});

// 支付处理函数
const handlePayment = async (type) => {
  // 校验用户名
  if (!username.value.trim()) {
    message.error('请输入有效的论坛用户名');
    return;
  }

  try {
    paymentLoading.value = true;

    // 获取浏览器指纹
    const fp = await FingerprintJS.load();
    const result = await fp.get();
    const browserFingerprint = result.visitorId;

    // 调用后端API创建支付订单
    const response = await axios.post('/api/create-payment', {
      username: username.value,
      payment_method: type, // 'wechat' 或 'alipay'
      browser_fingerprint: browserFingerprint, // 添加浏览器指纹,
      amount: parseFloat(currentDisplayPrice.value), // 实际金额（考虑优惠）
      buy_type: 'sub', // 购买类型为sub
      fat_count: 10 // FAT数量，默认10
    });

    if (response.data.success) {
      // 成功创建支付订单，跳转到等待支付页面
      const paymentUrl = response.data.payment_url;
      const qrcode = response.data.qrcode;
      if (paymentUrl || qrcode) {
       

        // 跳转到等待支付页面，传递订单ID
        router.push(`/buy/waiting?order_id=${response.data.order_id}&method=${type}`);
      } else {
        message.error('获取支付链接失败');
      }
    } else {
      message.error(response.data.error || '支付创建失败');
    }
  } catch (error) {
    console.error('支付请求错误:', error);
    message.error('支付请求失败，请重试');
  } finally {
    paymentLoading.value = false;
  }
};

// 检查订单状态
const checkOrderStatus = async (order_id) => {
  try {
    // 显示支付状态提示
    message.info('正在支付中，请稍候...', 0); // 0表示不自动关闭

    // 轮询订单状态，最多轮询30次（每2秒一次，持续60秒）
    for (let i = 0; i < 30; i++) {
      await new Promise(resolve => setTimeout(resolve, 2000)); // 等待2秒

      const response = await axios.get(`/api/order-status/${order_id}`);

      if (response.data.status === 'paid') {
        // 订单已支付
        message.destroy(); // 关闭之前的消息
        message.success('支付成功！正在为您发货...');

        // 可以在这里添加发货成功后的逻辑，如跳转到成功页面
        setTimeout(() => {
          message.success('续费成功！请返回论坛查看您的订阅状态。');
        }, 2000);

        return; // 退出轮询
      } else if (response.data.status === 'cancelled') {
        // 订单已取消
        message.destroy();
        message.error('支付已取消');
        return;
      }
    }

    // 超时未支付
    message.destroy();
    message.warning('支付超时，请重新尝试支付');
  } catch (error) {
    console.error('检查订单状态错误:', error);
    message.destroy();
    message.error('检查订单状态失败');
  }
};


// 处理支付回调URL参数
const handlePaymentCallback = () => {
  const route = useRoute();
  const tradeStatus = route.query.trade_status;
  const tradeNo = route.query.trade_no;
  const outTradeNo = route.query.out_trade_no;
  const type = route.query.type;
  const money = route.query.money;

  // 检查是否为支付回调
  if (tradeStatus && tradeNo && outTradeNo && type && money !== undefined) {
    if (tradeStatus === 'TRADE_SUCCESS') {
      // 支付成功，跳转到结果页面
      message.success('支付成功！');
      router.push({
        path: '/buy/result',
        query: {
          order_id: outTradeNo, // 使用 out_trade_no 作为订单ID
          status: 'paid',
          trade_no: tradeNo,
          type: type,
          money: money
        }
      });
    } else {
      // 其他状态，跳转到结果页面显示状态
      router.push({
        path: '/buy/result',
        query: {
          order_id: outTradeNo,
          status: tradeStatus.toLowerCase(),
          trade_no: tradeNo,
          type: type,
          money: money
        }
      });
    }
  }
}

// 获取价格和配置设置
const fetchSettings = async () => {
  try {
    const response = await axios.get('/api/theme-settings');
    return response.data;
  } catch (error) {
    console.error('获取设置失败:', error);
    // 返回默认值
    return {
      sub_price: 198.0,
      sale_enabled: 0,
      sale_sub_price: 0.0,
      sale_fat_required: 288
    };
  }
};

const getServerStatus = async () => {
  // 获取当前设置
  const settings = await fetchSettings();
  // 使用优惠所需的FAT数量，如果未开启优惠则使用默认值
  const requiredFat = settings.sale_enabled ? settings.sale_fat_required : 288;
  
  axios.get('/apihvh/status_api.php').then((response) => {
    const balance = Number(response.data.last_sync_balance);
    wallet_fat.value = balance;
    if (balance >= requiredFat) {
      can_buy.value = true;
      server.value = `在线 剩余FAT库存:${response.data.last_sync_balance} (购买需${requiredFat}个FAT)`;
    } else {
      can_buy.value = false;
      message.error(`卡网FAT库存不足，当前库存${response.data.last_sync_balance}个FAT，购买需要${requiredFat}个FAT，请等待补货后再来。`);
      error.value = true;
      let baseErrorMsg = `卡网FAT库存不足，当前库存${response.data.last_sync_balance}个FAT，购买需要${requiredFat}个FAT，请等待补货后再来。`;
      
      if (response.data.msg) {
        error_msg.value = baseErrorMsg + ' 错误信息:' + response.data.msg;
      } else {
        error_msg.value = baseErrorMsg + 'Fat$库存:' + response.data.last_sync_balance;
      }
      server.value = error_msg.value;
    }
  }).catch((e) => {
    can_buy.value = false;
    message.error('发货服务器状态检查失败，暂时无法购买，请稍后再试。');
    error.value = true;
    let baseErrorMsg = '服务器状态检查失败，请稍后再试。';
    if (e.message) {
      error_msg.value = baseErrorMsg + ' 错误信息：' + e.message;
    } else {
      error_msg.value = baseErrorMsg;
    }
  });
}

onMounted(() => {
  // 首先获取价格设置
  fetchPriceSettings();
  
  // 首先检查是否为支付回调
  handlePaymentCallback();
  // 如果不是支付回调，则检查服务器状态
  const route = useRoute();
  if (!route.query.trade_status) {
    getServerStatus();
  }
});
</script>

<style scoped lang="less">
//检测服务器的card
.check-card {
  width: 420px;
  margin: 0 auto;
  margin-top: 30px;
  text-align: center;
  padding: 40px;
  background: #ffffff;
  border-radius: 16px;
  box-shadow:
    0 8px 30px rgba(0, 0, 0, 0.08),
    0 2px 10px rgba(0, 0, 0, 0.04);
  overflow: hidden;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}

.check-card:hover {
  transform: translateY(-4px);
  box-shadow:
    0 12px 40px rgba(0, 0, 0, 0.12),
    0 4px 15px rgba(0, 0, 0, 0.06);
}

// 外层容器 - 渐变背景
.buy-container {
  min-height: 100vh;
  padding: 40px 20px;
  display: flex;
  align-items: center;
  justify-content: center;
}

// 卡片主体 - 精致化设计
.buy-panel {
  width: 420px;
  background: #ffffff;
  border-radius: 20px;
  box-shadow:
    0 10px 40px rgba(0, 0, 0, 0.08),
    0 4px 15px rgba(0, 0, 0, 0.06);
  overflow: hidden;
  position: relative;
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);

  &:hover {
    transform: translateY(-5px);
    box-shadow:
      0 15px 50px rgba(0, 0, 0, 0.15),
      0 6px 20px rgba(0, 0, 0, 0.1);
  }

  // 头部区域 - 增强视觉层次
  &__header {
    text-align: center;
    padding: 35px 24px 25px;
    position: relative;
    background: linear-gradient(135deg, #f8fafc 0%, #eef2f7 100%);

    .header-decoration {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 8px;
      background: linear-gradient(90deg, #07c160 0%, #1677ff 100%);
    }

    .buy-panel__title {
      margin: 0 0 8px 0;
      font-size: 24px;
      font-weight: 700;
      color: #111827;
      letter-spacing: 0.5px;
      background: linear-gradient(135deg, #07c160 0%, #1677ff 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .buy-panel__subtitle {
      margin: 0;
      font-size: 15px;
      color: #6b7280;
      font-weight: 500;
    }
  }

  // 主体内容区
  &__body {
    padding: 0 32px 28px;

    // 价格卡片
    .price-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      margin-bottom: 32px;
      padding: 20px;
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
      border-radius: 16px;
      position: relative;
      border: 1px solid rgba(226, 232, 240, 0.5);

      .price-row {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 10px;
      }

      .original-price {
        font-size: 18px;
        color: #9ca3af;
        text-decoration: line-through;
        display: flex;
        align-items: center;
        height: 1.5em;
      }

      .current-price {
        display: flex;
        align-items: baseline;
      }

      .price-symbol {
        font-size: 22px;
        color: #2563eb;
        margin-right: 4px;
      }

      .price-number {
        font-size: 40px;
        font-weight: 800;
        color: #1d4ed8;
        letter-spacing: -1px;
      }

      .price-unit {
        font-size: 17px;
        color: #475569;
        margin-left: 6px;
      }

      .price-tag {
        position: absolute;
        top: -12px;
        right: 20px;
        background: linear-gradient(135deg, #f59e0b, #d97706);
        color: white;
        font-size: 13px;
        padding: 4px 12px;
        border-radius: 20px;
        font-weight: 600;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      }
    }

    // 用户名输入项
    .username-form-item {
      margin-bottom: 20px;

      :deep(.ant-form-item-label) {
        font-weight: 500;
        color: #374151;
        padding-bottom: 6px;
      }

      :deep(.ant-input) {
        height: 50px;
        border-radius: 12px;
        border: 2px solid #e5e7eb;
        padding: 0 16px;
        font-size: 15px;
        transition: all 0.3s ease;
        background-color: #f9fafb;

        &:hover {
          border-color: #a0aec0;
        }

        &:focus {
          border-color: #1677ff;
          box-shadow: 0 0 0 4px rgba(22, 119, 255, 0.15);
          background-color: #ffffff;
        }
      }

      .input-icon {
        color: #718096;
        font-size: 16px;
      }

      .error-tip {
        margin-top: 8px;
        font-size: 13px;
        color: #e53e3e;
        display: flex;
        align-items: center;
        padding: 6px 10px;
        background-color: #fef2f2;
        border-radius: 6px;
        border-left: 4px solid #e53e3e;

        :deep(.anticon) {
          font-size: 14px;
          margin-right: 6px;
        }
      }
    }

    // 权益列表
    .benefits-list {
      margin-top: 28px;
      padding: 16px;
      background: #f8fafc;
      border-radius: 12px;
      border: 1px solid #e2e8f0;

      .benefits-title {
        margin: 0 0 14px 0;
        font-size: 16px;
        font-weight: 600;
        color: #1e293b;
        display: flex;
        align-items: center;
        gap: 8px;

        :deep(.anticon) {
          color: #0ea5e9;
        }
      }

      ul {
        margin: 0;
        padding-left: 20px;
        list-style: none;

        li {
          margin-bottom: 10px;
          font-size: 14px;
          color: #334155;
          display: flex;
          align-items: center;
          padding: 6px 0;

          :deep(.anticon) {
            color: #10b981;
            margin-right: 10px;
            font-size: 16px;
            background: #ecfdf5;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
          }
        }
      }
    }
  }

  // 底部操作区

  &__footer {

    padding: 28px 32px 36px;

    background: linear-gradient(135deg, #f8fafc 0%, #eef2f7 100%);

    border-top: 1px solid rgba(226, 232, 240, 0.6);



    .payment-notice {

      text-align: center;

      font-size: 14px;

      color: #4b5563;

      margin-bottom: 24px;

      display: flex;

      align-items: center;

      justify-content: center;

      padding: 12px;

      background: #f1f5f9;

      border-radius: 10px;

      border-left: 4px solid #3b82f6;



      :deep(.anticon) {

        font-size: 14px;

        margin-right: 8px;

        color: #2563eb;

      }

    }



    // 支付按钮组

    .payment-buttons {

      display: flex;

      gap: 16px;

      margin-bottom: 20px;



      .payment-btn {

        flex: 1;

        height: 54px;

        border-radius: 14px;

        font-size: 16px;

        font-weight: 600;

        border: none;

        position: relative;

        overflow: hidden;

        transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);

        letter-spacing: 0.5px;



        .btn-icon {

          font-size: 18px;

          margin-right: 8px;

        }



        // 按钮点击波纹效果

        &::after {

          content: '';

          position: absolute;

          top: 50%;

          left: 50%;

          width: 0;

          height: 0;

          background: rgba(255, 255, 255, 0.3);

          border-radius: 50%;

          transform: translate(-50%, -50%);

          transition: width 0.6s ease, height 0.6s ease;

        }



        &:active::after {

          width: 300px;

          height: 300px;

        }



        // 微信按钮

        &.wechat-btn {

          background: linear-gradient(135deg, #10b981 0%, #059669 100%);

          box-shadow: 0 4px 15px rgba(16, 185, 129, 0.3);



          &:hover {

            background: linear-gradient(135deg, #059669 0%, #047857 100%);

            transform: translateY(-3px);

            box-shadow: 0 6px 20px rgba(16, 185, 129, 0.4);

          }



          &:active {

            transform: translateY(0);

            box-shadow: 0 2px 10px rgba(16, 185, 129, 0.3);

          }

        }



        // 支付宝按钮

        &.alipay-btn {

          background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);

          box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);



          &:hover {

            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);

            transform: translateY(-3px);

            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);

          }



          &:active {

            transform: translateY(0);

            box-shadow: 0 2px 10px rgba(59, 130, 246, 0.3);

          }

        }

      }

    }



    // 协议提示







    .agreement-tip {







      text-align: center;







      font-size: 13px;







      color: #64748b;







      padding: 10px;







      background: #f8fafc;







      border-radius: 8px;















      .agreement-link {







        color: #2563eb;







        text-decoration: none;
        margin: 0 4px;
        font-weight: 500;

        &:hover {
          text-decoration: underline;
          color: #1d4ed8;
        }
      }
    }
  }
}

// 响应式适配
@media (max-width: 450px) {
  .buy-panel {
    width: 92%;

    &__body {
      padding: 0 20px 20px;
    }

    &__footer {
      padding: 20px 20px 28px;

      .payment-buttons {
        flex-direction: column;
        gap: 12px;
      }
    }

    .price-card .price-number {
      font-size: 32px;
    }
  }
}

.desc {
  margin: 24px 0 0 0; // 与上方内容拉开间距，匹配antd默认间距规范
  margin-bottom: 15px;
  padding: 16px 20px;
  background-color: #fff2f0; // 错误状态配套浅红背景，贴合antd error色系
  border: 1px solid #ffccc7;
  border-radius: 8px; // 圆角弱化硬朗感
  box-shadow: 0 2px 8px rgba(245, 108, 108, 0.08); // 轻微阴影增强层次感
  max-width: 600px; // 限制宽度，避免文本过长影响阅读
  margin-left: auto;
  margin-right: auto; // 居中显示

  p {
    margin: 0 !important; // 清除默认p标签间距
    font-size: 16px !important;
    color: #f5222d; // antd error主色，突出错误提示
    line-height: 1.8; // 行高优化，提升可读性
    text-align: center; // 文本居中，视觉更规整
    word-break: break-word; // 兼容长文本换行
  }

  // 响应式适配：移动端调整间距和字体
  @media (max-width: 768px) {
    padding: 12px 16px;
    max-width: 100%;

    p {
      font-size: 14px !important;
      line-height: 1.6;
    }
  }
}

// 优化result组件整体间距（可选）
:deep(.ant-result) {
  padding: 40px 20px; // 增加整体内边距，避免内容拥挤
}

:deep(.ant-result-extra) {
  margin-top: 32px !important; // 按钮与desc区域拉开间距
}
</style>