<template>
    <!-- 全局加载遮罩 -->
    <div v-if="showGlobalLoading" class="global-loading-overlay" :class="{ 'fade-out': fadeOutClass }">
      <div class="global-loading-content">
        <a-spin size="large" />
      </div>
    </div>
  
  <div class="app-container" >
    <!-- 全局订单提醒 -->
    <div v-if="showOrderReminder" class="order-reminder">
      <div class="reminder-content">
        <div class="reminder-icon">
          <InfoCircleOutlined />
        </div>
        <div class="reminder-text">
          <!-- <span>您的浏览器有{{ orderCount }}个订单，是否查看？<a @click="goToMyOrdersPage">点击查看</a></span> -->
          <span>由于支付商不给订单退款，所以错付用户名暂时停止退款服务。<a @click="goToMyOrdersPage">历史订单</a></span>
        </div>
        <div class="reminder-close" @click="closeReminder">
          ×
        </div>
      </div>
    </div>
    
    <!-- 全局顶栏 -->
    <div class="global-header">
      <div class="header-content">
        <div class="back-button" @click="goBack" v-if="showBackButton">
          <span class="back-icon">←</span>
          <span class="back-text">返回</span>
        </div>
        <div class="back-button" @click="navigateTo('/')">
          <span class="back-icon"><HomeOutlined /></span>
          <span class="back-text">首页</span>
        </div>
        <h1 class="page-title">{{ currentPageTitle }}</h1>
      </div>
    </div>
     <canvas
      v-if="isChristmas || isNewYear || isHalloween"
      ref="canvasRef"
      class="festival-canvas"
    ></canvas>
    <!-- 路由视图容器 -->
    <div class="router-view-container">
      <RouterView />
    </div>
    
    <!-- 底部导航栏 -->
    <div v-if="showBottomNav" class="bottom-nav">
      <div 
        class="nav-item" 
        :class="{ active: currentRoute === '/' }"
        @click="navigateTo('/')"
      >
        <HomeOutlined />
        <span>首页</span>
      </div>
      <div 
        class="nav-item" 
        :class="{ active: currentRoute === '/query-order' }"
        @click="navigateTo('/query-order')"
      >
        <OrderedListOutlined />
        <span>订单查询</span>
      </div>
      <!--  -->
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, onMounted, onUnmounted, nextTick } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { 
  InfoCircleOutlined, 
  HomeOutlined, 
  OrderedListOutlined,
  SettingOutlined
} from '@ant-design/icons-vue';
import { Spin } from 'ant-design-vue';
import FingerprintJS from '@fingerprintjs/fingerprintjs';
import axios from 'axios';
import { Modal } from 'ant-design-vue';
import { h } from 'vue';
const route = useRoute();
const router = useRouter();
const showDev = ref(true);
const info = () => {
  Modal.info({
    title: 'This is a notification message',
    content: h('div', {}, [
      h('p', '新后端仍在开发测试中，如果您此时在网站进行任何购买都有可能导致异常，如果您非开发人员请暂时不要使用此网站。'),
    ]),
    onOk() {
      console.log('ok');
    },
  });
};
// 全局加载相关
const showGlobalLoading = ref(false);
const loadingText = ref('正在加载页面...');
const fadeOutClass = ref(false); // 控制淡出动画

// 订单提醒相关
const showOrderReminder = ref(false);
const orderCount = ref(0); // 订单数量
const browserFingerprint = ref('');

// 获取当前路由
const currentRoute = computed(() => route.path);

// 底部导航栏显示控制
const showBottomNav = computed(() => {
  return !route.path.includes('/buy/') && 
         route.path !== '/buy/waiting' && 
         route.path !== '/buy/result' && 
         route.path !== '/order-status' && 
         route.path !== '/my-orders';
});

// 管理导航显示控制
const showAdminNav = computed(() => {
  // 只在首页显示管理入口，便于管理员访问
  return route.path === '/';
});

// 监听路由守卫事件
const handleRouteChangeStart = () => {
  fadeOutClass.value = false; // 重置淡出类
  showGlobalLoading.value = true;
};

const handleRouteChangeEnd = () => {
  // 先触发动画淡出
  fadeOutClass.value = true;
  
  // 在动画结束后真正隐藏加载遮罩
  setTimeout(() => {
    showGlobalLoading.value = false;
    fadeOutClass.value = false; // 重置淡出类以备下次使用
  }, 300); // 与CSS中的过渡时间保持一致
};

onMounted(() => {
  window.addEventListener('route-change-start', handleRouteChangeStart);
  window.addEventListener('route-change-end', handleRouteChangeEnd);

  // 应用主题设置
  applyThemeSettings();

  // 页面加载时检查订单
  if (!route.path.includes('/my-orders') && !route.path.includes('/order-status')) {
    checkUserOrder();
  }

  if (showDev.value) {
    info();
  }
});

onUnmounted(() => {
  window.removeEventListener('route-change-start', handleRouteChangeStart);
  window.removeEventListener('route-change-end', handleRouteChangeEnd);
  stop();
});



// 获取浏览器指纹
const getBrowserFingerprint = async () => {
  const fp = await FingerprintJS.load();
  const result = await fp.get();
  return result.visitorId;
};
const currentSettings = ref({
  theme: 'normal'
})
// 获取并应用主题设置
const applyThemeSettings = async () => {
  try {
    const response = await axios.get('/api/theme-settings');
    const { theme, fat_price, sub_price } = response.data;
    console.log('主题设置:', theme);
    currentSettings.value.theme = theme;
    // 应用主题
    document.body.setAttribute('data-theme', theme);
    switch (theme) {
      case 'normal':
        document.body.classList.remove('theme-christmas', 'theme-halloween', 'theme-newyear');
        document.body.classList.add('theme-normal');
        break;
      case 'christmas':
        document.body.classList.remove('theme-normal', 'theme-halloween', 'theme-newyear');
        document.body.classList.add('theme-christmas');
        break;
      case 'halloween':
        document.body.classList.remove('theme-normal', 'theme-christmas', 'theme-newyear');
        document.body.classList.add('theme-halloween');
        break;
      case 'newyear':
        document.body.classList.remove('theme-normal', 'theme-christmas', 'theme-halloween');
        document.body.classList.add('theme-newyear');
        break;
    }
  } catch (error) {
    console.error('获取主题设置失败:', error);
    // 检查是否有响应数据
    if (error.response) {
      console.error('服务器返回错误:', error.response.data);
    } else if (error.request) {
      console.error('无法连接到服务器:', error.request);
    } else {
      console.error('请求配置错误:', error.message);
    }
  }
};

// 检查用户的订单状态
const checkUserOrder = async () => {
  try {
    // 获取浏览器指纹
    browserFingerprint.value = await getBrowserFingerprint();
    
    // 向后端查询该浏览器指纹的订单
    const response = await axios.post('/api/orders-by-fingerprint', {
      browser_fingerprint: browserFingerprint.value
    });
    
    // 检查是否有订单
    if (response.data.all_orders && response.data.all_orders.length > 0) {
      orderCount.value = response.data.all_orders.length;
      // 显示提醒：您的浏览器有被保存过的订单，是否查看？
      showOrderReminder.value = true;
    }
  } catch (error) {
    console.error('检查用户订单失败:', error);
  }
};

// 关闭提醒
const closeReminder = () => {
  showOrderReminder.value = false;
};

// 前往我的订单页面
const goToMyOrdersPage = () => {
  router.push('/my-orders');
  showOrderReminder.value = false;
};

// 导航到底部导航栏的页面
const navigateTo = (path) => {
  router.push(path);
};

// 获取当前页面标题
const currentPageTitle = computed(() => {
  const routeMap = {
    '/': '首页',
    '/buy/fat': 'FAT$购买',
    '/buy/sub': 'FA续费购买',
    '/agreement-refund': '退款协议',
    '/query-order': '订单查询'
  };
  return routeMap[route.path] || '页面';
});

// 根据路由决定过渡动画类型
const routeTransitionName = computed(() => {
  const transitions = {
    '/': 'fade-slide', // 首页使用滑动效果
    '/buy/fat': 'zoom', // FAT$购买使用缩放效果
    '/buy/sub': 'flip', // FA续费使用翻转效果
    '/agreement-refund': 'fade-slide', // 退款协议使用滑动效果
    '/query-order': 'fade-slide' // 查询订单使用滑动效果
  };
  return transitions[route.path] || 'fade-slide';
});

// 判断是否显示返回按钮
const showBackButton = computed(() => {
  return route.path !== '/' && route.path !== '/query-order';
});

// 返回上一页
const goBack = () => {
  router.go(-1);
};

// 监听路由变化
watch(() => route.path, (newPath) => {
  // 在非订单页面显示订单提醒
  if (!newPath.includes('/my-orders') && !newPath.includes('/order-status')) {
    checkUserOrder();
  } else {
    // 在订单相关页面隐藏提醒
    showOrderReminder.value = false;
  }
}, { immediate: true });


const isChristmas = computed(() => currentSettings.value.theme === 'christmas')
const isNewYear = computed(() => currentSettings.value.theme === 'newyear')
const isHalloween = computed(() => currentSettings.value.theme === 'halloween')

const canvasRef = ref(null)
let ctx
let rafId

const snowflakes = [] // 圣诞雪花
const clickParticles = [] // 点击粒子
const lightParticles = [] // 元旦上升光点
const lanterns = [] // 元旦灯笼
const halloweenParticles = [] // 万圣节粒子
const halloweenLanterns = [] // 万圣节灯笼

// ---------- 圣诞参数 ----------
const SNOW_COUNT = 160
const SNOW_SPEED_MIN = 0.5
const SNOW_SPEED_MAX = 1.2

// ---------- 元旦参数 ----------
const LIGHT_COUNT = 112 // 比圣诞少 30%
const LIGHT_SPEED_MIN = 0.3 // 比雪慢 40%
const LIGHT_SPEED_MAX = 0.72
const LANTERN_COUNT = 3 // 灯笼数量减少到 3 个

// ---------- 万圣节参数 ----------
const HALLOWEEN_COUNT = 30
const HALLOWEEN_SPEED_MIN = 0.6
const HALLOWEEN_SPEED_MAX = 1.5
const HALLOWEEN_LANTERN_COUNT = 2

function resize() {
  const canvas = canvasRef.value
  if (!canvas) {
    console.log('resize(): canvas 元素不存在');
    return
  }

  const w = window.innerWidth
  const h = window.innerHeight

  canvas.width = w
  canvas.height = h

  ctx = canvas.getContext('2d')
  console.log('resize(): Canvas 初始化完成', w, 'x', h);
}

function createSnowflake(y = Math.random() * window.innerHeight) {
  return {
    x: Math.random() * window.innerWidth,
    y,
    r: Math.random() * 1.5 + 0.5,
    vy: Math.random() * (SNOW_SPEED_MAX - SNOW_SPEED_MIN) + SNOW_SPEED_MIN
  }
}

function createLightParticle(y = window.innerHeight + Math.random() * 100) {
  // 元旦上升光点：冷白/淡蓝
  const isSpecial = Math.random() < 0.2 // 20% 概率是白色
  return {
    x: Math.random() * window.innerWidth,
    y,
    r: Math.random() * 0.7 + 0.5, // 0.5 - 1.2px
    vy: Math.random() * (LIGHT_SPEED_MAX - LIGHT_SPEED_MIN) + LIGHT_SPEED_MIN,
    vx: (Math.random() - 0.5) * 0.3, // 轻微左右摆动
    color: isSpecial ? 'rgba(255,255,255,0.8)' : 'rgba(200,220,255,0.6)'
  }
}

function createLantern(y = window.innerHeight + Math.random() * 300) {
  return {
    x: Math.random() * window.innerWidth,
    y,
    vy: Math.random() * 0.25 + 0.15, // 更慢的上升速度
    vx: (Math.random() - 0.5) * 0.15, // 更小的左右摆动
    size: Math.random() * 20 + 40, // 40-60px
    opacity: Math.random() * 0.2 + 0.6 // 0.6-0.8
  }
}

function createHalloweenParticle(y = Math.random() * window.innerHeight) {
  // 万圣节粒子：蝙蝠、幽灵、小南瓜
  const types = ['🦇', '👻', '🎃']
  const type = types[Math.floor(Math.random() * types.length)]
  return {
    x: Math.random() * window.innerWidth,
    y,
    type,
    size: Math.random() * 15 + 20, // 20-35px
    vy: Math.random() * (HALLOWEEN_SPEED_MAX - HALLOWEEN_SPEED_MIN) + HALLOWEEN_SPEED_MIN,
    vx: (Math.random() - 0.5) * 1.5, // 左右摆动更明显
    rotation: Math.random() * Math.PI * 2,
    rotationSpeed: (Math.random() - 0.5) * 0.1
  }
}

function createHalloweenLantern(y = Math.random() * window.innerHeight) {
  return {
    x: Math.random() * window.innerWidth,
    y,
    vy: Math.random() * 0.4 + 0.3,
    vx: (Math.random() - 0.5) * 0.3,
    size: Math.random() * 20 + 50, // 50-70px
    opacity: Math.random() * 0.3 + 0.6
  }
}

function initSnow() {
  snowflakes.length = 0
  for (let i = 0; i < SNOW_COUNT; i++) {
    snowflakes.push(createSnowflake())
  }
  console.log('initSnow(): 已创建', snowflakes.length, '个雪花');
}

function initLights() {
  lightParticles.length = 0
  lanterns.length = 0
  for (let i = 0; i < LIGHT_COUNT; i++) {
    lightParticles.push(createLightParticle())
  }
  for (let i = 0; i < LANTERN_COUNT; i++) {
    lanterns.push(createLantern())
  }
  console.log('initLights(): 已创建', lightParticles.length, '个光点,', lanterns.length, '个灯笼');
}

function initHalloween() {
  halloweenParticles.length = 0
  halloweenLanterns.length = 0
  for (let i = 0; i < HALLOWEEN_COUNT; i++) {
    halloweenParticles.push(createHalloweenParticle())
  }
  for (let i = 0; i < HALLOWEEN_LANTERN_COUNT; i++) {
    halloweenLanterns.push(createHalloweenLantern())
  }
  console.log('initHalloween(): 已创建', halloweenParticles.length, '个粒子,', halloweenLanterns.length, '个灯笼');
}

function addClickParticles(x, y) {
  console.log('addClickParticles(): 添加粒子，当前粒子数:', clickParticles.length);
  for (let i = 0; i < 10; i++) {
    const angle = (Math.PI * 2 * i) / 10
    clickParticles.push({
      x,
      y,
      vx: Math.cos(angle) * 2,
      vy: Math.sin(angle) * 2,
      life: 20
    })
  }
  console.log('addClickParticles(): 添加后粒子数:', clickParticles.length);
}

function update() {
  if (!ctx) return

  ctx.clearRect(0, 0, canvasRef.value.width, canvasRef.value.height)

  // --- 圣诞雪花 ---
  if (isChristmas.value) {
    ctx.fillStyle = '#fff'
    snowflakes.forEach(f => {
      f.y += f.vy
      if (f.y > window.innerHeight) {
        f.y = -5
        f.x = Math.random() * window.innerWidth
      }
      ctx.beginPath()
      ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2)
      ctx.fill()
    })
  }

  // --- 元旦上升光点 ---
  if (isNewYear.value) {
    lightParticles.forEach(p => {
      p.y -= p.vy // 向上飘
      p.x += p.vx // 轻微左右摆动
      if (p.y < -10) {
        p.y = window.innerHeight + 10
        p.x = Math.random() * window.innerWidth
      }
      ctx.fillStyle = p.color
      ctx.beginPath()
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2)
      ctx.fill()
    })

    // --- 元旦灯笼 ---
    lanterns.forEach(l => {
      l.y -= l.vy
      l.x += l.vx
      if (l.y < -50) {
        l.y = window.innerHeight + 50
        l.x = Math.random() * window.innerWidth
      }
      
      // 先绘制光圈（在灯笼后面）
      ctx.save()
      ctx.globalAlpha = l.opacity * 0.4
      const gradient = ctx.createRadialGradient(l.x, l.y, 0, l.x, l.y, l.size * 1.8)
      gradient.addColorStop(0, 'rgba(96, 165, 250, 0.6)')
      gradient.addColorStop(0.5, 'rgba(96, 165, 250, 0.2)')
      gradient.addColorStop(1, 'rgba(96, 165, 250, 0)')
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(l.x, l.y, l.size * 1.8, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
      
      // 绘制灯笼 emoji
      ctx.save()
      ctx.globalAlpha = l.opacity
      ctx.font = `${l.size}px Arial`
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillText('🏮', l.x, l.y)
      ctx.restore()
    })
  }

// --- 万圣节特效 ---
  if (isHalloween.value) {
    // 万圣节粒子（蝙蝠、幽灵、南瓜等）
    halloweenParticles.forEach(p => {
      p.y += p.vy // 从上到下
      p.x += p.vx // 左右摆动
      p.rotation += p.rotationSpeed // 旋转
      if (p.y > window.innerHeight + 50) {
        p.y = -50
        p.x = Math.random() * window.innerWidth
      }
      ctx.save()
      ctx.globalAlpha = 0.8
      ctx.font = `${p.size}px Arial`
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.translate(p.x, p.y)
      ctx.rotate(p.rotation)
      ctx.fillText(p.type, 0, 0)
      ctx.restore()
    })

    // 万圣节灯笼（南瓜灯）
    halloweenLanterns.forEach(l => {
      l.y += l.vy
      l.x += l.vx
      if (l.y > window.innerHeight + 70) {
        l.y = -70
        l.x = Math.random() * window.innerWidth
      }
      
      // 光圈（万圣节橙色）
      ctx.save()
      ctx.globalAlpha = l.opacity * 0.4
      const gradient = ctx.createRadialGradient(l.x, l.y, 0, l.x, l.y, l.size * 1.8)
      gradient.addColorStop(0, 'rgba(255, 140, 0, 0.6)')
      gradient.addColorStop(0.5, 'rgba(255, 140, 0, 0.2)')
      gradient.addColorStop(1, 'rgba(255, 140, 0, 0)')
      ctx.fillStyle = gradient
      ctx.beginPath()
      ctx.arc(l.x, l.y, l.size * 1.8, 0, Math.PI * 2)
      ctx.fill()
      ctx.restore()
      
      // 万圣节灯笼 emoji
      ctx.save()
      ctx.globalAlpha = l.opacity
      ctx.font = `${l.size}px Arial`
      ctx.textAlign = 'center'
      ctx.textBaseline = 'middle'
      ctx.fillText('🎃', l.x, l.y)
      ctx.restore()
    })
  }

  // --- 点击粒子 ---
  clickParticles.forEach(p => {
    p.x += p.vx
    p.y += p.vy
    p.life--
    const alpha = p.life / 20 // 根据生命周期设置透明度
    ctx.save()
    ctx.fillStyle = `rgba(255, 182, 193, ${alpha})` // 粉色粒子
    ctx.beginPath()
    ctx.arc(p.x, p.y, 2.5, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  })

  // 清理死亡粒子
  for (let i = clickParticles.length - 1; i >= 0; i--) {
    if (clickParticles[i].life <= 0) {
      clickParticles.splice(i, 1)
    }
  }

  rafId = requestAnimationFrame(update)
}

// ---------- 生命周期 ----------
function start() {
  console.log('start() 被调用，当前主题:', currentSettings.value.theme);
  resize();
  
  if (isChristmas.value) {
    initSnow();
  } else if (isNewYear.value) {
    initLights();
  } else if (isHalloween.value) {
    initHalloween();
  }
  
  update();
  window.addEventListener('resize', resize);
  window.addEventListener('click', handleClick);
  console.log('特效已启动');
}

function stop() {
  cancelAnimationFrame(rafId);
  window.removeEventListener('resize', resize);
  window.removeEventListener('click', handleClick);
  snowflakes.length = 0;
  clickParticles.length = 0;
  lightParticles.length = 0;
  lanterns.length = 0;
  halloweenParticles.length = 0;
  halloweenLanterns.length = 0;
  console.log('特效已停止');
}

function handleClick(e) {
  console.log('handleClick(): 点击位置', e.clientX, e.clientY);
  addClickParticles(e.clientX, e.clientY);
}

watch(isChristmas, (newVal) => {
  console.log('isChristmas 变化:', newVal, '当前主题:', currentSettings.value.theme);
  if (newVal) {
    // 圣诞主题，启动特效
    if (!rafId) { // 避免重复启动
      console.log('启动圣诞特效');
      // 使用 nextTick 确保 DOM 已更新后再启动特效
      nextTick(() => {
        start();
      });
    }
  } else if (!isNewYear.value) {
    // 非圣诞且非元旦主题，停止特效
    console.log('停止特效');
    stop();
  }
});

watch(isNewYear, (newVal) => {
  console.log('isNewYear 变化:', newVal, '当前主题:', currentSettings.value.theme);
  if (newVal) {
    // 元旦主题，启动特效
    if (!rafId) { // 避免重复启动
      console.log('启动元旦特效');
      // 使用 nextTick 确保 DOM 已更新后再启动特效
      nextTick(() => {
        start();
      });
    }
  } else if (!isChristmas.value) {
    // 非元旦且非圣诞主题，停止特效
    console.log('停止特效');
    stop();
  }
});

watch(isHalloween, (newVal) => {
  console.log('isHalloween 变化:', newVal, '当前主题:', currentSettings.value.theme);
  if (newVal) {
    // 万圣节主题，启动特效
    if (!rafId) { // 避免重复启动
      console.log('启动万圣节特效');
      // 使用 nextTick 确保 DOM 已更新后再启动特效
      nextTick(() => {
        start();
      });
    }
  } else if (!isChristmas.value && !isNewYear.value) {
    // 非万圣节且非圣诞且非元旦主题，停止特效
    console.log('停止特效');
    stop();
  }
});

</script>

<style scoped>
.app-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* 订单提醒样式 */
.order-reminder {
  position: fixed;
  top: 70px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 10000;
  width: 90%;
  max-width: 500px;
}

.reminder-content {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  background: #fffbe6;
  border: 1px solid #ffe58f;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.reminder-icon {
  color: #faad14;
  font-size: 16px;
  margin-right: 10px;
}

.reminder-text {
  flex: 1;
  font-size: 14px;
  color: #6b7280;
}

.reminder-text a {
  color: #1890ff;
  cursor: pointer;
  text-decoration: underline;
}

.reminder-close {
  font-size: 18px;
  cursor: pointer;
  color: #9ca3af;
}

.reminder-close:hover {
  color: #6b7280;
}

.global-header {
  background: linear-gradient(135deg, #1677ff 0%, #096dd9 100%);
  color: white;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  position: sticky;
  top: 0;
  z-index: 1000;
}

.header-content {
  max-width: 1200px;
  margin: 0 auto;
  padding: 16px 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.back-button {
  display: flex;
  align-items: center;
  cursor: pointer;
  padding: 8px 12px;
  border-radius: 6px;
  background: rgba(255, 255, 255, 0.15);
  transition: all 0.3s ease;
  margin-right: 10px;
}

.back-button:hover {
  background: rgba(255, 255, 255, 0.25);
  transform: translateY(-1px);
}

.back-icon {
  font-size: 18px;
  margin-right: 6px;
}

.back-text {
  font-size: 14px;
  font-weight: 500;
}

.page-title {
  margin: 0;
  font-size: 18px;
  font-weight: 600;
  flex: 1;
  text-align: center;
  letter-spacing: 0.5px;
}

.router-view-container {
  flex: 1;
  padding: 20px 0;
 
  min-height: calc(100vh - 132px); /* 减去头部和底部导航的高度 */
  position: relative;
  overflow: hidden;
}

/* 底部导航栏样式 */
.bottom-nav {
  display: flex;
  justify-content: space-around;
  align-items: center;
  height: 60px;
  background: rgba(255, 255, 255, 0.2);
  /* border-top: 1px solid #e5e7eb; */
  backdrop-filter: blur(10px);
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.05);
  position: sticky;
  bottom: 0;
  z-index: 1000;
}

.nav-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  flex: 1;
  height: 100%;
  cursor: pointer;
  transition: all 0.3s ease;
  color: #6b7280;
  font-size: 12px;
  padding: 5px 0;
}

.nav-item.active {
  color: #1677ff;
  background: linear-gradient()

}

.nav-item:hover {
  background: #f8fafc;
}

.nav-item.active:hover {
  background: #e6f4ff;
}

.nav-item svg {
  font-size: 18px;
  margin-bottom: 2px;
}

/* 全局加载遮罩样式 */
.global-loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: transparent;
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  backdrop-filter: blur(5px);
  opacity: 1;
  transition: opacity 0.3s ease;
}

.global-loading-overlay.fade-out {
  opacity: 0;
  pointer-events: none;
}

.global-loading-content {
  text-align: center;
  padding: 40px;
  border-radius: 16px;
  backdrop-filter: blur(10px);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  border: 1px solid rgba(226, 232, 240, 0.3);
}

.global-loading-overlay :deep(.ant-spin) {
  margin: 0 auto;
}

.global-loading-overlay :deep(.ant-spin-text) {
  color: #1f2937;
  margin-top: 16px;
  font-size: 16px;
  font-weight: 500;
}
.festival-canvas {
  position: fixed;
  inset: 0;
  z-index: 99999999; /* 在背景之上，在内容之下 */
  pointer-events: none;
}
.loading-hidden {
  visibility: hidden;
}

/* 创意路由切换动画 */
    .fade-slide-enter-active {
      transition: all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
      z-index: 1;
    }

    .fade-slide-leave-active {
      transition: all 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      z-index: 0;
    }

    .fade-slide-enter-from {
      opacity: 0;
      transform: translateX(50px) scale(0.95);
      filter: blur(4px);
    }

    .fade-slide-leave-to {
      opacity: 0;
      transform: translateX(-50px) scale(1.05);
      filter: blur(4px);
    }
    
    /* 页面缩放进入动画 */
    .zoom-enter-active {
      animation: zoomIn 0.45s cubic-bezier(0.34, 1.56, 0.64, 1);
    }
    
    .zoom-leave-active {
      animation: zoomOut 0.35s ease-in-out;
    }
    
    @keyframes zoomIn {
      0% {
        opacity: 0;
        transform: scale(0.9) translateY(20px);
      }
      60% {
        opacity: 1;
        transform: scale(1.02) translateY(-5px);
      }
      100% {
        opacity: 1;
        transform: scale(1) translateY(0);
      }
    }
    
    @keyframes zoomOut {
      0% {
        opacity: 1;
        transform: scale(1) translateY(0px);
      }
      100% {
        opacity: 0;
        transform: scale(0.95) translateY(15px);
      }
    }
    
    /* 页面翻转动画 */
    .flip-enter-active {
      animation: flipIn 0.6s ease-out;
    }
    
    .flip-leave-active {
      animation: flipOut 0.5s ease-in;
    }
    
    @keyframes flipIn {
      0% {
        transform: perspective(400px) rotateY(90deg);
        opacity: 0;
      }
      40% {
        transform: perspective(400px) rotateY(-10deg);
      }
      70% {
        transform: perspective(400px) rotateY(10deg);
      }
      100% {
        transform: perspective(400px) rotateY(0deg);
        opacity: 1;
      }
    }
    
    @keyframes flipOut {
      0% {
        transform: perspective(400px) rotateY(0deg);
        opacity: 1;
      }
      100% {
        transform: perspective(400px) rotateY(-90deg);
        opacity: 0;
      }
    }
    
    /* 节日主题特效 */
    
    /* 圣诞主题雪花特效 */
    .theme-christmas {
      overflow: hidden;
    }
    
    .snowflake {
      position: fixed;
      top: -20px;
      color: #fff;
      font-size: 1em;
      text-shadow: 0 0 5px #fff;
      user-select: none;
      z-index: 9999;
      pointer-events: none;
    }
    
    /* 万圣节主题特效 */
    .theme-halloween {
      filter: hue-rotate(10deg) saturate(1.5);
    }
    
    .theme-halloween::before {
      content: "";
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: 
        radial-gradient(rgba(255, 100, 0, 0.1) 1px, transparent 1px),
        radial-gradient(rgba(255, 200, 0, 0.05) 1px, transparent 1px);
      background-size: 60px 60px;
      background-position: 0 0, 30px 30px;
      pointer-events: none;
      z-index: 9998;
      opacity: 0.3;
    }
    
    /* 元旦主题特效 */
    .theme-newyear {
      background: linear-gradient(135deg, #f6d365 0%, #fda085 100%);
    }
    
    .confetti {
      position: fixed;
      width: 10px;
      height: 10px;
      background-color: #f00;
      box-shadow: 0 0 10px #f00;
      border-radius: 50%;
      animation: confetti-fall 5s linear infinite;
      z-index: 9999;
      pointer-events: none;
    }
    
    @keyframes confetti-fall {
      0% {
        transform: translateY(-20px) rotate(0deg);
        opacity: 1;
      }
      100% {
        transform: translateY(100vh) rotate(360deg);
        opacity: 0;
      }
    }
    
    /* 正常主题 */
    .theme-normal {
      
    }
    
    /* 主题相关样式 */
    body.theme-christmas {
      background: linear-gradient(135deg, #fff5f5 0%, #fef7e0 100%);
    }

    body.theme-christmas .app-container {
      background: linear-gradient(135deg, #fff5f5 0%, #fef7e0 100%) !important;
    }

    body.theme-christmas .global-header {
      background: linear-gradient(135deg, #c00 0%, #800 100%) !important;
    }

    body.theme-christmas .router-view-container {
      background: transparent !important;
    }

    body.theme-halloween {
      background: linear-gradient(135deg, #2d1700 0%, #1a0f00 100%);
      color: #fff;
    }

    body.theme-halloween .app-container {
      background: linear-gradient(135deg, #2d1700 0%, #1a0f00 100%) !important;
      color: #fff;
    }

    body.theme-halloween .global-header {
      background: linear-gradient(135deg, #f90 0%, #d70 100%) !important;
      color: #000;
    }

    body.theme-halloween .router-view-container {
      background: transparent !important;
    }

    body.theme-halloween .ant-card {
      background: rgba(255, 255, 255, 0.1) !important;
      border-color: rgba(255, 255, 255, 0.2) !important;
      color: #fff;
    }

    body.theme-halloween .ant-btn-primary {
      background: #f90 !important;
      border-color: #f90 !important;
    }

    body.theme-halloween .ant-input,
    body.theme-halloween .ant-input-affix-wrapper {
      background: rgba(255, 255, 255, 0.1) !important;
      border-color: rgba(255, 255, 255, 0.3) !important;
      color: #fff;
    }

    body.theme-halloween .ant-form-item-label > label {
      color: #fff !important;
    }

    body.theme-halloween .ant-result {
      color: #fff !important;
    }

    body.theme-halloween .ant-result .ant-result-title {
      color: #fff !important;
    }

    body.theme-halloween .ant-result .ant-result-subtitle {
      color: #d1d5db !important;
    }

    body.theme-halloween .ant-result .ant-result-content {
      color: #fff !important;
    }

    body.theme-newyear {
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
      color: #e5e7eb;
    }

    body.theme-newyear .app-container {
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%) !important;
      color: #e5e7eb;
    }

    body.theme-newyear .global-header {
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%) !important;
      color: #e5e7eb;
      border-bottom: 1px solid rgba(96, 165, 250, 0.2);
    }

    body.theme-newyear .router-view-container {
      background: transparent !important;
    }

    body.theme-newyear .ant-card {
      background: rgba(30, 41, 59, 0.8) !important;
      border-color: rgba(96, 165, 250, 0.2) !important;
      color: #e5e7eb;
    }

    body.theme-newyear .ant-btn-primary {
      background: #60a5fa !important;
      border-color: #60a5fa !important;
    }

    body.theme-newyear .ant-input,
    body.theme-newyear .ant-input-affix-wrapper {
      background: rgba(30, 41, 59, 0.8) !important;
      border-color: rgba(96, 165, 250, 0.3) !important;
      color: #e5e7eb;
    }

    body.theme-newyear .ant-form-item-label > label {
      color: #e5e7eb !important;
    }
</style>