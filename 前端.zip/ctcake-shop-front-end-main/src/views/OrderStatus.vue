<template>
  <div class="order-status-container">
    <div v-if="!orderIdProp && !orderIdFromInput" class="query-form">
      <div class="form-container">
        <h2 class="form-title">🔍 查询订单状态</h2>
        <div class="input-group">
          <input 
            v-model="inputOrderId" 
            type="text" 
            placeholder="输入订单号" 
            @keyup.enter="queryOrder"
            required
          />
          <button @click="queryOrder" :disabled="!inputOrderId.trim()" class="query-btn">
            <span>查询</span>
          </button>
        </div>
      </div>
    </div>
    
    <div v-else class="order-result">
      <div class="result-container">
        <div class="order-header">
          <h2>订单号：{{ orderIdProp || orderIdFromInput }}</h2>
          <div v-if="shouldRefresh" class="refresh-badge">⟳ 每秒自动刷新</div>
          <div v-else class="refresh-badge success">✅ 订单已完成</div>
        </div>
        
        <div v-if="!shouldRefresh" class="status-notice">
          ⚠️ 当充值出现错误时系统会自动为您原路退款。如果结果显示成功但是截图中没有成功，请联系客服。群635505571
        </div>
        
        <div v-if="!orderData" class="status-card error">
          <div class="status-icon">⚠️</div>
          <div class="status-text">无法连接到服务器或返回无效数据</div>
        </div>
        <div v-else-if="orderData.code === 1" class="status-card error">
          <div class="status-icon">❌</div>
          <div class="status-text">订单不存在</div>
        </div>
        <div v-else-if="orderData.status" class="order-status">
          <div v-if="orderData.status === 'queued'" class="status-card queue">
            <div class="status-icon">⏳</div>
            <div class="status-text">
              <div class="status-main">排队充值中</div>
              <div class="status-sub">前方还有 {{ orderData.queued_count || 0 }} 个订单</div>
            </div>
          </div>
          <div v-else-if="orderData.status === 'running'" class="status-card running">
            <div class="status-icon">🔄</div>
            <div class="status-text">
              <div class="status-main">订单正在充值中</div>
              <div class="status-sub">请稍候……此过程预计需要30秒</div>
            </div>
          </div>
          <div v-else-if="orderData.status === 'paid' || orderData.status === 'done'" class="status-card done">
            <div class="status-icon">✅</div>
            <div class="status-text">
              <div class="status-main">{{ orderData.result.result.msg || orderData.msg || '订单支付成功，正在处理中...' }}</div>
            </div>
          </div>
          <div v-else class="status-card error">
            <div class="status-icon">❓</div>
            <div class="status-text">
              <div class="status-main">错误</div>
              <div class="status-sub">{{ orderData.result.result.msg }}</div>
            </div>
          </div>
          
          <!-- 发货截图 -->
          <div v-if="(orderData.status === 'done' || orderData.status === 'paid') && orderData.result.result.screenshot" class="screenshot-section">
            <h4>发货截图</h4>
            <div class="screenshot-container">
              <img 
                :src="`data:image/png;base64,${orderData.result.result.screenshot}`" 
                :alt="'screenshot'" 
                @click="showImage(orderData.result.result.screenshot)"
              />
            </div>
            <div class="screenshot-note">点击图片查看大图</div>
          </div>
        </div>
        <div v-else class="status-card error">
          <div class="status-icon">❌</div>
          <div class="status-text">返回格式不正确</div>
        </div>
      </div>
    </div>
    
    <!-- 图片查看弹窗 -->
    <div v-if="showOverlay" class="img-overlay" @click="closeImage">
      <img :src="`data:image/png;base64,${currentImage}`" alt="screenshot" />
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch } from 'vue';
import { useRoute } from 'vue-router';
import axios from 'axios';

// 接收外部传入的订单ID
const props = defineProps({
  orderId: {
    type: String,
    default: null
  }
});

// 响应式数据
const orderIdProp = ref(props.orderId); // 外部传入的订单ID
const orderIdFromInput = ref(''); // 用户输入的订单ID
const inputOrderId = ref('');
const orderData = ref({});
const shouldRefresh = ref(true);
const showOverlay = ref(false);
const currentImage = ref('');
const pollInterval = ref(null);

// 查询订单状态
const queryOrder = async () => {
  const id = inputOrderId.value.trim();
  if (!id) return;
  
  orderIdFromInput.value = id;
  await fetchOrderStatus();
};

// 获取订单状态
const fetchOrderStatus = async () => {
  const id = orderIdProp.value || orderIdFromInput.value;
  if (!id) return;
  
  try {
    const response = await axios.get(`/api/order-status/${encodeURIComponent(id)}`);
    orderData.value = response.data;
    
    // 检查是否需要继续刷新
    if (orderData.value && orderData.value.status === 'done') {
      shouldRefresh.value = false;
      // 订单完成后停止轮询
      stopPolling();
    }
  } catch (error) {
    console.error('获取订单状态失败:', error);
    orderData.value = null;
  }
};

// 开始轮询
const startPolling = () => {
  if (pollInterval.value) {
    clearInterval(pollInterval.value);
  }
  pollInterval.value = setInterval(fetchOrderStatus, 1000);
};

// 停止轮询
const stopPolling = () => {
  if (pollInterval.value) {
    clearInterval(pollInterval.value);
    pollInterval.value = null;
  }
};

// 显示图片弹窗
const showImage = (imgBase64) => {
  currentImage.value = imgBase64;
  showOverlay.value = true;
};

// 关闭图片弹窗
const closeImage = () => {
  showOverlay.value = false;
};

// 监听orderId属性变化
watch(() => props.orderId, (newOrderId) => {
  if (newOrderId) {
    orderIdProp.value = newOrderId;
    orderIdFromInput.value = newOrderId;  // 确保使用传入的ID
    fetchOrderStatus();
    startPolling();  // 开始轮询
  }
});

// 初始化，检查URL参数
onMounted(() => {
  const route = useRoute();
  if (!orderIdProp.value) {  // 只在没有传入orderId时检查URL参数
    const urlOrderId = route.query.order_id;
    
    if (urlOrderId) {
      orderIdFromInput.value = urlOrderId;
      inputOrderId.value = urlOrderId;
      fetchOrderStatus();
    }
  } else {
    // 如果有传入的orderId，则使用它
    orderIdFromInput.value = orderIdProp.value;
    fetchOrderStatus();
  }
});

// 在组件挂载后开始轮询（如果有订单ID）
onMounted(() => {
  const id = orderIdProp.value || orderIdFromInput.value;
  if (id) {
    startPolling();
  }
});

// 组件卸载时清除轮询
onUnmounted(() => {
  stopPolling();
});
</script>

<style scoped lang="less">
.order-status-container {
  font-family: "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  padding: 20px;

  .query-form {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 300px;

    .form-container {
      background: #ffffff;
      padding: 40px;
      border-radius: 20px;
      box-shadow: 
        0 10px 40px rgba(0, 0, 0, 0.08),
        0 4px 15px rgba(0, 0, 0, 0.06);
      text-align: center;
      width: 100%;
      max-width: 450px;
      position: relative;
      border: 1px solid rgba(226, 232, 240, 0.5);

      .form-title {
        margin: 0 0 24px 0;
        font-size: 22px;
        font-weight: 700;
        color: #111827;
        letter-spacing: 0.5px;
        background: linear-gradient(135deg, #07c160 0%, #1677ff 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
      }

      .input-group {
        display: flex;
        gap: 12px;

        input {
          flex: 1;
          padding: 14px 16px;
          border-radius: 12px;
          border: 2px solid #e5e7eb;
          width: 100%;
          font-size: 15px;
          transition: all 0.3s ease;
          background-color: #f9fafb;

          &:hover {
            border-color: #a0aec0;
          }

          &:focus {
            border-color: #1677ff;
            box-shadow: 0 0 0 4px rgba(22, 119, 255, 0.15);
            background-color: #ffffff;
          }
        }

        .query-btn {
          padding: 14px 24px;
          border: none;
          border-radius: 12px;
          background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
          color: white;
          cursor: pointer;
          font-size: 15px;
          font-weight: 600;
          transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
          letter-spacing: 0.5px;
          height: 50px;

          &:hover:not(:disabled) {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(59, 130, 246, 0.4);
          }

          &:disabled {
            background: #d1d5db;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
          }

          &::after {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            transition: width 0.6s ease, height 0.6s ease;
          }

          &:active::after {
            width: 300px;
            height: 300px;
          }
        }
      }
    }
  }

  .order-result {
    .result-container {
      background: #ffffff;
      padding: 30px;
      border-radius: 20px;
      box-shadow: 
        0 10px 40px rgba(0, 0, 0, 0.08),
        0 4px 15px rgba(0, 0, 0, 0.06);
      width: 100%;
      position: relative;
      border: 1px solid rgba(226, 232, 240, 0.5);

      .order-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
        flex-wrap: wrap;
        gap: 10px;

        h2 {
          margin: 0;
          font-size: 18px;
          font-weight: 600;
          color: #111827;
        }

        .refresh-badge {
          padding: 6px 12px;
          border-radius: 20px;
          font-size: 13px;
          font-weight: 500;
          background: #f3f4f6;
          color: #6b7280;

          &.success {
            background: #dcfce7;
            color: #166534;
          }
        }
      }

      .status-notice {
        background: #fffbeb;
        color: #92400e;
        padding: 12px 16px;
        border-radius: 8px;
        font-size: 13px;
        margin-bottom: 20px;
        border-left: 4px solid #f59e0b;
      }

      .status-card {
        display: flex;
        align-items: flex-start;
        gap: 15px;
        padding: 20px;
        border-radius: 12px;
        margin-bottom: 20px;
        animation: fadeIn 0.3s ease;

        .status-icon {
          font-size: 24px;
          min-width: 30px;
        }

        .status-text {
          flex: 1;
          text-align: left;

          .status-main {
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 4px;
          }

          .status-sub {
            font-size: 14px;
            color: #6b7280;
          }
        }

        &.error {
          background: #fef2f2;
          border: 1px solid #fecaca;

          .status-main {
            color: #dc2626;
          }
        }

        &.queue {
          background: #fffbeb;
          border: 1px solid #fde68a;

          .status-main {
            color: #d97706;
          }
        }

        &.running {
          background: #dbeafe;
          border: 1px solid #93c5fd;

          .status-main {
            color: #1d4ed8;
          }
        }

        &.done {
          background: #f0fdf4;
          border: 1px solid #a7f3d0;

          .status-main {
            color: #059669;
          }
        }
      }

      .screenshot-section {
        margin-top: 25px;
        padding-top: 20px;
        border-top: 1px solid #e5e7eb;

        h4 {
          margin: 0 0 15px 0;
          font-size: 16px;
          font-weight: 600;
          color: #111827;
        }

        .screenshot-container {
          display: flex;
          justify-content: center;
          margin-bottom: 10px;

          img {
            max-width: 100%;
            max-height: 300px;
            border-radius: 10px;
            cursor: pointer;
            transition: 0.2s;
            border: 1px solid #d1d5db;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);

            &:hover {
              transform: scale(1.02);
              box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
            }
          }
        }

        .screenshot-note {
          text-align: center;
          color: #6b7280;
          font-size: 13px;
        }
      }
    }
  }

  .img-overlay {
    display: flex;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.9);
    justify-content: center;
    align-items: center;
    z-index: 9999;

    img {
      max-width: 90%;
      max-height: 90%;
      border-radius: 10px;
      box-shadow: 0 0 40px rgba(255,255,255,0.1);
    }
  }

  @keyframes fadeIn {
    from {
      opacity: 0;
      transform: translateY(10px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @media (max-width: 480px) {
    .result-container {
      padding: 20px;

      .order-header {
        flex-direction: column;
        align-items: flex-start;

        .refresh-badge {
          align-self: flex-start;
        }
      }

      .status-card {
        padding: 16px;
        flex-direction: column;
        gap: 10px;

        .status-icon {
          align-self: center;
        }
      }
    }

    .input-group {
      flex-direction: column;

      input {
        width: 100%;
      }

      .query-btn {
        width: 100%;
      }
    }
  }
}
</style>