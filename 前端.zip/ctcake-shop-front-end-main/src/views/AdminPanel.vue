<template>
  <div class="admin-panel" v-if="!isLoggedIn">
    <div class="login-container">
      <h2>管理员登录</h2>
      <a-form :model="loginForm" @finish="handleLogin">
        <a-form-item name="password" :rules="[{ required: true, message: '请输入管理员密码!' }]">
          <a-input-password v-model:value="loginForm.password" placeholder="管理员密码" />
        </a-form-item>
        <a-form-item>
          <a-button type="primary" html-type="submit" :loading="loginLoading">登录</a-button>
        </a-form-item>
      </a-form>
    </div>
  </div>

  <div class="admin-panel" v-else>
    <div class="admin-header">
      <h2>后台管理面板</h2>
      <a-button @click="logout" type="primary" danger>退出登录</a-button>
    </div>

    <div class="admin-content">
      <a-tabs default-active-key="1">
        <a-tab-pane key="1" tab="样式设置">
          <div class="theme-settings">
            <h3>主题风格设置</h3>
            <div class="theme-options">
              <div 
                v-for="theme in themes" 
                :key="theme.key"
                class="theme-option"
                :class="{ active: currentSettings.theme === theme.key }"
                @click="currentSettings.theme = theme.key"
              >
                <div class="theme-preview" :class="`theme-${theme.key}`">
                  <div class="theme-colors">
                    <div class="theme-color" :style="{ backgroundColor: theme.primaryColor }"></div>
                    <div class="theme-color" :style="{ backgroundColor: theme.secondaryColor }"></div>
                  </div>
                  <div class="theme-name">{{ theme.name }}</div>
                </div>
              </div>
            </div>
          </div>
        </a-tab-pane>
        
        <a-tab-pane key="2" tab="价格设置">
          <div class="price-settings">
            <h3>价格设置</h3>
            <a-form layout="vertical">
              <a-form-item label="FAT$单价 (元)">
                <a-input-number 
                  v-model:value="currentSettings.fat_price" 
                  :min="0" 
                  :step="0.01"
                  style="width: 100%"
                />
              </a-form-item>
              <a-form-item label="订阅价格 (元)">
                <a-input-number 
                  v-model:value="currentSettings.sub_price" 
                  :min="0" 
                  :step="0.01"
                  style="width: 100%"
                />
              </a-form-item>
            </a-form>
          </div>
        </a-tab-pane>
        
        <a-tab-pane key="3" tab="优惠设置">
          <div class="sale-settings">
            <h3>限时优惠设置</h3>
            <a-form layout="vertical">
              <a-form-item label="开启优惠活动">
                <a-switch 
                  v-model:checked="currentSettings.sale_enabled"
                  :checked-value="1"
                  :un-checked-value="0"
                />
              </a-form-item>
              
              <a-form-item label="优惠订阅价格 (元)" v-if="currentSettings.sale_enabled">
                <a-input-number 
                  v-model:value="currentSettings.sale_sub_price" 
                  :min="0" 
                  :step="0.01"
                  style="width: 100%"
                />
              </a-form-item>
              
              <a-form-item label="优惠所需FAT数量" v-if="currentSettings.sale_enabled">
                <a-input-number 
                  v-model:value="currentSettings.sale_fat_required" 
                  :min="1"
                  style="width: 100%"
                />
              </a-form-item>
              
              <div v-if="currentSettings.sale_enabled">
                <a-form-item label="优惠开始时间">
                  <a-date-picker 
                    v-model:value="saleStartDate"
                    value-format="YYYY-MM-DD HH:mm:ss"
                    show-time 
                    format="YYYY-MM-DD HH:mm:ss"
                    style="width: 100%"
                  />
                </a-form-item>
                
                <a-form-item label="优惠结束时间">
                  <a-date-picker 
                    v-model:value="saleEndDate"
                    value-format="YYYY-MM-DD HH:mm:ss"
                    show-time 
                    format="YYYY-MM-DD HH:mm:ss"
                    style="width: 100%"
                  />
                </a-form-item>
              </div>
            </a-form>
          </div>
        </a-tab-pane>
        
        <a-tab-pane key="4" tab="密码设置">
          <div class="password-settings">
            <h3>修改管理员密码</h3>
            <a-form :model="passwordForm" @finish="changePassword">
              <a-form-item label="新密码" name="newPassword" :rules="[{ required: true, message: '请输入新密码!' }]">
                <a-input-password v-model:value="passwordForm.newPassword" placeholder="新管理员密码" />
              </a-form-item>
              <a-form-item label="确认新密码" name="confirmPassword" :rules="[{ required: true, message: '请确认新密码!' }]">
                <a-input-password v-model:value="passwordForm.confirmPassword" placeholder="确认新管理员密码" />
              </a-form-item>
              <a-form-item>
                <a-button type="primary" html-type="submit">修改密码</a-button>
              </a-form-item>
            </a-form>
          </div>
        </a-tab-pane>
      </a-tabs>
      
      <div class="admin-actions">
        <a-button type="primary" @click="saveSettings" :loading="saving">保存设置</a-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { message } from 'ant-design-vue';
import axios from 'axios';

// 登录状态
const isLoggedIn = ref(false);
const loginLoading = ref(false);
const saving = ref(false);

// 登录表单
const loginForm = reactive({
  password: ''
});

// 密码修改表单
const passwordForm = reactive({
  newPassword: '',
  confirmPassword: ''
});

// 当前设置
const currentSettings = ref({
  theme: 'normal',
  fat_price: 0.75,
  sub_price: 198.0,
  sale_enabled: 0,
  sale_sub_price: 0.0,
  sale_fat_required: 288,
  sale_start_date: null,
  sale_end_date: null
});
const themes = ref([
  {
    key: 'normal',
    name: '正常',
    primaryColor: '#1677ff',
    secondaryColor: '#096dd9'
  },
  {
    key: 'christmas',
    name: '圣诞',
    primaryColor: '#8b1e2d',   // 深酒红，像红丝绒
    secondaryColor: '#1f3d2b'  // 冷杉绿，而不是圣诞帽绿
  },
  {
    key: 'halloween',
    name: '万圣节',
    primaryColor: '#b45309',   // 焦糖南瓜橙
    secondaryColor: '#1c1917'  // 煤黑，带一点暖度
  },
  {
    key: 'newyear',
    name: '元旦&新年',
    primaryColor: '#0f172a',   // 深夜蓝灰，稳住气质
    secondaryColor: '#60a5fa'  // 香槟金，不用土豪金
  }
])
const saleStartDate  = ref(null);
const saleEndDate    = ref(null);
// 从后端获取当前设置
const loadSettings = async () => {
  try {
    const response = await axios.get('/api/admin/settings', {
      headers: {
        'Authorization': localStorage.getItem('admin_token')
      }
    });
    
    if (response.data.success) {
      const settings = response.data.settings;
      currentSettings.value = {
        ...currentSettings.value,
        ...settings
      };
      
      // 处理日期
      if (settings.sale_start_date) {
        saleStartDate.value = new Date(settings.sale_start_date).toISOString();
      }
      if (settings.sale_end_date) {
        saleEndDate.value = new Date(settings.sale_end_date).toISOString();
      }
      
      applyTheme(currentSettings.value.theme);
    } else {
      message.error(response.data.message || '获取设置失败');
    }
  } catch (error) {
    console.error('加载设置失败:', error);
    message.error('加载设置失败');
  }
};

// 应用主题
const applyTheme = (theme) => {
  document.body.setAttribute('data-theme', theme);
  switch (theme) {
    case 'normal':
      document.body.classList.remove('theme-christmas', 'theme-halloween', 'theme-newyear');
      document.body.classList.add('theme-normal');
      break;
    case 'christmas':
      document.body.classList.remove('theme-normal', 'theme-halloween', 'theme-newyear');
      document.body.classList.add('theme-christmas');
      break;
    case 'halloween':
      document.body.classList.remove('theme-normal', 'theme-christmas', 'theme-newyear');
      document.body.classList.add('theme-halloween');
      break;
    case 'newyear':
      document.body.classList.remove('theme-normal', 'theme-christmas', 'theme-halloween');
      document.body.classList.add('theme-newyear');
      break;
  }
};

// 管理员登录
const handleLogin = async () => {
  loginLoading.value = true;
  try {
    const response = await axios.post('/api/admin/login', {
      password: loginForm.password
    });
    
    if (response.data.success) {
      localStorage.setItem('admin_token', response.data.token);
      isLoggedIn.value = true;
      message.success('登录成功');
      loadSettings();
    } else {
      message.error(response.data.message || '登录失败');
    }
  } catch (error) {
    console.error('登录失败:', error);
    // 检查是否有响应数据
    if (error.response) {
      // 服务器返回了错误响应
      const errorMessage = error.response.data?.message || error.response.data || `登录失败，状态码: ${error.response.status}`;
      message.error(errorMessage);
    } else if (error.request) {
      // 请求已发出但没有收到响应
      message.error('无法连接到服务器，请确保后端服务已启动');
    } else {
      // 其他错误
      message.error('登录失败，请检查网络连接');
    }
  } finally {
    loginLoading.value = false;
  }
};

// 保存设置
const saveSettings = async () => {
  if (passwordForm.newPassword && passwordForm.newPassword !== passwordForm.confirmPassword) {
    message.error('新密码和确认密码不匹配');
    return;
  }
  
  saving.value = true;
  try {
    const response = await axios.post('/api/admin/settings', {
      theme: currentSettings.value.theme,
      fat_price: currentSettings.value.fat_price,
      sub_price: currentSettings.value.sub_price,
      sale_enabled: currentSettings.value.sale_enabled,
      sale_sub_price: currentSettings.value.sale_sub_price,
      sale_fat_required: currentSettings.value.sale_fat_required,
      sale_start_date: saleStartDate.value,
      sale_end_date: saleEndDate.value,
      new_password: passwordForm.newPassword || undefined
    }, {
      headers: {
        'Authorization': localStorage.getItem('admin_token')
      }
    });
    
    if (response.data.success) {
      message.success('设置保存成功');
      applyTheme(currentSettings.value.theme);
      
      // 如果修改了密码，清除当前登录状态并重新登录
      if (passwordForm.newPassword) {
        passwordForm.newPassword = '';
        passwordForm.confirmPassword = '';
        localStorage.removeItem('admin_token');
        isLoggedIn.value = false;
        message.info('密码已修改，请重新登录');
      }
    } else {
      message.error(response.data.message || '保存失败');
    }
  } catch (error) {
    console.error('保存设置失败:', error);
    // 检查是否有响应数据
    if (error.response) {
      // 服务器返回了错误响应
      const errorMessage = error.response.data?.message || error.response.data || `保存失败，状态码: ${error.response.status}`;
      message.error(errorMessage);
    } else if (error.request) {
      // 请求已发出但没有收到响应
      message.error('无法连接到服务器，请确保后端服务已启动');
    } else {
      // 其他错误
      message.error('保存设置失败，请检查网络连接');
    }
  } finally {
    saving.value = false;
  }
};

// 修改密码
const changePassword = async () => {
  if (passwordForm.newPassword !== passwordForm.confirmPassword) {
    message.error('新密码和确认密码不匹配');
    return;
  }
  
  await saveSettings();
};

// 退出登录
const logout = () => {
  localStorage.removeItem('admin_token');
  isLoggedIn.value = false;
  loginForm.password = '';
  message.success('已退出登录');
};

// 检查登录状态
onMounted(() => {
  const token = localStorage.getItem('admin_token');
  if (token) {
    // 简单验证token格式（实际应用中应向后端验证）
    if (token.length === 64) { // SHA256哈希长度
      isLoggedIn.value = true;
      loadSettings();
    }
  }
});
</script>

<style scoped>
.admin-panel {
  max-width: 800px;
  margin: 20px auto;
  padding: 20px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.login-container {
  text-align: center;
}

.login-container h2 {
  margin-bottom: 24px;
  color: #1f2937;
}

.admin-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid #e5e7eb;
}

.admin-header h2 {
  margin: 0;
  color: #1f2937;
}

.admin-content {
  margin-top: 20px;
}

.theme-settings h3,
.price-settings h3,
.password-settings h3 {
  margin-bottom: 16px;
  color: #1f2937;
}

.theme-options {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
  gap: 16px;
  margin-bottom: 20px;
}

.theme-option {
  cursor: pointer;
  border: 2px solid transparent;
  border-radius: 8px;
  transition: all 0.3s ease;
}

.theme-option:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.theme-option.active {
  border-color: #1677ff;
}

.theme-preview {
  padding: 16px;
  text-align: center;
  border-radius: 6px;
  background: #f8fafc;
}

.theme-colors {
  display: flex;
  justify-content: center;
  gap: 8px;
  margin-bottom: 8px;
}

.theme-color {
  width: 30px;
  height: 30px;
  border-radius: 4px;
  border: 1px solid #e5e7eb;
}

.theme-name {
  font-size: 14px;
  color: #374151;
}

.price-settings, .password-settings {
  max-width: 400px;
}

.admin-actions {
  margin-top: 24px;
  text-align: center;
}

/* 主题特定样式 */
body.theme-christmas {
  background: linear-gradient(135deg, #fff5f5 0%, #fef7e0 100%);
}

body.theme-christmas .app-container {
  background: linear-gradient(135deg, #fff5f5 0%, #fef7e0 100%) !important;
}

body.theme-christmas .global-header {
  background: linear-gradient(135deg, #c00 0%, #800 100%) !important;
}

body.theme-halloween {
  background: linear-gradient(135deg, #2d1700 0%, #1a0f00 100%);
  color: #fff;
}

body.theme-halloween .app-container {
  background: linear-gradient(135deg, #2d1700 0%, #1a0f00 100%) !important;
  color: #fff;
}

body.theme-halloween .global-header {
  background: linear-gradient(135deg, #f90 0%, #d70 100%) !important;
  color: #000;
}

body.theme-halloween .ant-card {
  background: rgba(255, 255, 255, 0.1) !important;
  border-color: rgba(255, 255, 255, 0.2) !important;
}

body.theme-halloween .ant-btn-primary {
  background: #f90 !important;
  border-color: #f90 !important;
}

body.theme-newyear {
  background: linear-gradient(135deg, #fef7e0 0%, #fffbeb 100%);
}

body.theme-newyear .app-container {
  background: linear-gradient(135deg, #fef7e0 0%, #fffbeb 100%) !important;
}

body.theme-newyear .global-header {
  background: linear-gradient(135deg, #d4af37 0%, #b8860b 100%) !important;
}
</style>