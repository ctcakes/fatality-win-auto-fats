-- 初始化订单表，包含所有字段
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    amount REAL,
    username TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    paid_at TEXT,
    payment_method TEXT,
    payment_url TEXT,
    browser_fingerprint TEXT,
    product_type TEXT,  -- 'sub' 或 'fat'
    buy_type TEXT NOT NULL CHECK (buy_type IN ('fat', 'sub')),  -- 只能选择 'fat' 或 'sub'，不可为空
    fat_count INTEGER DEFAULT 10 CHECK (fat_count >= 10 OR fat_count IS NULL)  -- 最小值10，默认10，可为空
);