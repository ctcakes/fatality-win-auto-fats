<template>
  <div class="result-container">
    <div class="result-card">
      <div class="result-icon" :class="resultIconClass">
        <CheckCircleOutlined v-if="status === 'paid'" class="success-icon" />
        <CloseCircleOutlined v-else-if="status === 'cancelled' || status === 'closed'" class="error-icon" />
        <ExclamationCircleOutlined v-else class="warning-icon" />
      </div>
      <h2 class="result-title">{{ resultTitle }}</h2>
      <p class="result-desc">{{ resultDesc }}</p>
      <div class="order-info">
        <p><strong>订单号：</strong>{{ orderId }}</p>
        <p v-if="status === 'paid'"><strong>支付金额：</strong>{{ formattedAmount }}￥</p>
        <p v-else><strong>订单状态：</strong>{{ statusText }}</p>
        <p><strong>支付时间：</strong>{{ currentTime }}</p>
        <p v-if="isTestOrder"><strong>商品类型：</strong>{{ isTestOrder ? '测试商品' : '自动发货商品' }}</p>
      </div>
      <div class="action-buttons">
        <a-button type="primary" @click="goToHome" size="large" class="primary-btn">
          返回首页
        </a-button>
        <a-button @click="goToBuySub" size="large" class="secondary-btn">
          继续购买
        </a-button>
      </div>
    </div>
    
    <!-- 订单状态组件 - 仅在支付成功时显示 -->
          <div v-if="status === 'paid' && orderId && !isTestOrder" class="order-status-section">
            <div class="status-card">
              <h3 class="status-title">订单执行状态</h3>
              <OrderStatus :order-id="orderId" @amount-updated="updateAmount" />
            </div>
          </div>  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { 
  CheckCircleOutlined, 
  CloseCircleOutlined, 
  ExclamationCircleOutlined 
} from '@ant-design/icons-vue';
import { message } from 'ant-design-vue';
import axios from 'axios';
import OrderStatus from './OrderStatus.vue';

const route = useRoute();
const router = useRouter();
const amount = ref(0);
const status = ref('');
const orderId = ref('');
const isTestOrder = ref(false);
const resultTitle = ref('');
const resultDesc = ref('');
const resultIconClass = ref('');
const statusText = ref('');

const currentTime = ref('');

// 格式化金额，保留两位小数以避免浮点数精度问题
const formattedAmount = computed(() => {
  return parseFloat(amount.value).toFixed(2);
});

const executeBuySubLogic = async () => {
  message.info('订单已支付，请等待服务器发货，预计30秒。', 0); // 0表示不自动关闭
  //轮询逻辑会修改页面显示，不必写这里的逻辑
};

// 执行FAT购买业务逻辑
const executeBuyFatLogic = async () => {
  message.info('订单已支付，请等待服务器发货，预计30秒。', 0); // 0表示不自动关闭
  //轮询逻辑会修改页面显示，不必写这里的逻辑
};

onMounted(() => {
  orderId.value = route.query.order_id;
  
  const outTradeNo = route.query.order_id;
  
  // 如果是支付回调URL，使用out_trade_no作为订单ID
  if (outTradeNo) {
    orderId.value = outTradeNo; // 使用 out_trade_no 作为订单ID
    fetchFullOrderDetail(outTradeNo);
  }
});

// 更新金额的方法
const updateAmount = (newAmount) => {
  amount.value = newAmount;
};

const goToHome = () => {
  router.push('/');
};

// 获取订单详情
const fetchOrderDetail = async (orderNo) => {
  try {
    const response = await axios.get(`/api/order-status/${encodeURIComponent(orderNo)}`);
    if (response.data && response.data.result && response.data.result.order_amount) {
      amount.value = response.data.result.order_amount;
    } else if (response.data && response.data.order_amount) {
      amount.value = response.data.order_amount;
    }
  } catch (error) {
    console.error('获取订单详情失败:', error);
  }
};

// 获取完整订单详情
const fetchFullOrderDetail = async (orderNo) => {
  try {
    const response = await axios.get(`/api/order-status/${encodeURIComponent(orderNo)}`);
    
    if (response.data && response.data.code === 0) {
      // 从后端API获取完整订单信息
      status.value = response.data.pay_status || response.data.status; // 使用支付状态
      amount.value = response.data.result && response.data.result.order_amount 
        ? response.data.result.order_amount 
        : (response.data.order_amount || 0);
      
      // 设置结果信息基于从后端获取的状态
      if (status.value === 'paid') {
        resultTitle.value = '支付成功！';
        resultDesc.value = '感谢您的惠顾！请耐心等待服务器发货！';
        resultIconClass.value = 'success';
      } else if (status.value === 'cancelled' || status.value === 'closed' || status.value === 'TRADE_CLOSED') {
        resultTitle.value = '订单已取消';
        resultDesc.value = '您的订单已取消或关闭，如有疑问请联系客服。';
        resultIconClass.value = 'error';
      } else if (status.value === 'pending') {
        resultTitle.value = '等待支付';
        resultDesc.value = '请完成支付以继续。';
        resultIconClass.value = 'warning';
      } else {
        resultTitle.value = '支付状态';
        resultDesc.value = '当前订单状态为：' + (response.data.status || status.value);
        resultIconClass.value = 'warning';
      }
      
      // 设置状态文本
      statusText.value = response.data.status || status.value;
      
      // 设置当前时间
      const now = new Date();
      currentTime.value = now.toLocaleString('zh-CN');
      
      // 检查是否为测试订单 - 从后端获取的订单信息中判断
      // 通常测试订单金额为0.01
      if (amount.value === 0.01) {
        isTestOrder.value = true;
      }
    } else {
      // 如果API返回错误，显示错误信息
      resultTitle.value = '订单查询失败';
      resultDesc.value = response.data.msg || '无法获取订单信息，请稍后重试。';
      resultIconClass.value = 'error';
    }
  } catch (error) {
    console.error('获取完整订单详情失败:', error);
    resultTitle.value = '网络错误';
    resultDesc.value = '无法连接到服务器，请检查网络连接后重试。';
    resultIconClass.value = 'error';
  }
};

const goToBuySub = () => {
  router.push('/buy/sub');
};
</script>

<style scoped lang="less">
.result-container {
  min-height: 100vh;
  padding: 40px 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  
  flex-direction: column;
  gap: 30px;
}

.result-card {
  width: 450px;
  background: #ffffff;
  border-radius: 20px;
  padding: 40px;
  text-align: center;
  box-shadow: 
    0 10px 40px rgba(0, 0, 0, 0.08),
    0 4px 15px rgba(0, 0, 0, 0.06);
  position: relative;
  border: 1px solid rgba(226, 232, 240, 0.5);

  .result-icon {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;

    &.success {
      background: #f6ffed;
      border: 1px solid #b7eb8f;

      .success-icon {
        font-size: 48px;
        color: #52c41a;
      }
    }

    &.error {
      background: #fff2f0;
      border: 1px solid #ffccc7;

      .error-icon {
        font-size: 48px;
        color: #ff4d4f;
      }
    }

    &.warning {
      background: #fffbe6;
      border: 1px solid #ffe58f;

      .warning-icon {
        font-size: 48px;
        color: #faad14;
      }
    }
  }

  .result-title {
    font-size: 26px;
    font-weight: 700;
    color: #111827;
    margin: 0 0 12px 0;
    letter-spacing: 0.5px;
    background: linear-gradient(135deg, #07c160 0%, #1677ff 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }

  .result-desc {
    font-size: 16px;
    color: #6b7280;
    margin: 0 0 24px 0;
    line-height: 1.6;
  }

  .order-info {
    background: #f8fafc;
    border-radius: 12px;
    padding: 20px;
    margin: 0 0 24px 0;
    text-align: left;

    p {
      margin: 10px 0;
      font-size: 14px;
      color: #4b5563;
      display: flex;
      justify-content: space-between;

      strong {
        color: #111827;
        margin-right: 10px;
      }
    }
  }

  .action-buttons {
    display: flex;
    gap: 12px;
    margin-top: 24px;

    .primary-btn {
      flex: 1;
    }

    .secondary-btn {
      flex: 1;
    }
  }
}

// 订单状态部分样式
.order-status-section {
  width: 100%;
  max-width: 700px;
  margin: 0 auto;
  padding: 20px;

  .status-card {
    background: #ffffff;
    border-radius: 20px;
    padding: 30px;
    box-shadow: 
      0 10px 40px rgba(0, 0, 0, 0.08),
      0 4px 15px rgba(0, 0, 0, 0.06);
    border: 1px solid rgba(226, 232, 240, 0.5);

    .status-title {
      margin: 0 0 20px 0;
      font-size: 20px;
      font-weight: 700;
      color: #111827;
      text-align: center;
      background: linear-gradient(135deg, #07c160 0%, #1677ff 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
  }
}

// 响应式适配
@media (max-width: 480px) {
  .result-card {
    width: 90%;
    padding: 30px 20px;
  }
  
  .order-status-section {
    padding: 10px;
    
    .status-card {
      padding: 20px;
    }
  }
}
</style>

<style scoped lang="less">
.result-container {
  min-height: 100vh;
  padding: 40px 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  
}

.result-card {
  width: 450px;
  background: #ffffff;
  border-radius: 16px;
  padding: 40px;
  text-align: center;
  box-shadow: 
    0 10px 40px rgba(0, 0, 0, 0.08),
    0 4px 15px rgba(0, 0, 0, 0.06);
  position: relative;

  .result-icon {
    width: 80px;
    height: 80px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;

    &.success {
      background: #f6ffed;
      border: 1px solid #b7eb8f;

      .success-icon {
        font-size: 48px;
        color: #52c41a;
      }
    }

    &.error {
      background: #fff2f0;
      border: 1px solid #ffccc7;

      .error-icon {
        font-size: 48px;
        color: #ff4d4f;
      }
    }

    &.warning {
      background: #fffbe6;
      border: 1px solid #ffe58f;

      .warning-icon {
        font-size: 48px;
        color: #faad14;
      }
    }
  }

  .result-title {
    font-size: 26px;
    font-weight: 600;
    color: #111827;
    margin: 0 0 12px 0;
  }

  .result-desc {
    font-size: 16px;
    color: #6b7280;
    margin: 0 0 24px 0;
    line-height: 1.6;
  }

  .order-info {
    background: #f8fafc;
    border-radius: 8px;
    padding: 16px;
    margin: 0 0 24px 0;
    text-align: left;

    p {
      margin: 8px 0;
      font-size: 14px;
      color: #4b5563;

      strong {
        color: #111827;
      }
    }
  }

  .action-buttons {
    display: flex;
    gap: 12px;
    margin-top: 24px;

    .primary-btn {
      flex: 1;
    }

    .secondary-btn {
      flex: 1;
    }
  }
}

// 响应式适配
@media (max-width: 480px) {
  .result-card {
    width: 90%;
    padding: 30px 20px;
  }
}
</style>