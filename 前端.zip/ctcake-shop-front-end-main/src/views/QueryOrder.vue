<template>
  <div class="query-container">
    <div class="query-card">
      <div class="card-header">
        <div class="header-icon">
          <FileTextOutlined class="icon" />
        </div>
        <h2 class="query-title">订单查询</h2>
        <div class="header-decoration"></div>
      </div>
      
      <div class="card-content">
        <!-- 浏览器指纹查询 -->
        <div class="query-section">
          <div class="section-header">
            <h3>通过浏览器缓存查询</h3>
            <p class="section-desc">自动获取您设备上的订单信息，无需输入订单号</p>
          </div>
          <a-button 
            type="primary" 
            size="large" 
            @click="queryByFingerprint"
            :loading="fingerprintLoading"
            class="query-btn"
          >
            <template #icon>
              <HistoryOutlined />
            </template>
            查询缓存订单
          </a-button>
        </div>
        
        <div class="divider"></div>
        
        <!-- 订单号查询 -->
        <div class="query-section">
          <div class="section-header">
            <h3>通过订单号查询</h3>
            <p class="section-desc">输入订单号进行精确查询</p>
          </div>
          <div class="input-group">
            <a-input 
              v-model:value="orderIdInput" 
              placeholder="输入订单号" 
              size="large"
              @pressEnter="queryByOrderId"
              class="order-id-input"
            >
              <template #prefix>
                <OrderedListOutlined class="input-icon" />
              </template>
            </a-input>
            <a-button 
              type="primary" 
              size="large" 
              @click="queryByOrderId"
              :loading="orderIdLoading"
              class="query-btn"
            >
              <template #icon>
                <SearchOutlined />
              </template>
              查询订单
            </a-button>
          </div>
        </div>
        
        <!-- 查询结果 -->
        <div v-if="queryResult" class="result-section">
          <h3 class="section-title">查询结果</h3>
          <div class="result-card">
            <div class="result-grid">
              <div class="result-item">
                <span class="label">订单号:</span>
                <span class="value order-id">{{ queryResult.order_id }}</span>
              </div>
              <div class="result-item">
                <span class="label">状态:</span>
                <span class="value status" :class="queryResult.status">{{ getStatusText(queryResult.status) }}</span>
              </div>
              <div class="result-item">
                <span class="label">商品类型:</span>
                <span class="value">{{ queryResult.product_type === 'sub' ? 'FA续费' : 'FAT购买' }}</span>
              </div>
              <div class="result-item">
                <span class="label">金额:</span>
                <span class="value amount">¥{{ queryResult.amount }}</span>
              </div>
              <div class="result-item">
                <span class="label">用户名:</span>
                <span class="value">{{ queryResult.username }}</span>
              </div>
              <div class="result-item">
                <span class="label">创建时间:</span>
                <span class="value">{{ formatDate(queryResult.created_at) }}</span>
              </div>
            </div>
            
            <div class="result-actions">
              <a-button 
                v-if="queryResult.status === 'pending'" 
                type="primary" 
                @click="goToPayment(queryResult)"
                :disabled="isOrderExpired(queryResult) && !queryResult.pay_url"
              >
                {{ isOrderExpired(queryResult) && queryResult.pay_url ? '重新支付' : (isOrderExpired(queryResult) ? '订单已过期' : '前往支付') }}
              </a-button>
              
              <a-button 
                v-else-if="queryResult.status === 'paid'" 
                @click="viewOrderResult(queryResult)"
              >
                查看执行结果
              </a-button>
              
              <div v-if="queryResult.status === 'pending' && isOrderExpired(queryResult)" class="expired-note">
                订单已超过5分钟未支付，已过期
              </div>
            </div>
          </div>
        </div>
        
        <!-- 浏览器指纹订单列表 -->
        <div v-if="fingerprintOrders.length > 0" class="orders-list-section">
          <h3 class="section-title">我的所有订单</h3>
          <div 
            v-for="order in fingerprintOrders" 
            :key="order.order_id" 
            class="order-item"
          >
            <div class="order-summary">
              <div class="order-id">订单号: {{ order.order_id }}</div>
              <div class="order-status" :class="order.status">{{ getStatusText(order.status) }}</div>
            </div>
            <div class="order-details">
              <div class="order-info-grid">
                <div class="order-info-item">
                  <strong>类型:</strong> {{ order.product_type === 'sub' ? 'FA续费' : 'FAT购买' }}
                </div>
                <div class="order-info-item">
                  <strong>金额:</strong> ¥{{ order.amount }}
                </div>
                <div class="order-info-item">
                  <strong>时间:</strong> {{ formatDate(order.created_at) }}
                </div>
              </div>
            </div>
            <div class="order-actions">
              <a-button 
                v-if="order.status === 'pending'" 
                type="primary" 
                size="small"
                @click="goToPayment(order)"
                :disabled="isOrderExpired(order) && !order.pay_url"
              >
                {{ isOrderExpired(order) && order.pay_url ? '重新支付' : (isOrderExpired(order) ? '过期' : '支付') }}
              </a-button>
              
              <a-button 
                v-else-if="order.status === 'paid'" 
                size="small"
                @click="viewOrderResult(order)"
              >
                查看结果
              </a-button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';
import { message } from 'ant-design-vue';
import { 
  FileTextOutlined, 
  SearchOutlined,
  HistoryOutlined,
  OrderedListOutlined
} from '@ant-design/icons-vue';
import axios from 'axios';
import FingerprintJS from '@fingerprintjs/fingerprintjs';

const router = useRouter();
const orderIdInput = ref('');
const queryResult = ref(null);
const fingerprintOrders = ref([]);
const fingerprintLoading = ref(false);
const orderIdLoading = ref(false);

// 通过浏览器指纹查询订单
const queryByFingerprint = async () => {
  try {
    fingerprintLoading.value = true;
    queryResult.value = null; // 清除之前的查询结果
    
    const fp = await FingerprintJS.load();
    const result = await fp.get();
    const fingerprint = result.visitorId;
    
    const response = await axios.post('/api/orders-by-fingerprint', {
      browser_fingerprint: fingerprint
    });
    
    if (response.data.all_orders && response.data.all_orders.length > 0) {
      fingerprintOrders.value = response.data.all_orders;
      message.success(`找到 ${response.data.all_orders.length} 个订单`);
    } else {
      message.info('未找到订单');
      fingerprintOrders.value = [];
    }
  } catch (error) {
    console.error('查询订单失败:', error);
    message.error('查询订单失败');
    fingerprintOrders.value = [];
  } finally {
    fingerprintLoading.value = false;
  }
};

// 通过订单号查询订单
const queryByOrderId = async () => {
  const id = orderIdInput.value.trim();
  if (!id) {
    message.warning('请输入订单号');
    return;
  }
  
  try {
    orderIdLoading.value = true;
    fingerprintOrders.value = []; // 清除浏览器指纹订单列表
    
    const response = await axios.get(`/api/order-status/${id}`);
    if (response.data.code === 1) {
      message.error(response.data.msg || '订单不存在或查询失败');
      queryResult.value = null;
      return;
    }
    queryResult.value = {
      order_id: id,
      ...response.data
    };
    
    message.success('查询成功');
  } catch (error) {
    console.error('查询订单失败:', error);
    message.error('订单不存在或查询失败');
    queryResult.value = null;
  } finally {
    orderIdLoading.value = false;
  }
};

// 获取状态文本
const getStatusText = (status) => {
  switch (status) {
    case 'pending': return '待支付';
    case 'paid': return '已支付';
    case 'expired': return '已过期';
    case 'cancelled': return '已取消';
    default: return status;
  }
};

// 格式化日期
const formatDate = (dateString) => {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleString('zh-CN');
};

// 检查订单是否过期
const isOrderExpired = (order) => {
  if (order.status !== 'pending') return false;
  
  const createdTime = new Date(order.created_at).getTime();
  const currentTime = new Date().getTime();
  const timeDiff = (currentTime - createdTime) / (1000 * 60); // 转换为分钟
  
  return timeDiff > 5; // 5分钟过期
};

// 前往支付
const goToPayment = (order) => {
  // 检查订单是否已过期
  if (isOrderExpired(order)) {
    message.warning('订单已过期，无法支付');
    return;
  }

  // 无论支付方式如何，都只跳转到等待页面，由等待页面处理后续逻辑
  router.push(`/buy/waiting?order_id=${order.order_id}`);
};

// 查看订单结果
const viewOrderResult = (order) => {
  // 跳转到订单状态页面
  router.push(`/order-status?order_id=${order.order_id}`);
};
</script>

<style scoped lang="less">
.query-container {
  min-height: 100vh;
  padding: 40px 20px;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  
}

.query-card {
  width: 100%;
  max-width: 700px;
  background: #ffffff;
  border-radius: 20px;
  box-shadow: 
    0 10px 40px rgba(0, 0, 0, 0.08),
    0 4px 15px rgba(0, 0, 0, 0.06);
  position: relative;
  border: 1px solid rgba(226, 232, 240, 0.5);
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);

  &:hover {
    transform: translateY(-5px);
    box-shadow: 
      0 15px 50px rgba(0, 0, 0, 0.1),
      0 6px 20px rgba(0, 0, 0, 0.08);
  }

  .card-header {
    position: relative;
    padding: 28px 32px 20px;
    // background: linear-gradient(135deg, #f8fafc 0%, #eef2f7 100%);
    border-bottom: 1px solid rgba(226, 232, 240, 0.6);

    .header-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 44px;
      height: 44px;
      background: linear-gradient(135deg, #1677ff 0%, #096dd9 100%);
      border-radius: 12px;
      margin-bottom: 12px;
    }

    .icon {
      font-size: 22px;
      color: white;
    }

    .query-title {
      margin: 0;
      font-size: 22px;
      font-weight: 700;
      color: #111827;
      letter-spacing: 0.5px;
      background: linear-gradient(135deg, #1677ff 0%, #096dd9 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .header-decoration {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 4px;
      background: linear-gradient(90deg, #1677ff 0%, #096dd9 100%);
    }
  }

  .card-content {
    padding: 20px 32px 32px;
  }

  .query-section {
    margin-bottom: 30px;
    padding: 20px;
    background: #f8fafc;
    border-radius: 16px;
    border: 1px solid #e2e8f0;

    .section-header {
      margin-bottom: 15px;

      h3 {
        margin: 0 0 8px;
        font-size: 18px;
        font-weight: 600;
        color: #111827;
      }

      .section-desc {
        margin: 0;
        font-size: 14px;
        color: #6b7280;
        line-height: 1.5;
      }
    }

    .query-btn {
      width: 100%;
      margin-top: 10px;
      height: 50px;
      border-radius: 12px;
      font-size: 16px;
      font-weight: 600;
    }

    .input-group {
      display: flex;
      gap: 10px;

      .order-id-input {
        flex: 1;

        :deep(.ant-input) {
          height: 50px;
          border-radius: 12px;
          font-size: 15px;
          transition: all 0.3s ease;
          background-color: #f9fafb;

          &:hover {
            border-color: #a0aec0;
          }

          &:focus {
            border-color: #1677ff;
            box-shadow: 0 0 0 4px rgba(22, 119, 255, 0.15);
            background-color: #ffffff;
          }
        }

        :deep(.input-icon) {
          color: #718096;
        }
      }

      .query-btn {
        width: auto;
        margin-top: 0;
        min-width: 120px;
      }
    }
  }

  .divider {
    text-align: center;
    margin: 25px 0;
    position: relative;
    color: #9ca3af;
    font-size: 14px;
    font-weight: 500;

    &::before {
      content: '';
      position: absolute;
      top: 50%;
      left: 0;
      right: 0;
      height: 1px;
      background: #e5e7eb;
      z-index: 1;
    }

    &::after {
      content: '或';
      position: relative;
      z-index: 2;
      background: #fff;
      padding: 0 15px;
      display: inline-block;
      background-color: #f0f2f5;
    }
  }

  .result-section {
    margin-top: 30px;
    padding-top: 20px;
    border-top: 1px solid #e5e7eb;

    .section-title {
      margin-bottom: 15px;
      font-size: 18px;
      font-weight: 600;
      color: #111827;
    }

    .result-card {
      background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
      border-radius: 16px;
      padding: 24px;
      border: 1px solid #e2e8f0;

      .result-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 15px;
        margin-bottom: 20px;
      }

      .result-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 12px;
        padding-bottom: 12px;
        border-bottom: 1px solid #e2e8f0;
        flex-wrap: wrap;
        
        &:last-child {
          margin-bottom: 0;
          padding-bottom: 0;
          border-bottom: none;
        }

        .label {
          font-weight: 500;
          color: #4b5563;
          flex: 0 0 80px;
        }

        .value {
          color: #1f2937;
          text-align: right;
          flex: 1;
          word-break: break-all;

          &.status {
            font-weight: 600;

            &.pending {
              color: #d97706;
            }

            &.paid {
              color: #059669;
            }

            &.expired {
              color: #dc2626;
            }

            &.cancelled {
              color: #6b7280;
            }
          }

          &.order-id {
            font-family: monospace;
            font-size: 14px;
            background: #f1f5f9;
            padding: 2px 6px;
            border-radius: 4px;
          }

          &.amount {
            font-weight: 600;
            color: #059669;
          }
        }
      }

      .result-actions {
        margin-top: 15px;
        text-align: center;

        .expired-note {
          color: #dc2626;
          font-size: 13px;
          margin-top: 8px;
          padding: 8px 12px;
          background: #fef2f2;
          border-radius: 6px;
          border-left: 3px solid #dc2626;
        }
      }
    }
  }

  .orders-list-section {
    margin-top: 30px;

    .section-title {
      margin-bottom: 15px;
      font-size: 18px;
      font-weight: 600;
      color: #111827;
    }

    .order-item {
      border: 1px solid #e5e7eb;
      border-radius: 16px;
      padding: 20px;
      margin-bottom: 15px;
      background: #f8fafc;
      transition: all 0.3s ease;

      &:hover {
        transform: translateY(-3px);
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.1);
        border-color: rgba(22, 119, 255, 0.3);
      }

      .order-summary {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
        flex-wrap: wrap;
        gap: 10px;

        .order-id {
          font-weight: 600;
          color: #111827;
          font-size: 15px;
        }

        .order-status {
          padding: 6px 12px;
          border-radius: 20px;
          font-size: 13px;
          font-weight: 500;

          &.pending {
            background: linear-gradient(135deg, #fef3c7 0%, #fcd34d 100%);
            color: #d97706;
          }

          &.paid {
            background: linear-gradient(135deg, #d1fae5 0%, #6ee7b7 100%);
            color: #059669;
          }

          &.expired {
            background: linear-gradient(135deg, #fee2e2 0%, #fca5a5 100%);
            color: #dc2626;
          }

          &.cancelled {
            background: linear-gradient(135deg, #e5e7eb 0%, #d1d5db 100%);
            color: #6b7280;
          }
        }
      }

      .order-details {
        .order-info-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
          gap: 12px;
          margin-bottom: 15px;

          .order-info-item {
            font-size: 14px;
            color: #4b5563;
            padding: 8px 12px;
            background: #f1f5f9;
            border-radius: 8px;

            strong {
              color: #111827;
            }
          }
        }
      }

      .order-actions {
        text-align: right;
      }
    }
  }
}

@media (max-width: 768px) {
  .query-card {
    width: 95%;
    margin: 20px auto;

    .card-content {
      padding: 20px 20px 25px;
    }

    .query-section {
      padding: 15px;
    }

    .input-group {
      flex-direction: column;

      .order-id-input {
        width: 100%;
      }

      .query-btn {
        width: 100%;
      }
    }

    .result-grid {
      grid-template-columns: 1fr !important;
    }

    .order-info-grid {
      grid-template-columns: 1fr !important;
    }
  }
}
</style>