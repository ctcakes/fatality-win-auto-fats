<template>
  <div class="festival-effects" :class="`theme-${currentTheme}`">
    <!-- 圣诞主题特效 -->
    <template v-if="currentTheme === 'christmas'">
      <div v-for="i in 50" :key="`snowflake-${i}`" 
           class="snowflake" 
           :style="getSnowflakeStyle(i)">
        ❄️
      </div>
      <div class="christmas-lights"></div>
    </template>

    <!-- 万圣节主题特效 -->
    <template v-if="currentTheme === 'halloween'">
      <div v-for="i in 15" :key="`bat-${i}`" 
           class="bat" 
           :style="getBatStyle(i)">
        🦇
      </div>
      <div v-for="i in 10" :key="`ghost-${i}`" 
           class="ghost" 
           :style="getGhostStyle(i)">
        👻
      </div>
      <div class="spider-web"></div>
    </template>

    <!-- 元旦主题特效 -->
    <template v-if="currentTheme === 'newyear'">
      <div v-for="i in 30" :key="`confetti-${i}`" 
           class="confetti" 
           :style="getConfettiStyle(i)"></div>
      <div class="firework" v-for="i in 5" :key="`firework-${i}`" :style="getFireworkStyle(i)"></div>
      <div class="lantern-container">
        <div v-for="i in 3" :key="`lantern-${i}`" class="lantern" :style="getLanternStyle(i)">🏮</div>
      </div>
    </template>

    <!-- 春节主题特效 -->
    <template v-if="currentTheme === 'spring'">
      <div v-for="i in 20" :key="`firecracker-${i}`" 
           class="firecracker" 
           :style="getFirecrackerStyle(i)">
        🧨
      </div>
      <div v-for="i in 15" :key="`flower-${i}`" 
           class="flower" 
           :style="getFlowerStyle(i)">
        🌸
      </div>
      <div class="fu-character">福</div>
    </template>

    <!-- 情人节主题特效 -->
    <template v-if="currentTheme === 'valentine'">
      <div v-for="i in 25" :key="`heart-${i}`" 
           class="heart" 
           :style="getHeartStyle(i)">
        ❤️
      </div>
      <div class="rose-container">
        <div v-for="i in 8" :key="`rose-${i}`" class="rose" :style="getRoseStyle(i)">🌹</div>
      </div>
    </template>

    <!-- 中秋节主题特效 -->
    <template v-if="currentTheme === 'midautumn'">
      <div class="moon">🌕</div>
      <div v-for="i in 10" :key="`star-${i}`" 
           class="star" 
           :style="getStarStyle(i)">
        ⭐
      </div>
      <div class="rabbit">🐰</div>
      <div class="lantern-group">
        <div v-for="i in 4" :key="`moon-lantern-${i}`" class="moon-lantern" :style="getMoonLanternStyle(i)">🏮</div>
      </div>
    </template>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch } from 'vue';

const props = defineProps({
  currentTheme: {
    type: String,
    default: 'normal'
  }
});

// 圣诞雪花样式
const getSnowflakeStyle = (index) => {
  return {
    left: `${Math.random() * 100}%`,
    animationDelay: `${Math.random() * 5}s`,
    animationDuration: `${5 + Math.random() * 5}s`,
    fontSize: `${0.5 + Math.random() * 1.5}em`,
    opacity: 0.6 + Math.random() * 0.4
  };
};

// 万圣节蝙蝠样式
const getBatStyle = (index) => {
  return {
    left: `${Math.random() * 100}%`,
    top: `${10 + Math.random() * 30}%`,
    animationDelay: `${Math.random() * 3}s`,
    animationDuration: `${3 + Math.random() * 4}s`,
    fontSize: `${1 + Math.random()}em`
  };
};

// 万圣节幽灵样式
const getGhostStyle = (index) => {
  return {
    left: `${Math.random() * 100}%`,
    top: `${30 + Math.random() * 40}%`,
    animationDelay: `${Math.random() * 4}s`,
    animationDuration: `${4 + Math.random() * 5}s`,
    fontSize: `${1.5 + Math.random() * 1.5}em`
  };
};

// 元旦彩纸样式
const getConfettiStyle = (index) => {
  const colors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff', '#ffa500'];
  return {
    left: `${Math.random() * 100}%`,
    backgroundColor: colors[index % colors.length],
    animationDelay: `${Math.random() * 3}s`,
    animationDuration: `${4 + Math.random() * 4}s`,
    width: `${5 + Math.random() * 10}px`,
    height: `${5 + Math.random() * 10}px`
  };
};

// 元旦烟花样式
const getFireworkStyle = (index) => {
  return {
    left: `${10 + index * 20}%`,
    top: `${20 + Math.random() * 30}%`,
    animationDelay: `${index * 0.5}s`,
    animationDuration: `${2 + Math.random() * 2}s`
  };
};

// 元旦灯笼样式
const getLanternStyle = (index) => {
  return {
    left: `${20 + index * 30}%`,
    top: `${5 + Math.random() * 10}%`,
    animationDelay: `${index * 0.3}s`,
    animationDuration: `${3 + Math.random() * 2}s`,
    fontSize: `${2 + Math.random()}em`
  };
};

// 春节鞭炮样式
const getFirecrackerStyle = (index) => {
  return {
    left: `${Math.random() * 100}%`,
    top: `${10 + Math.random() * 20}%`,
    animationDelay: `${Math.random() * 2}s`,
    animationDuration: `${2 + Math.random() * 3}s`,
    fontSize: `${1 + Math.random() * 0.5}em`
  };
};

// 春节花朵样式
const getFlowerStyle = (index) => {
  return {
    left: `${Math.random() * 100}%`,
    top: `${30 + Math.random() * 40}%`,
    animationDelay: `${Math.random() * 3}s`,
    animationDuration: `${4 + Math.random() * 4}s`,
    fontSize: `${1.5 + Math.random() * 1.5}em`
  };
};

// 情人节心形样式
const getHeartStyle = (index) => {
  return {
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    animationDelay: `${Math.random() * 3}s`,
    animationDuration: `${3 + Math.random() * 4}s`,
    fontSize: `${0.8 + Math.random() * 1.5}em`
  };
};

// 情人节玫瑰样式
const getRoseStyle = (index) => {
  return {
    left: `${10 + index * 10}%`,
    top: `${40 + Math.random() * 20}%`,
    animationDelay: `${index * 0.4}s`,
    animationDuration: `${3 + Math.random() * 2}s`,
    fontSize: `${1.5 + Math.random()}em`
  };
};

// 中秋节星星样式
const getStarStyle = (index) => {
  return {
    left: `${Math.random() * 100}%`,
    top: `${5 + Math.random() * 30}%`,
    animationDelay: `${Math.random() * 2}s`,
    animationDuration: `${2 + Math.random() * 3}s`,
    fontSize: `${0.8 + Math.random() * 1.2}em`
  };
};

// 中秋节灯笼样式
const getMoonLanternStyle = (index) => {
  return {
    left: `${15 + index * 20}%`,
    top: `${10 + Math.random() * 15}%`,
    animationDelay: `${index * 0.5}s`,
    animationDuration: `${4 + Math.random() * 2}s`,
    fontSize: `${1.5 + Math.random()}em`
  };
};
</script>

<style scoped>
.festival-effects {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
  z-index: 9999;
  overflow: hidden;
}

/* 圣诞主题样式 */
.snowflake {
  position: absolute;
  animation: snowfall linear infinite;
}

@keyframes snowfall {
  0% {
    transform: translateY(-20px) rotate(0deg);
  }
  100% {
    transform: translateY(100vh) rotate(360deg);
  }
}

.christmas-lights {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: 
    radial-gradient(circle at 10% 20%, rgba(255, 0, 0, 0.1) 0%, transparent 50%),
    radial-gradient(circle at 90% 80%, rgba(0, 255, 0, 0.1) 0%, transparent 50%),
    radial-gradient(circle at 50% 50%, rgba(255, 255, 0, 0.05) 0%, transparent 50%);
  animation: christmasGlow 3s ease-in-out infinite;
}

@keyframes christmasGlow {
  0%, 100% { opacity: 0.3; }
  50% { opacity: 0.6; }
}

/* 万圣节样式 */
.bat {
  position: absolute;
  animation: batFly ease-in-out infinite;
}

@keyframes batFly {
  0%, 100% {
    transform: translateX(0) translateY(0) rotate(0deg);
  }
  25% {
    transform: translateX(30px) translateY(-10px) rotate(10deg);
  }
  50% {
    transform: translateX(0) translateY(-20px) rotate(0deg);
  }
  75% {
    transform: translateX(-30px) translateY(-10px) rotate(-10deg);
  }
}

.ghost {
  position: absolute;
  animation: ghostFloat ease-in-out infinite;
}

@keyframes ghostFloat {
  0%, 100% {
    transform: translateY(0) scale(1);
    opacity: 0.7;
  }
  50% {
    transform: translateY(-30px) scale(1.1);
    opacity: 0.9;
  }
}

.spider-web {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: 
    repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(128, 128, 128, 0.03) 35px, rgba(128, 128, 128, 0.03) 70px);
  pointer-events: none;
}

/* 元旦样式 */
.confetti {
  position: absolute;
  animation: confettiFall linear infinite;
}

@keyframes confettiFall {
  0% {
    transform: translateY(-20px) rotate(0deg) scale(1);
    opacity: 1;
  }
  100% {
    transform: translateY(100vh) rotate(720deg) scale(0.5);
    opacity: 0;
  }
}

.firework {
  position: absolute;
  width: 4px;
  height: 4px;
  background: radial-gradient(circle, #ff0 0%, #f00 50%, transparent 100%);
  border-radius: 50%;
  animation: fireworkExplode ease-out infinite;
}

@keyframes fireworkExplode {
  0% {
    transform: scale(0);
    opacity: 1;
  }
  50% {
    transform: scale(50);
    opacity: 0.8;
  }
  100% {
    transform: scale(100);
    opacity: 0;
  }
}

.lantern-container {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 20%;
}

.lantern {
  position: absolute;
  animation: lanternSwing ease-in-out infinite;
}

@keyframes lanternSwing {
  0%, 100% {
    transform: rotate(-5deg);
  }
  50% {
    transform: rotate(5deg);
  }
}

/* 春节样式 */
.firecracker {
  position: absolute;
  animation: firecrackerPop ease-in-out infinite;
}

@keyframes firecrackerPop {
  0%, 100% {
    transform: scale(1);
    opacity: 0.8;
  }
  50% {
    transform: scale(1.3);
    opacity: 1;
  }
}

.flower {
  position: absolute;
  animation: flowerBloom ease-in-out infinite;
}

@keyframes flowerBloom {
  0%, 100% {
    transform: scale(1) rotate(0deg);
    opacity: 0.8;
  }
  50% {
    transform: scale(1.2) rotate(15deg);
    opacity: 1;
  }
}

.fu-character {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 8em;
  font-weight: bold;
  color: #ff0000;
  text-shadow: 0 0 20px rgba(255, 0, 0, 0.8);
  animation: fuGlow 2s ease-in-out infinite;
  z-index: 10000;
}

@keyframes fuGlow {
  0%, 100% {
    opacity: 0.3;
    transform: translate(-50%, -50%) scale(1);
  }
  50% {
    opacity: 0.6;
    transform: translate(-50%, -50%) scale(1.1);
  }
}

/* 情人节样式 */
.heart {
  position: absolute;
  animation: heartBeat ease-in-out infinite;
}

@keyframes heartBeat {
  0%, 100% {
    transform: scale(1);
  }
  25% {
    transform: scale(1.2);
  }
  50% {
    transform: scale(1);
  }
  75% {
    transform: scale(1.1);
  }
}

.rose-container {
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 30%;
}

.rose {
  position: absolute;
  animation: roseFloat ease-in-out infinite;
}

@keyframes roseFloat {
  0%, 100% {
    transform: translateY(0) rotate(-5deg);
  }
  50% {
    transform: translateY(-20px) rotate(5deg);
  }
}

/* 中秋节样式 */
.moon {
  position: fixed;
  top: 5%;
  right: 10%;
  font-size: 4em;
  animation: moonGlow 4s ease-in-out infinite;
}

@keyframes moonGlow {
  0%, 100% {
    filter: drop-shadow(0 0 10px rgba(255, 255, 200, 0.8));
    transform: scale(1);
  }
  50% {
    filter: drop-shadow(0 0 20px rgba(255, 255, 200, 1));
    transform: scale(1.1);
  }
}

.star {
  position: absolute;
  animation: starTwinkle ease-in-out infinite;
}

@keyframes starTwinkle {
  0%, 100% {
    opacity: 0.4;
    transform: scale(1);
  }
  50% {
    opacity: 1;
    transform: scale(1.3);
  }
}

.rabbit {
  position: fixed;
  bottom: 10%;
  left: 15%;
  font-size: 3em;
  animation: rabbitJump 3s ease-in-out infinite;
}

@keyframes rabbitJump {
  0%, 100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-20px);
  }
}

.lantern-group {
  position: fixed;
  top: 10%;
  left: 0;
  width: 100%;
}

.moon-lantern {
  position: absolute;
  animation: moonLanternSwing ease-in-out infinite;
}

@keyframes moonLanternSwing {
  0%, 100% {
    transform: rotate(-3deg);
  }
  50% {
    transform: rotate(3deg);
  }
}
</style>