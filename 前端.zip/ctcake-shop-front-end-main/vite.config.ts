import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

// https://vite.dev/config/
export default defineConfig({
  plugins: [vue()],
  server: {
    proxy: {
      '/apihvh': {
        target: 'https://static.hvhgod.onl/',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/apihvh/, '')
      },
      '/api': {  // 代理所有以 /api 开头的请求到本地后端
        target: 'http://202.189.7.62:20112/',
        changeOrigin: true,
        rewrite: (path) => path  // 保持路径不变，因为后端API路径相同
      }
    }
  }
}
)
