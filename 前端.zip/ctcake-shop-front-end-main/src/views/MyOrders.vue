<template>
  <div class="my-orders-container">
    <div class="orders-card">
      <div class="card-header">
        <div class="header-icon">
          <FileTextOutlined class="icon" />
        </div>
        <h2 class="orders-title">我的订单</h2>
        <div class="header-decoration"></div>
      </div>

      <div class="card-content">
        <div v-if="loading" class="loading-section">
          <a-spin size="large" />
          <p>正在加载订单信息...</p>
        </div>

        <div v-else-if="orders.length === 0" class="no-orders">
          <FileTextOutlined class="no-orders-icon" />
          <p>暂无订单记录</p>
          <router-link to="/" class="browse-products-btn">
            <a-button type="primary" size="large">
              浏览商品
            </a-button>
          </router-link>
        </div>

        <div v-else class="orders-list">
          <div v-for="order in orders" :key="order.order_id" class="order-item"
            :class="{ 'order-item-pending': order.status === 'pending' }">
            <div class="order-header">
              <div class="order-id">订单号: {{ order.order_id }}</div>
              <div class="order-status" :class="order.status">{{ getStatusText(order.status) }}</div>
            </div>

            <div class="order-details">
              <div class="order-info">
                <div class="info-row">
                  <div class="info-item">
                    <span class="info-label">商品类型:</span>
                    <span class="info-value">{{ order.product_type === 'sub' ? 'FA续费' : 'FAT购买' }}</span>
                  </div>
                  <div class="info-item">
                    <span class="info-label">金额:</span>
                    <span class="info-value amount">¥{{ order.amount }}</span>
                  </div>
                </div>
                <div class="info-row">
                  <div class="info-item">
                    <span class="info-label">创建时间:</span>
                    <span class="info-value">{{ formatDate(order.created_at) }}</span>
                  </div>
                </div>
                <!-- <div v-if="order.status === 'paid'" class="info-row">
                  <div class="info-item">
                    <span class="info-label">支付时间:</span>
                    <span class="info-value">{{ formatDate(order.paid_at) }}</span>
                  </div>
                </div> -->
              </div>
            </div>

            <div class="order-actions">
              <a-button v-if="order.status === 'pending' && !isOrderExpired(order)" type="primary"
                @click="goToPayment(order)" :disabled="isOrderExpired(order)">
                {{ isOrderExpired(order) ? '订单已过期' : '前往支付' }}
              </a-button>

              <a-button v-else-if="order.status === 'paid'" @click="viewOrderResult(order)">
                查看执行结果
              </a-button>

              <div v-if="order.status === 'pending' && isOrderExpired(order)" class="expired-note">
                订单已超过5分钟未支付，已过期
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import { message } from 'ant-design-vue';
import { FileTextOutlined } from '@ant-design/icons-vue';
import axios from 'axios';
import FingerprintJS from '@fingerprintjs/fingerprintjs';

const router = useRouter();
const orders = ref([]);
const loading = ref(true);

// 获取浏览器指纹
const getBrowserFingerprint = async () => {
  const fp = await FingerprintJS.load();
  const result = await fp.get();
  return result.visitorId;
};

// 加载订单
const loadOrders = async () => {
  try {
    const fingerprint = await getBrowserFingerprint();

    const response = await axios.post('/api/orders-by-fingerprint', {
      browser_fingerprint: fingerprint
    });

    orders.value = response.data.all_orders || [];
  } catch (error) {
    console.error('加载订单失败:', error);
    message.error('加载订单失败');
    orders.value = [];
  } finally {
    loading.value = false;
  }
};

// 获取状态文本
const getStatusText = (status) => {
  switch (status) {
    case 'pending': return '待支付';
    case 'paid': return '已支付';
    case 'expired': return '已过期';
    case 'cancelled': return '已取消';
    default: return status;
  }
};

// 格式化日期
const formatDate = (dateString) => {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleString('zh-CN');
};

// 检查订单是否过期
const isOrderExpired = (order) => {
  if (order.status !== 'pending') return false;

  const createdTime = new Date(order.created_at).getTime();
  const currentTime = new Date().getTime();
  const timeDiff = (currentTime - createdTime) / (1000 * 60); // 转换为分钟

  return timeDiff > 5; // 5分钟过期
};

// 前往支付
const goToPayment = (order) => {
  if (isOrderExpired(order)) {
    message.warning('订单已过期，无法支付');
    return;
  }

  // 无论支付方式如何，都只跳转到等待页面，由等待页面处理后续逻辑
  router.push(`/buy/waiting?order_id=${order.order_id}`);
};

// 查看订单结果
const viewOrderResult = (order) => {
  // 跳转到订单状态页面
  router.push(`/order-status?order_id=${order.order_id}`);
};

onMounted(() => {
  loadOrders();
});
</script>

<style scoped lang="less">
.my-orders-container {
  min-height: 100vh;
  padding: 40px 20px;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  
}

.orders-card {
  width: 100%;
  max-width: 800px;
  background: #ffffff;
  border-radius: 20px;
  box-shadow:
    0 10px 40px rgba(0, 0, 0, 0.08),
    0 4px 15px rgba(0, 0, 0, 0.06);
  position: relative;
  border: 1px solid rgba(226, 232, 240, 0.5);
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);

  &:hover {
    transform: translateY(-5px);
    box-shadow:
      0 15px 50px rgba(0, 0, 0, 0.1),
      0 6px 20px rgba(0, 0, 0, 0.08);
  }

  .card-header {
    position: relative;
    padding: 28px 32px 20px;
    
    border-bottom: 1px solid rgba(226, 232, 240, 0.6);

    .header-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 44px;
      height: 44px;
      background: linear-gradient(135deg, #1677ff 0%, #096dd9 100%);
      border-radius: 12px;
      margin-bottom: 12px;
    }

    .icon {
      font-size: 22px;
      color: white;
    }

    .orders-title {
      margin: 0;
      font-size: 22px;
      font-weight: 700;
      color: #111827;
      letter-spacing: 0.5px;
      background: linear-gradient(135deg, #1677ff 0%, #096dd9 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .header-decoration {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 4px;
      background: linear-gradient(90deg, #1677ff 0%, #096dd9 100%);
    }
  }

  .card-content {
    padding: 20px 32px 40px;
  }

  .loading-section {
    text-align: center;
    padding: 60px 0;

    p {
      margin-top: 16px;
      color: #6b7280;
    }
  }

  .no-orders {
    text-align: center;
    padding: 60px 20px;

    .no-orders-icon {
      font-size: 80px;
      color: #d1d5db;
      margin-bottom: 20px;
    }

    p {
      font-size: 18px;
      color: #6b7280;
      margin-bottom: 25px;
    }

    .browse-products-btn {
      display: inline-block;
    }
  }

  .orders-list {
    .order-item {
      border: 1px solid #e5e7eb;
      border-radius: 16px;
      padding: 24px;
      margin-bottom: 20px;
      transition: all 0.3s ease;
      background: #f8fafc;

      &:hover {
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        transform: translateY(-3px);
        border-color: rgba(22, 119, 255, 0.3);
      }

      &.order-item-pending {
        border-left: 4px solid #f59e0b;
      }

      .order-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 18px;
        flex-wrap: wrap;
        gap: 10px;

        .order-id {
          font-weight: 600;
          color: #111827;
          font-size: 16px;
        }

        .order-status {
          padding: 6px 12px;
          border-radius: 20px;
          font-size: 13px;
          font-weight: 500;

          &.pending {
            background: linear-gradient(135deg, #fef3c7 0%, #fcd34d 100%);
            color: #d97706;
          }

          &.paid {
            background: linear-gradient(135deg, #d1fae5 0%, #6ee7b7 100%);
            color: #059669;
          }

          &.expired {
            background: linear-gradient(135deg, #fee2e2 0%, #fca5a5 100%);
            color: #dc2626;
          }

          &.cancelled {
            background: linear-gradient(135deg, #e5e7eb 0%, #d1d5db 100%);
            color: #6b7280;
          }
        }
      }

      .order-details {
        .order-info {
          .info-row {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 15px;

            &:last-child {
              margin-bottom: 0;
            }

            .info-item {
              flex: 1;
              min-width: 200px;

              .info-label {
                font-weight: 500;
                color: #4b5563;
                margin-right: 8px;
              }

              .info-value {
                color: #1f2937;

                &.amount {
                  font-weight: 600;
                  color: #059669;
                }
              }
            }
          }
        }
      }

      .order-actions {
        margin-top: 24px;
        display: flex;
        justify-content: flex-end;

        .expired-note {
          color: #dc2626;
          font-size: 13px;
          margin-top: 8px;
          text-align: right;
          padding: 8px 12px;
          background: #fef2f2;
          border-radius: 6px;
          border-left: 3px solid #dc2626;
        }
      }
    }
  }
}

@media (max-width: 768px) {
  .orders-card {
    width: 95%;
    margin: 20px auto;

    .card-content {
      padding: 20px 20px 30px;
    }

    .order-header {
      flex-direction: column;
      align-items: flex-start;

      .order-status {
        align-self: flex-end;
      }
    }

    .info-row {
      flex-direction: column !important;
      gap: 10px !important;
    }

    .info-item {
      min-width: auto !important;
    }
  }
}
</style>