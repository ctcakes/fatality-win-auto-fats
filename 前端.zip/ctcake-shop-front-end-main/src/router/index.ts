import { createWebHashHistory, createRouter } from 'vue-router'

import IndexView from '../views/IndexView.vue'
import WaitingPay from '../views/WaitingPay.vue'
import ResultView from '../views/ResultView.vue'
import OrderStatus from '../views/OrderStatus.vue'
import MyOrders from '../views/MyOrders.vue'
import QueryOrder from '../views/QueryOrder.vue'
import AdminPanel from '../views/AdminPanel.vue'
import UI from '../views/UserInfoAgreement.vue'
const routes = [
  { path: '/', component: IndexView },
  { path: '/buy/fat', component: () => import('../views/BuyFat.vue') },
  { path: '/buy/sub', component: () => import('../views/BuySub.vue') },
  { path: '/buy/waiting', component: WaitingPay },
  { path: '/buy/result', component: ResultView },
  { path: '/order-status', component: OrderStatus },
  { path: '/my-orders', component: MyOrders },
  { path: '/query-order', component: QueryOrder },
  { path: '/agreement-refund', component: () => import('../views/refund.vue') },
  { path: '/admin', component: AdminPanel },
  { path: '/ui-agreement', component: UI },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes,
})

// 路由守卫 - 在路由切换开始时显示加载状态
router.beforeEach((to, from, next) => {
  // 触发全局事件，通知App组件显示加载状态
  window.dispatchEvent(new CustomEvent('route-change-start'));
  next();
});

// 路由守卫 - 在路由切换完成后隐藏加载状态
router.afterEach(() => {
  // 稍微延迟以确保页面内容已渲染
  setTimeout(() => {
    window.dispatchEvent(new CustomEvent('route-change-end'));
  }, 100);
});

export default router