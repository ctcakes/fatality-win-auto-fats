<template>
  <div class="index-container">
    <div class="welcome-banner">
      <h1 class="welcome-title">欢迎来到CTCAKE Shop Fats$专卖店</h1>
      <p class="welcome-subtitle">{{ festivalText }}</p>
    </div>

    <!-- 公告卡片 -->
    <div class="announcement-card">
      <div class="card-header">
        <div class="header-icon">
          <NotificationOutlined class="icon" />
        </div>
        <h2 class="card-title">平台公告</h2>
        <div class="header-decoration"></div>
      </div>
      <div class="card-content">
        <div class="notice-content" v-html="notice_html"></div>
      </div>
    </div>
    <!-- 商品分类卡片 -->
    <div class="product-card">
      <div class="card-header">
        <div class="header-icon">
          <AppstoreOutlined class="icon" />
        </div>
        <h2 class="card-title">热门商品</h2>
        <div class="header-decoration"></div>
      </div>
      <div class="card-content">
        <div class="product-grid">
          <!-- FAT$购买 -->
          <router-link to="/buy/fat" class="product-item">
            <div class="product-card-item">
              <div class="product-icon">
                <DollarCircleFilled class="item-icon" />
              </div>
              <h3 class="product-title">[秒到账]FAT$购买</h3>
              <p class="product-desc">论坛Workshop代币Fat$</p>
              <div class="product-tag">{{ fatPrice }}￥</div>
            </div>
          </router-link>

          <!-- FA续费购买 -->
          <!-- <router-link to="/buy/sub" class="product-item">
            <div class="product-card-item">
              <div class="product-icon">
                <GiftFilled class="item-icon" />
              </div>
              <h3 class="product-title">[自动发货]FA 30天续费购买</h3>
              <p class="product-desc">一个月Fatality续费，CS2+CSGO</p>
              <div class="product-tag" :class="{ 'sale-tag': isSaleActive }">{{ displaySubPrice }}￥/月</div>
            </div>
          </router-link> -->
        </div>
      </div>
    </div>
    <!-- 特色服务卡片 -->
    <div class="feature-card">
      <div class="card-header">
        <div class="header-icon">
          <RocketOutlined class="icon" />
        </div>
        <h2 class="card-title">数据统计</h2>
        <h4 style="margin-top: 5px;color: #94a3b8;">用户名为购买者的FA论坛用户名，均在后端隐私处理，无须担心。</h4>
        <div class="header-decoration"></div>
      </div>
      <div class="card-content">
        <div class="feature-grid">
          <div class="feature-item">
            <div class="feature-icon">
              <ThunderboltOutlined class="item-icon" />
            </div>
            <h4 class="feature-title">购买最多FAT的用户</h4>
            <p class="feature-desc">用户 {{ fats.most_fat }}，他在网站总计购买了 {{ fats.most_fat_fats }} 个fat。</p>
          </div>
          <div class="feature-item">
            <div class="feature-icon">
              <SafetyCertificateOutlined class="item-icon" />
            </div>
            <h4 class="feature-title">最多订单的用户</h4>
            <p class="feature-desc">用户 {{ fats.most_user }}，TA在网站下了 {{ fats.most_user_order_count }} 次单。</p>
          </div>
          <div class="feature-item">
            <div class="feature-icon">
              <CustomerServiceOutlined class="item-icon" />
            </div>
            <h4 class="feature-title">卡网总计</h4>
            <p class="feature-desc">运营至今，卡网共销售 {{ fats.fats }} 个FAT。</p>
          </div>
        </div>
      </div>
    </div>



  </div>
</template>

<script setup>

import { ref, onMounted, computed } from 'vue';

import axios from 'axios';

import {

  NotificationOutlined,

  DollarCircleFilled,

  GiftFilled,

  AppstoreOutlined,

  RocketOutlined,

  ThunderboltOutlined,

  SafetyCertificateOutlined,

  CustomerServiceOutlined

} from '@ant-design/icons-vue';



const loading = ref(true);

const notice_html = ref('群635505571，售后316915824。<br>2026.1.21:<br>卡网后端全新升级，更换原来效率低下的实现方式，实现真正的"秒到账"。经过测试，整个过程(支付成功到FAT到账)大约只需要5秒。<br>我们支持输错用户名自动退款，详情请参阅<a href="#/agreement-refund/">退款准则</a>。点击支付即表示您同意<a href="#/agreement-refund">退款准则</a>及<a href="#/ui-agreement" >信息收集行为</a>');

const fats = ref({ fats: 0, most_fat: '', most_fat_fats: 0, most_user: '', most_user_order_count: 0 });
const get_fats = async () => {
  try {
    const response = await axios.get('/api/fats');
    fats.value = response.data;
  } catch (error) {
    console.error('获取FAT数据失败:', error);
  }
}

// 动态价格
const festivalText = ref('');
const fatPrice = ref(0.75);

const subPrice = ref(198.0);

const saleSubPrice = ref(0.0);

const isSaleActive = ref(false);



// 计算显示价格

const displaySubPrice = computed(() => {

  return isSaleActive.value && saleSubPrice.value > 0 ? saleSubPrice.value : subPrice.value;

});



// 获取价格设置

const fetchPriceSettings = async () => {

  try {

    const response = await axios.get('/api/theme-settings');

    if (response.data.fat_price !== undefined) {

      fatPrice.value = response.data.fat_price;

    }

    if (response.data.sub_price !== undefined) {

      subPrice.value = response.data.sub_price;

    }

    if (response.data.sale_sub_price !== undefined) {

      saleSubPrice.value = response.data.sale_sub_price;

    }

    if (response.data.is_sale_active !== undefined) {

      isSaleActive.value = response.data.is_sale_active;

    }

    if (response.data.theme === 'newyear') {
      const now = new Date();

      const newYear = new Date(now.getFullYear(), 0, 1);      // 元旦
      const springFestival = new Date(2026, 1, 17);           // 2026-02-17

      const dayMs = 1000 * 60 * 60 * 24;
      const diffToSpring = Math.ceil((springFestival - now) / dayMs);

      // 元旦前后
      if (
        (now.getMonth() === 11 && now.getDate() >= 25) ||
        (now.getMonth() === 0 && now.getDate() <= 7)
      ) {
        festivalText.value = '元旦快乐！';
      }
      // 春节当天及一周内
      else if (diffToSpring >= 0 && diffToSpring <= 7) {
        festivalText.value = '春节快乐！';
      }
      // 春节之前
      else if (diffToSpring > 7) {
        festivalText.value = `提前祝您春节快乐！距离春节还有${diffToSpring}天！`;
      }
    }
  } catch (error) {

    console.error('获取价格设置失败:', error);

    // 如果获取失败，保持默认值

  }

};



onMounted(() => {

  fetchPriceSettings();
  get_fats();
});

</script>

<style scoped>
.index-container {
  padding: 40px 20px 60px;
  min-height: calc(100vh - 72px);
  /* background: linear-gradient(135deg, #f0f5ff 0%, #f6f9ff 100%); */
  display: flex;
  flex-direction: column;
  align-items: center;
}

.welcome-banner {
  text-align: center;
  margin-bottom: 40px;
  width: 100%;
  max-width: 800px;
}

.welcome-title {
  font-size: 36px;
  font-weight: 700;
  color: #111827;
  margin: 0 0 12px 0;
  letter-spacing: 0.5px;
  background: linear-gradient(135deg, #07c160 0%, #1677ff 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.welcome-subtitle {
  font-size: 18px;
  color: #6b7280;
  margin: 0;
  line-height: 1.5;
}

/* 通用卡片样式 */
.announcement-card,
.product-card,
.feature-card {
  width: 100%;
  max-width: 800px;
  background: #ffffff;
  border-radius: 20px;
  box-shadow:
    0 10px 40px rgba(0, 0, 0, 0.05),
    0 4px 15px rgba(0, 0, 0, 0.03);
  overflow: hidden;
  margin-bottom: 30px;
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
  position: relative;
}

.announcement-card:hover,
.product-card:hover,
.feature-card:hover {
  transform: translateY(-5px);
  box-shadow:
    0 15px 50px rgba(0, 0, 0, 0.08),
    0 6px 20px rgba(0, 0, 0, 0.06);
}

/* 卡片头部样式 */
.card-header {
  position: relative;
  padding: 28px 32px 20px;
  /* background: linear-gradient(135deg, #f8fafc 0%, #eef2f7 100%); */
  border-bottom: 1px solid rgba(226, 232, 240, 0.6);
}

.header-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 44px;
  height: 44px;
  background: linear-gradient(135deg, #1677ff 0%, #096dd9 100%);
  border-radius: 12px;
  margin-bottom: 12px;
}

.icon {
  font-size: 22px;
  color: white;
}

.card-title {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  color: #111827;
  letter-spacing: 0.5px;
  background: linear-gradient(135deg, #1677ff 0%, #096dd9 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}

.header-decoration {
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 4px;
  background: linear-gradient(90deg, #1677ff 0%, #096dd9 100%);
}

/* 卡片内容区域 */
.card-content {
  padding: 30px 32px;
}

.notice-content {
  font-size: 16px;
  line-height: 1.7;
  color: #374151;
  text-align: justify;
  padding: 10px 0;
}

/* 商品网格布局 */
.product-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 24px;
}

.product-item {
  text-decoration: none;
  display: block;
}

.product-card-item {
  background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
  border-radius: 16px;
  padding: 30px 25px;
  text-align: center;
  border: 1px solid rgba(226, 232, 240, 0.5);
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.product-card-item::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
  transition: 0.5s;
}

.product-card-item:hover::before {
  left: 100%;
}

.product-card-item:hover {
  transform: translateY(-8px);
  box-shadow:
    0 12px 30px rgba(0, 0, 0, 0.1),
    0 6px 15px rgba(0, 0, 0, 0.05);
  border-color: rgba(22, 119, 255, 0.3);
}

.product-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 70px;
  height: 70px;
  margin: 0 auto 18px;
  background: linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%);
  border-radius: 50%;
  transition: all 0.3s ease;
}

.product-card-item:hover .product-icon {
  transform: scale(1.1);
  background: linear-gradient(135deg, #bae6fd 0%, #7dd3fc 100%);
}

.item-icon {
  font-size: 32px;
  color: #1677ff;
}

.product-title {
  margin: 0 0 12px;
  font-size: 18px;
  font-weight: 600;
  color: #1f2937;
  line-height: 1.4;
}

.product-desc {
  margin: 0 0 20px;
  font-size: 14px;
  color: #6b7280;
  line-height: 1.5;
}

.product-tag {
  display: inline-block;
  padding: 6px 14px;
  background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
  color: white;
  font-size: 12px;
  font-weight: 600;
  border-radius: 20px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.sale-tag {
  background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%) !important;
}

/* 特色服务网格 */
.feature-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 30px;
  margin-top: 10px;
}

.feature-item {
  text-align: center;
  padding: 20px;
  border-radius: 16px;
  background: #f8fafc;
  transition: all 0.3s ease;
}

.feature-item:hover {
  transform: translateY(-5px);
  background: #f1f5f9;
  box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
}

.feature-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 60px;
  height: 60px;
  margin: 0 auto 16px;
  background: linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%);
  border-radius: 50%;
  transition: all 0.3s ease;
}

.feature-item:hover .feature-icon {
  transform: scale(1.1);
  background: linear-gradient(135deg, #bae6fd 0%, #7dd3fc 100%);
}

.feature-title {
  margin: 0 0 10px;
  font-size: 16px;
  font-weight: 600;
  color: #1f2937;
}

.feature-desc {
  margin: 0;
  font-size: 14px;
  color: #6b7280;
  line-height: 1.5;
}

.item-icon {
  font-size: 24px;
  color: #1677ff;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .index-container {
    padding: 30px 15px 50px;
  }

  .welcome-title {
    font-size: 28px;
  }

  .welcome-subtitle {
    font-size: 16px;
  }

  .card-header {
    padding: 24px 20px 16px;
  }

  .card-content {
    padding: 24px 20px;
  }

  .product-grid,
  .feature-grid {
    grid-template-columns: 1fr;
  }

  .card-title {
    font-size: 20px;
  }

  .product-card-item {
    padding: 24px 20px;
  }

  .product-icon {
    width: 60px;
    height: 60px;
    margin: 0 auto 15px;
  }

  .product-title {
    font-size: 17px;
  }

  .product-desc {
    font-size: 13px;
  }

  .feature-grid {
    gap: 20px;
  }

  .feature-item {
    padding: 15px;
  }
}
</style>