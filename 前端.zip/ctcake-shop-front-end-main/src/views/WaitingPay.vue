<template>
  <div class="waiting-pay-container">
    <div class="waiting-pay-card">
      <div class="card-header">
        <div class="header-icon" v-if="isOrderExpiredOrClosed">
          <CloseOutlined class="icon" />
        </div>
        <div class="header-icon" v-else-if="!isQrCodePayment">
          <LoadingOutlined class="icon icon-spin" />
        </div>
        <div class="header-icon" v-else>
          <QrcodeOutlined class="icon" />
        </div>
        <h2 class="waiting-title">{{ isOrderExpiredOrClosed ? '订单已过期' : (isQrCodePayment ? '扫码支付' : '等待支付') }}</h2>
        <div class="header-decoration"></div>
      </div>

      <div class="card-content">
        <p class="waiting-desc">
          {{ isOrderExpiredOrClosed ? '订单已过期或已关闭，无法支付' : (isQrCodePayment ? '请使用手机扫码完成支付' :
          '请在新打开的页面中完成支付，我们将在后台自动检测支付状态') }}
        </p>

        <div class="payment-info">
          <div class="info-card">
            <div class="info-item">
              <div class="info-label">订单号</div>
              <div class="info-value order-id">{{ orderId }}</div>
            </div>
          </div>
          <div class="info-card">
            <div class="info-label">支付方式</div>
            <div class="info-value">{{ paymentMethodText }}</div>
          </div>
          <div class="info-card">
            <div class="info-label">剩余时间</div>
            <div class="info-value countdown" :class="{ 'expired': countdown <= 0 }">
              {{ countdown > 0 ? formatTime(countdown) : '订单已过期' }}
            </div>
          </div>
        </div>

        <!-- 二维码显示区域 -->
        <div v-if="isQrCodePayment && qrCodeContent && !isOrderExpiredOrClosed" class="qrcode-container">
          <div class="qrcode-wrapper">
            <qrcode-vue v-if="qrCodeContent !== ''" :value="qrCodeContent" :size="200" level="H" class="qrcode-image" />
          </div>
          <p class="qrcode-tip">请使用手机扫码完成支付</p>
        </div>

        <div class="countdown-progress">
          <div class="progress-bar">
            <div class="progress-fill" :style="{ width: progressPercentage + '%' }"></div>
          </div>
          <div class="progress-text">{{ countdown > 0 ? formatTime(countdown) : '00:00' }}</div>
        </div>

        <div class="action-buttons">
          <a-button @click="checkStatus" :loading="checkingStatus" class="check-btn">
            <template #icon>
              <ReloadOutlined />
            </template>
            刷新支付状态
          </a-button>
          <a-button @click="goBackToBuy" class="back-btn">
            <template #icon>
              <ArrowLeftOutlined />
            </template>
            返回购买页面
          </a-button>
          <a-button v-if="countdown > 0 && !isOrderExpiredOrClosed && !isQrCodePayment" @click="rePay"
            class="re-pay-btn repay-btn-white" :disabled="!orderId">
            <template #icon>
              <LinkOutlined />
            </template>
            {{ isQrCodePayment ? '' : '重新支付' }}
          </a-button>
        </div>
        <div class="tips-section">
          <h4>无法支付？</h4>
          <ul>
            <li>如果没有弹出支付页面请<a :href="ex_payurl" target="_blank">点击这里</a>。</li>
            <li>或者复制以下链接到浏览器打开支付页面：</li>
          </ul>
          <a-input :value="ex_payurl" readonly style="width: 100%;" />
        </div>
        <div class="tips-section">
          <h4>💡 支付提示</h4>
          <ul>
            <li v-if="!isQrCodePayment">请在新打开的支付页面完成支付操作</li>
            <li v-else>请使用手机扫码完成支付操作</li>
            <li>支付完成后，系统将自动检测并更新订单状态</li>
            <li>如果长时间未更新，请手动点击"刷新支付状态"按钮</li>
            <li>订单5分钟内未支付将自动过期</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import {
  LoadingOutlined,
  ReloadOutlined,
  ArrowLeftOutlined,
  LinkOutlined,
  QrcodeOutlined,
  CloseOutlined
} from '@ant-design/icons-vue';
import { message } from 'ant-design-vue';
import axios from 'axios';
import QrcodeVue from 'qrcode.vue';

// 已经打开过支付页面的标记
const hasOpenedPayment = ref(false);

// 计算进度百分比 - 倒计时进度条
const progressPercentage = computed(() => {
  // 初始倒计时为300秒，随着倒计时减少，进度条也减少
  return (countdown.value / 300) * 100;
});

// 检查是否为二维码支付 - 考虑订单过期状态和订单状态
const isQrCodePayment = computed(() => {
  // 检查订单是否过期或已取消/关闭
  if (countdown.value <= 0 || (orderData.value && ['cancelled', 'closed', 'expired'].includes(orderData.value.pay_status || orderData.value.status))) {
    return false; // 订单过期或已取消/关闭后不再显示二维码
  }

  return orderData.value && orderData.value.pay_url && orderData.value.pay_url.startsWith('qr-');
});

// 二维码内容 - 考虑订单过期状态和订单状态
const qrCodeContent = computed(() => {
  // 检查订单是否过期或已取消/关闭
  if (countdown.value <= 0 || (orderData.value && ['cancelled', 'closed', 'expired'].includes(orderData.value.pay_status || orderData.value.status))) {
    return null; // 订单过期或已取消/关闭后不返回二维码内容
  }

  if (orderData.value && orderData.value.pay_url && orderData.value.pay_url.startsWith('qr-')) {
    // 移除 'qr-' 前缀，获取二维码内容
    return orderData.value.pay_url.substring(3);
  }
  return null;
});

// 检查订单是否已过期或关闭
const isOrderExpiredOrClosed = computed(() => {
  return countdown.value <= 0 ||
    (orderData.value && ['cancelled', 'closed', 'expired'].includes(orderData.value.pay_status || orderData.value.status));
});

// 订单数据
const orderData = ref(null);

// 重新支付功能 - 修改以处理二维码支付
const rePay = async () => {
  try {
    // 获取订单信息，包括支付链接
    const response = await axios.get(`/api/order-status/${orderId.value}`);
    orderData.value = response.data;

    if (response.data.pay_url) {
      if (response.data.pay_url.startsWith('qr-')) {
        // 这是二维码支付，获取原始二维码URL并打开
        const originalQrCodeUrl = response.data.pay_url.substring(3);
        window.open(originalQrCodeUrl, '_blank');
        message.info('已重新打开支付页面，请扫码完成支付');
        hasOpenedPayment.value = true;
      } else {
        // 这是链接支付，打开新窗口
        window.open(response.data.pay_url, '_blank');
        hasOpenedPayment.value = true;
      }
    } else if (response.data.qrcode) {
      // 如果没有pay_url但有qrcode，使用qrcode
      window.open(response.data.qrcode, '_blank');
      message.info('已重新打开支付页面，请扫码完成支付');
      hasOpenedPayment.value = true;
    } else {
      message.error('无法获取支付信息，请重新下单');
    }
  } catch (error) {
    console.error('获取支付信息失败:', error);
    message.error('获取支付信息失败');
  }
};
const ex_payurl = ref(''); //扩展_手动添加 payurl
const route = useRoute();
const router = useRouter();

const orderId = ref('');
const paymentMethod = ref('');
const checkingStatus = ref(false);
const checkInterval = ref(null);
const countdown = ref(300); // 5分钟倒计时（300秒）

// 添加倒计时相关逻辑
const countdownInterval = ref(null);
const countdownFinished = computed(() => countdown.value <= 0);

// 倒计时逻辑
const startCountdown = () => {
  if (countdownInterval.value) {
    clearInterval(countdownInterval.value);
  }

  countdownInterval.value = setInterval(() => {
    if (countdown.value > 0) {
      countdown.value--;
    } else {
      // 倒计时结束，停止轮询
      if (checkInterval.value) {
        clearInterval(checkInterval.value);
      }
      // 倒计时结束时，再次检查订单状态，因为后端可能已更新状态
      checkStatus();
    }
  }, 1000);
};

// 根据支付方式显示文本
const paymentMethodText = ref('');

// 获取初始订单信息
const fetchOrderInfo = async () => {
  try {
    const response = await axios.get(`/api/order-status/${orderId.value}`);
    orderData.value = response.data;

    // 从后端获取支付方式，而不是依赖URL参数
    if (orderData.value.payment_method) {
      paymentMethod.value = orderData.value.payment_method;
      paymentMethodText.value = paymentMethod.value === 'alipay' ? '支付宝' :
        paymentMethod.value === 'wechat' ? '微信支付' :
          '未知';
    } else {
      console.log("API does not return payment_method");
    }

    // 检查订单是否已过期或已取消/关闭
    const isExpiredOrClosed = ['cancelled', 'closed', 'expired'].includes(response.data.pay_status) ||
      (response.data.status && ['cancelled', 'closed', 'expired'].includes(response.data.status));

    // 只在第一次打开页面且订单未过期时自动打开支付页面（如果不是二维码支付）
    if (!hasOpenedPayment.value && !isExpiredOrClosed) {
      if (response.data.pay_url && !response.data.pay_url.startsWith('qr-')) {
        window.open(response.data.pay_url, '_blank');
        ex_payurl.value = response.data.pay_url;
        hasOpenedPayment.value = true;
      } else if (response.data.qrcode && !response.data.pay_url) {
        // 如果没有pay_url但有qrcode，也自动打开（这种情况下的二维码作为URL）
        window.open(response.data.qrcode, '_blank');
        hasOpenedPayment.value = true;
      }
    }
  } catch (error) {
    console.error('获取订单信息失败:', error);
    message.error('获取订单信息失败');
  }
};

onMounted(() => {
  // 从URL参数获取订单ID
  orderId.value = route.query.order_id;

  if (!orderId.value) {
    message.error('缺少订单ID参数');
    router.push('/');
    return;
  }

  // 获取初始订单信息
  fetchOrderInfo();

  // 开始定时检查订单状态
  startCheckingStatus();

  // 开始倒计时
  startCountdown();
});

// 开始定时检查订单状态
const startCheckingStatus = () => {
  // 立即检查一次
  checkStatus();

  // 每3秒检查一次订单状态
  checkInterval.value = setInterval(() => {
    checkStatus();
  }, 3000);
};

// 检查订单状态
const checkStatus = async () => {
  if (checkingStatus.value) return;

  checkingStatus.value = true;

  try {
    const response = await axios.get(`/api/order-status/${orderId.value}`);
    // 更新orderData以确保二维码信息是最新的
    if (!response.data.pay_url && response.data.qrcode) {
      response.data.pay_url = 'qr-' + response.data.qrcode;
    }
    orderData.value = response.data;

    const status = response.data.pay_status || response.data.status;
    const remainingTime = response.data.remaining_time; // 获取剩余时间
    if (remainingTime == undefined && status !== 'paid') {
      // 在支付成功之前，如果获取不到剩余时间但订单未被标记为已支付，给出提示但不跳转
      if (!['paid', 'cancelled', 'closed', 'expired'].includes(status)) {
        console.warn('无法获取订单剩余时间，但订单状态仍为:', status);
        // 不跳转，继续轮询检查状态
      }
    }
    // 更新倒计时
    if (remainingTime !== undefined && remainingTime !== null) {
      countdown.value = Math.floor(remainingTime);
    }

    if (status === 'paid') {
      // 支付成功，跳转到订单结果页面
      message.success('支付成功！');
      clearInterval(checkInterval.value);
      router.push(`/buy/result?order_id=${orderId.value}&status=paid`);
    } else if (status === 'cancelled' || status === 'closed' || status === 'expired') {
      message.warning('订单已取消、关闭或过期');
      clearInterval(checkInterval.value); // 停止轮询
      countdown.value = 0; // 设置倒计时为0，以便计算属性正确更新
      clearInterval(countdownInterval.value); // 停止倒计时
    } else {
      // 继续等待支付
      console.log('继续等待支付...');
    }
  } catch (error) {
    console.error('检查订单状态失败:', error);
    message.error('检查订单状态失败');
  } finally {
    checkingStatus.value = false;
  }
};

// 返回购买页面
const goBackToBuy = () => {
  if (checkInterval.value) {
    clearInterval(checkInterval.value);
  }
  router.push('/');
};


// 组件卸载时清理定时器
onUnmounted(() => {
  if (checkInterval.value) {
    clearInterval(checkInterval.value);
  }
  if (countdownInterval.value) {
    clearInterval(countdownInterval.value);
  }
});

// 格式化时间显示
const formatTime = (seconds) => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

</script>

<style scoped lang="less">
.waiting-pay-container {
  min-height: 100vh;
  padding: 40px 20px;
  display: flex;
  align-items: flex-start;
  justify-content: center;

}

.waiting-pay-card {
  width: 100%;
  max-width: 500px;
  background: #ffffff;
  border-radius: 20px;
  box-shadow:
    0 10px 40px rgba(0, 0, 0, 0.08),
    0 4px 15px rgba(0, 0, 0, 0.06);
  position: relative;
  border: 1px solid rgba(226, 232, 240, 0.5);
  transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);

  &:hover {
    transform: translateY(-5px);
    box-shadow:
      0 15px 50px rgba(0, 0, 0, 0.1),
      0 6px 20px rgba(0, 0, 0, 0.08);
  }

  .card-header {
    position: relative;
    padding: 28px 32px 20px;
    // background: linear-gradient(135deg, #f8fafc 0%, #eef2f7 100%);
    border-bottom: 1px solid rgba(226, 232, 240, 0.6);

    .header-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 44px;
      height: 44px;
      background: linear-gradient(135deg, #1677ff 0%, #096dd9 100%);
      border-radius: 12px;
      margin-bottom: 12px;
    }

    .icon {
      font-size: 22px;
      color: white;

      &.icon-spin {
        animation: spin 1s linear infinite;
      }
    }

    .waiting-title {
      margin: 0;
      font-size: 22px;
      font-weight: 700;
      color: #111827;
      letter-spacing: 0.5px;
      background: linear-gradient(135deg, #1677ff 0%, #096dd9 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .header-decoration {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 100%;
      height: 4px;
      background: linear-gradient(90deg, #1677ff 0%, #096dd9 100%);
    }
  }

  .card-content {
    padding: 20px 32px 32px;
  }

  .waiting-desc {
    font-size: 16px;
    color: #6b7280;
    margin: 10px 0 20px;
    text-align: center;
    line-height: 1.5;
  }

  .payment-info {
    display: flex;
    gap: 12px;
    margin: 0 0 20px 0;
    flex-wrap: wrap;

    .info-card {
      flex: 1;
      min-width: 150px;
      background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
      border-radius: 12px;
      padding: 16px;
      text-align: center;
      border: 1px solid #e2e8f0;
      transition: all 0.3s ease;

      &:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
      }
    }

    .info-label {
      font-size: 13px;
      color: #6b7280;
      margin-bottom: 6px;
      font-weight: 500;
    }

    .info-value {
      font-size: 15px;
      color: #1f2937;
      word-break: break-all;

      &.order-id {
        font-family: monospace;
        font-size: 14px;
        background: #f1f5f9;
        padding: 4px 8px;
        border-radius: 6px;
        display: inline-block;
        max-width: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      &.countdown {
        font-weight: 600;

        &.expired {
          color: #dc2626;
        }
      }
    }
  }

  .qrcode-container {
    text-align: center;
    margin: 20px 0;
    padding: 20px;
    background: #f8fafc;
    border-radius: 16px;
    border: 1px solid #e2e8f0;

    .qrcode-wrapper {
      display: flex;
      justify-content: center;
      margin-bottom: 15px;
    }

    :deep(.qrcode-image) {
      border: 1px solid #d1d5db;
      border-radius: 8px;
      padding: 10px;
      background: white;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
    }

    .qrcode-tip {
      margin: 0;
      font-size: 14px;
      color: #6b7280;
    }
  }

  .countdown-progress {
    margin: 20px 0;

    .progress-bar {
      width: 100%;
      height: 8px;
      background: #e2e8f0;
      border-radius: 4px;
      overflow: hidden;
      margin-bottom: 8px;

      .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #10b981, #3b82f6);
        transition: width 0.3s ease;
      }
    }

    .progress-text {
      text-align: center;
      font-size: 14px;
      color: #6b7280;
      font-weight: 500;
    }
  }

  .action-buttons {
    display: flex;
    gap: 12px;
    margin-bottom: 20px;
    flex-wrap: wrap;

    .check-btn,
    .back-btn,
    .re-pay-btn {
      flex: 1;
      min-width: 120px;
      height: 44px;
      border-radius: 10px;
      // color: white;
    }

    .repay-btn-white {
      color: white;
    }

    .re-pay-btn {
      background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
      border: none;

      &:hover {
        background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
      }
    }
  }

  .tips-section {
    background: #f8fafc;
    border-radius: 12px;
    padding: 16px;
    border-left: 4px solid #3b82f6;
    margin-bottom: 15px;

    h4 {
      margin: 0 0 10px 0;
      font-size: 15px;
      color: #111827;
      font-weight: 600;
    }

    ul {
      margin: 0;
      padding-left: 20px;
      font-size: 13px;
      color: #4b5563;
      line-height: 1.6;

      li {
        margin-bottom: 6px;

        &:last-child {
          margin-bottom: 0;
        }
      }
    }
  }
}

@keyframes spin {
  from {
    transform: rotate(0deg);
  }

  to {
    transform: rotate(360deg);
  }
}

// 响应式适配
@media (max-width: 768px) {
  .waiting-pay-card {
    width: 95%;
    margin: 20px auto;

    .card-content {
      padding: 20px 20px 25px;
    }

    .info-grid {
      grid-template-columns: 1fr !important;
    }

    .action-buttons {
      flex-direction: column;

      .check-btn,
      .back-btn,
      .re-pay-btn {
        width: 100%;
      }
    }
  }
}
</style>